<head>
<meta http-equiv="Content-Language" content="fr-ca">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">


<script language="JavaScript" src="navbar.js"></script>
<script language="JavaScript" src="dhtmllib.js"></script>
<script type="text/javascript" src="iehover-fix.js"></script>
<script id=clientEventHandlersJS language=javascript>
<!--

function Button1_onclick() {
WebBrowser.ExecWB(6,6);
}

//-->
</script>
 <script language="JavaScript">
// Define navigation bar settings.

navBarX = -50;
navBarY = 0;
navBarHeaderWidth  =260;
navBarMenuWidth    = 200;
navBarBorderWidth  =  4;
navBarPaddingWidth =   2;

navBarBorderColor   = "#000000";
navBarHeaderBgColor = "#999999";
navBarHeaderFgColor = "#000000";
navBarActiveBgColor = "#666666";
navBarActiveFgColor = "#ffffff";
navBarItemBgColor   = "#cccccc";
navBarItemFgColor   = "#000000";
navBarHighBgColor   = "#000080";
navBarHighFgColor   = "#ffffff";

navBarHeaderFontFamily = "Verdana,Arial,Helvetica,sans-serif";
navBarHeaderFontStyle  = "plain";
navBarHeaderFontWeight = "bold";
navBarHeaderFontSize   = "14pt";
navBarItemFontFamily   = "Verdana,Arial,Helvetica,sans-serif";
navBarItemFontStyle    = "plain";
navBarItemFontWeight   = "bold";
navBarItemFontSize     = "14pt";
</script>
<style type="text/css" media="all">
<?php include("uls-vertical.css");?>
</style>

</head>
<body>
<OBJECT ID="WebBrowser" WIDTH=0 HEIGHT=0 CLASSID="CLSID:8856F961-340A-11D0-A96B-00C04FD705A2"></OBJECT>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="43%" id="AutoNumber1">
<tr>
<td >
<ul id="nav1">
<li><a href="list_devices.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2"><b>Devices</b></font></a>	
		<ul>
		<li><a href="list_devices.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2" ><b>Devices&nbsp;List</b></font></a></li>		
		<li><a href="add_device.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2" ><b>Add&nbsp;New&nbsp;Device</b></font></a></li>		
		<li><a href="devices_division.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2" ><b>Devices&nbsp;division</b></font></a></li>
		<li><a href="large_devices.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2" ><b>Watch&nbsp;Large&nbsp;devices</b></font></a></li>
		<li><a href="meduim_devices.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2" ><b>Watch&nbsp;Meduim&nbsp;devices</b></font></a></li>
		<li><a href="small_devices.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2" ><b>Watch&nbsp;Small&nbsp;devices</b></font></a></li>

		</ul>
	</li>

</ul>
</td>

<td >
<ul id="nav2">
<li><a href="list_tasks.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2"><b>Tasks</b></font></a>	
		<ul>
		<li><a href="list_tasks.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2" ><b>Tasks&nbsp;List</b></font></a></li>		
		<li><a href="add_task.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2" ><b>Add&nbsp;New&nbsp;Task</b></font></a></li>		
		<li><a href="tasks_division.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2" ><b>Tasks&nbsp;division</b></font></a></li>
		<li><a href="large_tasks.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2" ><b>Watch&nbsp;Large&nbsp;tasks</b></font></a></li>
		<li><a href="meduim_tasks.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2" ><b>Watch&nbsp;Meduim&nbsp;tasks</b></font></a></li>
		<li><a href="small_tasks.php" title=""  <?php if($un_element131["lf"]!="Yes" ) echo " disabled"; ?>><font size="2" ><b>Watch&nbsp;Small&nbsp;tasks</b></font></a></li>

</ul>
</td>



<td >
<ul id="nav3">
		<li><a href="search_algorithm.php" title=""  <?php if($un_element131["lclient"]!="Yes" ) echo " disabled"; ?>><font size="2"><b>Search Tasks</b></font></a>
			
				<ul>	
			
		<li><a href="search_algorithm.php" title=""  <?php if($un_element131["le"]!="Yes" ) echo " disabled"; ?>><font size="2"><b>Our Algorithm</b></font></a>
			</li>	

		<li><a href="Longest_Cloudlet_Fastest.php" title=""  <?php if($un_element131["le"]!="Yes" ) echo " disabled"; ?>><font size="2"><b>Longest Cloudlet&nbsp;Fastest&nbsp;Processing</b></font></a>
			</li>
		<li><a href="Shortest_Cloudlet_Fastest.php" title=""  <?php if($un_element131["le"]!="Yes" ) echo " disabled"; ?>><font size="2"><b>Shortest&nbsp;Cloudlet&nbsp;Fastest&nbsp;Processing</b></font></a>
			</li>

		<li><a href="Min_Min.php" title=""  <?php if($un_element131["le"]!="Yes" ) echo " disabled"; ?>><font size="2"><b>Min&nbsp;Min</b></font></a>
			</li>	
		</ul>
	</li>

</ul>


</td>


<td>
<ul id="nav4">
		<li><a href="compare-algorithms00.php" title=""  <?php if($un_element131["lclient"]!="Yes" ) echo " disabled"; ?>><font size="2"><b>Generate the list of devices and tasks</b></font></a>
			
	<ul>	
			<li><a href="compare-algorithms00.php" title=""  <?php if($un_element131["lclient"]!="Yes" ) echo " disabled"; ?>><font size="2"><b>Generate the list of devices and tasks</b></font></a>
		</li>	
		<li><a href="main.php" title=""  <?php if($un_element131["le"]!="Yes" ) echo " disabled"; ?>><font size="2"><b>Execute all Tests for all Algorithms</b></font></a>
			</li>	
		<li><a href="compare-algorithms10.php" title=""  <?php if($un_element131["le"]!="Yes" ) echo " disabled"; ?>><font size="2"><b>Display the results of all the Tests</b></font></a>
			</li>	
		</ul>					
	</li>

</ul>
</td>



  </tr>
</table>
