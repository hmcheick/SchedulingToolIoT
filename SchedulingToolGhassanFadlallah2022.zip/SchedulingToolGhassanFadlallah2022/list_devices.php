<?php include("connection.php");
include("top.php");



if($_GET["id"]!='')
{
if($_GET["modif"]=='1')

{
$id=$_GET["id"];
$device=$_GET["device"];
$score=$_GET["score"];
$sql5 = "update devices set device='" . $device ."', score=" . $score ."  where id=" . $_GET["id"];
if ($conn->query($sql5) === TRUE) {
   echo "";
}

}
else 
{
$id=$_GET["id"];
$sql5 = "delete from devices where id=" . $_GET["id"];
if ($conn->query($sql5) === TRUE) {
   echo "";
}	

}
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>

<body onload="navBarInit()" bgcolor="#C0C0C0"  onload="javacript:form1.rech1.focus()">

<form method="POST" name="form1" action="list_devices.php?ajouter=1&rech1=<?php echo $rech1; ?>&rech2=<?php echo $rech2; ?>">

 <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="50%" id="AutoNumber1">

 <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="50%" id="AutoNumber1">
 <tr>
     <td width="15%">
    <p align="center"><b><a href="list_devices.php?param=code&rech1=<?php echo $rech1; ?>&rech2=<?php echo $rech2; ?>&active=<?php echo $_GET['active']; ?>&inactive=<?php echo $_GET['inactive']; ?>"  style="text-decoration: none;color:blue" >Id</a></b></td>
    <td width="15%">
    <p align="center"><b><a href="list_devices.php?param=code&rech1=<?php echo $rech1; ?>&rech2=<?php echo $rech2; ?>&active=<?php echo $_GET['active']; ?>&inactive=<?php echo $_GET['inactive']; ?>"  style="text-decoration: none;color:blue" >Device</a></b></td>
     <td width="15%">
    <p align="center"><b><a href="list_devices.php?param=code&rech1=<?php echo $rech1; ?>&rech2=<?php echo $rech2; ?>&active=<?php echo $_GET['active']; ?>&inactive=<?php echo $_GET['inactive']; ?>"  style="text-decoration: none;color:blue" >Score</a></b></td>
   <td width="15%">&nbsp;</td>
  
 </tr>
  

<?php 

$requete1= "SELECT * FROM devices order by score";

$j=0;
$curseur1 = @mysql_query($requete1) Or die("Impossible de s�lectionner le contenu de la requete");	
while( $un_element = mysql_fetch_array($curseur1))
{
?>

<tr>
    <td width="15%">
    <p align="center"><?php echo "<a  style='text-decoration: none;color:blue' href='list_devices.php'>" . $un_element["id"] . "</a>"; ?><input type='text' size='1' name='id<?php echo $j; ?>' value='<?php echo $un_element["id"]; ?>'  style="visibility:hidden"></td>
        <td width="15%">
    <p align="center"><input type='text' size='25' name='device<?php echo $j; ?>' value="<?php echo str_replace('É','�',$un_element['device']) ;  ?>"></td>
<td width="15%">
    <p align="center"><input type='text' size='25' name='score<?php echo $j; ?>' value="<?php echo str_replace('É','�',$un_element['score']) ;  ?>"></td>
<td width="15%"> <input type="button" value="Modify" name="B1" onclick="javascript:window.location='list_devices.php?modif=1&id=<?php echo $un_element[id];?>&device='+document.form1.device<?php echo $j; ?>.value+'&score='+document.form1.score<?php echo $j; ?>.value "><input type="button" value="Delete" name="B2"  onclick="javascript:window.location='list_devices.php?id=<?php echo $un_element[id];?>'" ><input type="button" onclick="javascript:window.location='add_device.php'" value="Add" name="B2"></td>
    
  </tr>
<?php 
$i=$i+1;
$j=$j+1;
  }
$j=$j-1;
?>

</table>	

          </form>

</body>

</html>