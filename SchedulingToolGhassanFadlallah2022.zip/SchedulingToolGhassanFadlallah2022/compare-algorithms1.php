<?php include("connection.php");
/*Ce script est pour initialiser les données, 
on doit l'executer avant chaque algorithme pour reinitialiser
les taches et les devices, on utilise les deux fichiers devices.txt et tasks.txt
ces deux fichiers contiennent les devices et les taches à executé
*/
include("top.php");


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from devices";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from large_devices";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from meduim_devices";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from small_devices";
if ($conn->query($sql4) === TRUE) {
echo "";
}


    // Nom du fichier des devices
    $fichier = file("devices.txt");
    // Nombre total de ligne du fichier
    $total = count($fichier);
    if($_POST[devico]!='') { $total=$_POST[devico]; }
    for($i = 0; $i < $total; $i++) {
    // On affiche ligne par ligne le contenu du fichier
    // avec la fonction nl2br pour ajouter les sauts de lignes
   // echo $fichier[$i] . '<br>';
$tt=explode(" ", $fichier[$i]);
$sql = "INSERT INTO devices(device,score,avail) VALUES ('$tt[0]',$tt[1],0);";

if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}




    }





if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from large_tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from meduim_tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from small_tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

    // Nom du fichier des taches
    $fichier = file("tasks.txt");
    // Nombre total de ligne du fichier
    $total = count($fichier);
        if($_POST[tasko]!='') { $total=$_POST[tasko]; }
    for($i = 0; $i < $total; $i++) {
    // On affiche ligne par ligne le contenu du fichier
    // avec la fonction nl2br pour ajouter les sauts de lignes
   // echo $fichier[$i] . '<br>';
$tt=explode(" ", $fichier[$i]);
$sql = "INSERT INTO tasks(task,size,avail,temps) VALUES ('$tt[0]',$tt[1],0,$tt[2]);";
if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}




    }





//Division des devices
//-----------------------------------
//----------------------------------
$sql5 = "delete from small_devices;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from meduim_devices;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from large_devices;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
//begin of small division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT * FROM devices where score>0 and score<10";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$device=$row["device"];
$score=$row["score"];
$sql4 = "INSERT INTO small_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 

//begin of meduim division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql1 = "SELECT * FROM devices where score>=10 and score<20";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
$device=$row1["device"];
$score=$row1["score"];
$sql5 = "INSERT INTO meduim_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql5) === TRUE) {
    echo "";
} } } 

//begin of large division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql2 = "SELECT * FROM devices where score>=20";
$result2 = $conn->query($sql2);

if ($result2->num_rows > 0) {
    // output data of each row
    while($row2 = $result2->fetch_assoc()) {
$device=$row2["device"];
$score=$row2["score"];
$sql4 = "INSERT INTO large_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 

$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s0=$timediff;
//---------------------------------------------
//---------------------------------------------

//Division des taches
//-----------------------------------
//----------------------------------
$starttime = microtime(true);

$sql5 = "delete from small_tasks;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from meduim_tasks;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from large_tasks;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
//begin of small division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT * FROM tasks where size>0 and size<10";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$task=$row["task"];
$size=$row["size"];
$temps=$row["temps"];
$sql4 = "INSERT INTO small_tasks(task,size,avail,temps) VALUES ('$task',$size,0,$temps);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 

//begin of meduim division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql1 = "SELECT * FROM tasks where size>=10 and size<20";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
$task=$row1["task"];
$size=$row1["size"];
$temps=$row1["temps"];
$sql5 = "INSERT INTO meduim_tasks(task,size,avail,temps) VALUES ('$task',$size,0,$temps);";
if ($conn->query($sql5) === TRUE) {
    echo "";
} } } 

//begin of large division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql2 = "SELECT * FROM tasks where size>=20";
$result2 = $conn->query($sql2);

if ($result2->num_rows > 0) {
    // output data of each row
    while($row2 = $result2->fetch_assoc()) {
$task=$row2["task"];
$size=$row2["size"];
$temps=$row2["temps"];
$sql4 = "INSERT INTO large_tasks(task,size,avail,temps) VALUES ('$task',$size,0,$temps);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 


//echo '<b>Division finished with succes</b>';
 
?>


</body>

</html>





