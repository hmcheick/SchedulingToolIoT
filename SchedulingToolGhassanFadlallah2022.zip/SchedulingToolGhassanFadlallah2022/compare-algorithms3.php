<?php
header("refresh: 10"); 
//on utilise 10 seconds pour ré-executer des nouvelles taches
//on peut mettre 20 seconds, 30 seconds ou autre
//Ce script execute le scf algorithme, on doit attendre qu'il execute tous les taches qui sont
//dans le fichier tasks.txt
include("connection.php");
include("top.php");
$some=0;
$ss1=0;
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT *  FROM devices order by score desc";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
$some=1;
$starttime = microtime(true);
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT * FROM tasks where size<=" . $row["score"] . " order by size asc limit 1"; 

$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($result1->num_rows > 0) {
$ss1=1;
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
}
elseif($row1["size"]<=$row["score"])
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
$id_device=$row["id"];
$nom_device=$row["device"];
$id_task=$row1["id"];
$nom_task=$row1["task"];
$id_task=$row1["id"];
$temps=$row1["temps"];
$sql4 = "INSERT INTO a2(id_device,device,id_task,task,avail,temps) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps);";
if ($conn->query($sql4) === TRUE) {
    echo "";
}
$sql4 = "delete from tasks where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
} 


}
}
$endtime = microtime(true);
$timediff = $endtime - $starttime;
if ($ss1==0)
{
echo '<b>All the tasks are executed</b>';
}
else
{
echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';





$endtime = microtime(true);
$timediff = $endtime - $starttime;
//ecrire tout le temps de calcul dans un fichier text
$myfile = fopen("scf.txt", "a") or die("Unable to open file!");
$txt =$timediff;
fwrite($myfile, $txt);
$txt = "\n";
fwrite($myfile, $txt);
fclose($myfile);
}
} 

?>






