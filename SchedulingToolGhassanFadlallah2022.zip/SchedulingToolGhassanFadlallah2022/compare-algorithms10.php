<?php include("connection.php");
include("top.php");
echo '<br><br>-------------Extraire des resultats------------<br>';
$sql2 = "SELECT max(no_test) maxi FROM a1";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$maxi=$row2["maxi"];

$nb_device=0;
$nb_task=0;

$mkdvdf1=0;
$mkdvdf2=0;
$mkdvdf3=0;
$mkdvdf4=0;

$mkspn1=0;
$mkspn2=0;
$mkspn3=0;
$mkspn4=0;

$df1=0;
$df2=0;
$df3=0;
$df4=0;


$dv1=0;
$dv2=0;
$dv3=0;
$dv4=0;

$std_dv=0;

$tab_Makespan = array_fill(0,2,array_fill(0,2,''));

$Best_Makespan=array(4, 2); 
for ($i=0; $i<4; $i++)
{
$Best_Makespan[$i][1]=0;
}

$Best_Dfr=array(4, 2); 
for ($i=0; $i<4; $i++)
{
$Best_Dfr[$i][1]=0;
}


$Best_Dev=array(4, 2); 
for ($i=0; $i<4; $i++)
{
$Best_Dev[$i][1]=0;
}

// number of Tasks charged to each device
$k=0;
$k1=0;
$k2=0;
$k3=0;

$Dev_Charge=array(500, 2); 
for ($i=0; $i<100; $i++)
{
	$Dev_Charge[$i][0]=0;
	$Dev_Charge[$i][1]=0;
}

$Dev_Charge1=array(500, 2); 
for ($i=0; $i<100; $i++)
{
	$Dev_Charge1[$i][0]=0;
	$Dev_Charge1[$i][1]=0;
}

$Dev_Charge2=array(500, 2); 
for ($i=0; $i<100; $i++)
{
	$Dev_Charge2[$i][0]=0;
	$Dev_Charge2[$i][1]=0;
}

$Dev_Charge3=array(500, 2); 
for ($i=0; $i<100; $i++)
{
	$Dev_Charge3[$i][0]=0;
	$Dev_Charge3[$i][1]=0;
}


/*
$sum_time_device=0;
$std_dev_lcfp=0;
$std_dev_scfp=0;
$std_dev_min=0;
$std_dev_notre=0;
*/


$nb=10;

function Carree($nb){
    $result = $nb*$nb;
     return $result;
// echo "Le carré de $nb est : $result";
}


$std_dev=array(4);
$best_mkspn=array(4);
$best_dif=array(4);

 echo 'maxiii=  ' . $maxi;
echo '<br><br>--------------------------------<br>'; 

// lire les fichiers: lcf.txt, scf.txt, minmin.txt et ghassanalgo.txt
$lines    = file('lcf.txt');
foreach ($lines as $lineNumber => $lineContent)
{
	$last_lcf = number_format($last_lcf + $lineContent, 3);
}
//$last_lcf = array_pop($lines);
echo '<br><br>********************************<br>';
echo 'Tasks-Devices affectation time lcf.txt  : ' . $last_lcf . '<br>';
echo '<br><br>********************************<br>';

$lines    = file('scf.txt');
foreach ($lines as $lineNumber => $lineContent)
{
	$last_scf = number_format($last_scf + $lineContent, 3);
}
//$last_scf = array_pop($lines);
echo '<br><br>********************************<br>';
echo 'Tasks-Devices affectation time scf.txt  : ' . $last_scf . '<br>';
echo '<br><br>********************************<br>';

$lines    = file('minmin.txt');
foreach ($lines as $lineNumber => $lineContent)
{
	$last_min = number_format($last_min + $lineContent, 3);
}
//$last_min = array_pop($lines);
echo '<br><br>********************************<br>';
echo 'Tasks-Devices affectation time minmin.txt  : ' . $last_min . '<br>';
echo '<br><br>********************************<br>';

$lines    = file('ghassanalgo.txt');
foreach ($lines as $lineNumber => $lineContent)
{
	$last_our = number_format($last_our + $lineContent, 3);
}
//$last_our = array_pop($lines);
echo '<br><br>********************************<br>';
echo 'Tasks-Devices affectation time ouralgo.txt  : ' . $last_our . '<br>';
echo '<br><br>********************************<br>';




for ($jjj=1;$jjj<=$maxi;$jjj++) 
{
	echo '<h1>INSTANCE NO: ' . $jjj . '</h1><br>';
	$maxspan1=0;$maxspan2=0;$maxspan3=0;$maxspan4=0;
	$minspan1=2000;$minspan2=2000;$minspan3=2000;$minspan4=2000;
	$dev1=0;$dev2=0;$dev3=0;$dev4=0;

 	echo '$jjj  =' . $jjj;
	echo '<br><br>--------------------------------<br>'; 

	echo '<br><br>--------------------------------<br>';
	echo '<b>Resultats LCFP</b><br>';
	echo '--------------------------------';

	$rg_device=0;
	$sum_part=array(100);
	$sum_time_device=0;
	$std_dev_lcfp=0;
	$dif=0;
	$cr=0;
	
	$s=0;

	$sql11 = "SELECT distinct(id_task)  FROM a1 where no_test=". $jjj;
	// $sql11 = "SELECT id_task  FROM a1 where no_test=". $jjj;
	$result11 = $conn->query($sql11);
	$nb_task=$result11->num_rows;
	echo '<br><br>--------------------------------<br>';
	echo 'nombre des taches dans a1  : ' . $nb_task . '<br>';


	$sql1 = "SELECT distinct(id_device)  FROM a1 where no_test=". $jjj;
	// $sql1 = "SELECT id_device  FROM a1 where no_test=". $jjj;
	$result1 = $conn->query($sql1);

	$nb_device=$result1->num_rows;
	echo '<br><br>--------------------------------<br>';
	echo 'nombre des appareils dans a1  : ' . $nb_device . '<br>';

	if ($result1->num_rows > 0) 
	{
    		// output data of each row
		$k=2;
    		while($row1 = $result1->fetch_assoc()) 
		{
			$id_device=$row1["id_device"];

			$sql2 = "SELECT count(*) nombre FROM a1 where id_device=". $id_device. " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$nombre=$row2["nombre"];

			$sql2 = "SELECT device FROM a1 where id_device=". $id_device . " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$device=$row2["device"];

			$nom_task=$row1["task"];
			$nom_device=$row1["device"];
 			echo '<br><br>Le device ' . $device . ' a execute les taches suivants :<br>';
			// $Dev_Charge[$k][0]=$device;
			$some=0;
			$some2=0;
			$sql3 = "SELECT task,temps FROM a1 where id_device=". $id_device . " and no_test=". $jjj;;
			$result3 = $conn->query($sql3);
			while($row3 = $result3->fetch_assoc()) 
			{
				$task=$row3["task"];
				$temps=$row3["temps"];
				$some=$some+$temps;
 				echo $task . ', ' . $temps . ' seconds<br>';
				//affichage des sizes des tasks
				$sql5 = "SELECT size FROM tasks where task='". $task . "'";
				$result5 = $conn->query($sql5);
				$row5 = $result5->fetch_assoc();
				$size=$row5["size"];

				$some2=$some2+$size;
 				// echo 'Taille taches=' . $size . '<br>';
			}
			$s=$s+$some;
			$rg_device++;
			$sum_part[$rg_device]=$some;
 			// echo '<br><br> Le device ' . $device . ' a execute les taches suivants :<br>';
			echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
 			// echo 'Temps total requis par cet appareil ' . $rg_device . ' seconds<br>';
		 	
			if($maxspan1<$some) 
			{
				$maxspan1=$some;
				$dev1=$device;
			}

			if($minspan1>$some) 
			{
				$minspan1=$some;
			}

 			echo 'Taille total des taches executes ' . $some . '<br>';
			echo '<br><br>device: '. $device .'  nombre: '. $nombre .' <br>';
			if($jjj==1)
			{
				$Dev_Charge[$k][0]=$device;
				$Dev_Charge[$k][1]=$nombre;	
				$k++;			
			}
			else
			{
				$found=0;
				$kk=0;
				for($m=2; $m<=$nb_device+2; $m++)
				{
					if($Dev_Charge[$m][0]==$device)
					{
						$found=1;
						$kk=$m;
						break;
						// $Dev_Charge[$m][0]=$device;
						// $Dev_Charge[$m][1]=$Dev_Charge[$m][1]+$nombre;
						// echo '<b> found : ' .  $found . ' Device :  ' . $Dev_Charge[$m][0] . ' a une valeur : ' . $Dev_Charge[$m][1] . '</b><br>';
						// $m=$k+2
					}

				}
				if($found==0)
				{
					$Dev_Charge[$k][0]=$device;
					$Dev_Charge[$k][1]=$nombre;	
					$k++;	
				}
				else
				{
					$Dev_Charge[$kk][0]=$device;
					$Dev_Charge[$kk][1]=$Dev_Charge[$kk][1]+$nombre;
					echo '<b> kk : ' .  $kk . ' Device :  ' . $Dev_Charge[$kk][0] . ' a une valeur : ' . $Dev_Charge[$kk][1] . '</b><br>';	
				}	
			}
		}

		for($i=1; $i<=$nb_device; $i++)
		{
			// echo '<b> i : ' . $i . '  Device :  ' . $Dev_Charge[$i+1][0] . ' a une valeur : ' . $Dev_Charge[$i+1][1] . '</b><br>';

			$sum_time_device=$sum_time_device+Carree($sum_part[$i]-$maxspan1);
		}

		// $sum_time_device=$sum_time_device+$s;
 		echo 'Temps total par tous les appareils ' . $sum_time_device . '<br>';
		// $dif=$sum_time_device-$maxspan1;
		// $cr=Carree($dif);
		$std_dev_lcfp=sqrt($sum_time_device/$nb_device);
	} 
	$std_dev[0]=number_format($std_dev_lcfp, 3);
 	// echo '<br><br><b> Deviation standard de LCFP:' . $std_dev[0] . '</b><br>';
	for($i=1; $i<=$nb_device; $i++)
	{
		echo '<b> i : ' . $i . '  Device :  ' . $Dev_Charge[$i+1][0] . ' a une valeur : ' . $Dev_Charge[$i+1][1] . '</b><br>';

	}
	?>

	<?php 
	$maxspan2=0;
	$dev2=0;
	echo '<br><br>--------------------------------<br>';
	echo '<b>Resultats SCFP</b><br>';
	echo '--------------------------------';

	$rg_device=0;
	$sum_part=array(100);
	$sum_time_device=0;
	$std_dev_scfp=0;
	$dif=0;
	$cr=0;

	$s=0;
	$sql1 = "SELECT distinct(id_device)  FROM a2 where no_test=". $jjj;
	// $sql1 = "SELECT id_device  FROM a2 where no_test=". $jjj;
	$result1 = $conn->query($sql1);

	if ($result1->num_rows > 0) 
	{
    		// output data of each row
		$k1=2;
    		while($row1 = $result1->fetch_assoc()) 
		{
			$id_device=$row1["id_device"];

			$sql2 = "SELECT count(*) nombre FROM a2 where id_device=". $id_device . " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$nombre=$row2["nombre"];

			$sql2 = "SELECT device FROM a2 where id_device=". $id_device ." and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$device=$row2["device"];

			$nom_task=$row1["task"];
			$nom_device=$row1["device"];
 			echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';


			$some=0;
			$some2=0;
			$sql3 = "SELECT task,temps FROM a2 where id_device=". $id_device. " and no_test=". $jjj;
			$result3 = $conn->query($sql3);
			while($row3 = $result3->fetch_assoc()) 
			{
				$task=$row3["task"];
				$temps=$row3["temps"];
				$some=$some+$temps;
 				echo $task . ', ' . $temps . ' seconds<br>';
				//affichage des sizes des tasks
				$sql5 = "SELECT size FROM tasks where task='". $task . "'";
				$result5 = $conn->query($sql5);
				$row5 = $result5->fetch_assoc();
				$size=$row5["size"];

				$some2=$some2+$size;
				// echo 'Taille taches=' . $size . '<br>';
			}
			$s=$s+$some;
			$rg_device++;
			$sum_part[$rg_device]=$some;
 			echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
 			// echo 'Temps total requis par cet appareil ' . $rg_device . ' seconds<br>';
			if($maxspan2<$some) 
			{
				$maxspan2=$some;
				$dev2=$device;
			}


			if($minspan2>$some) 
			{
				$minspan2=$some;
			}

 			echo 'Taille total des taches executes ' . $some . '<br>';

			echo '<br><br>device: '. $device .'  nombre: '. $nombre .' <br>';
			if($jjj==1)
			{
				$Dev_Charge1[$k1][0]=$device;
				$Dev_Charge1[$k1][1]=$nombre;	
				$k1++;			
			}
			else
			{
				$found=0;
				$kk=0;
				for($m=2; $m<=$nb_device+2; $m++)
				{
					if($Dev_Charge1[$m][0]==$device)
					{
						$found=1;
						$kk=$m;
						break;
					}

				}
				if($found==0)
				{
					$Dev_Charge1[$k1][0]=$device;
					$Dev_Charge1[$k1][1]=$nombre;	
					$k++;	
				}
				else
				{
					$Dev_Charge1[$kk][0]=$device;
					$Dev_Charge1[$kk][1]=$Dev_Charge1[$kk][1]+$nombre;
					echo '<b> kk : ' .  $kk . ' Device :  ' . $Dev_Charge1[$kk][0] . ' a une valeur : ' . $Dev_Charge1[$kk][1] . '</b><br>';	
				}	
			}

 		} 

		for($i=1; $i<=$nb_device; $i++)
		{
			$sum_time_device=$sum_time_device+Carree($sum_part[$i]-$maxspan2);
		}

		// $sum_time_device=$sum_time_device+$s;
 		echo 'Temps total par tous les appareils ' . $sum_time_device . '<br>';
		// $dif=$sum_time_device-$maxspan1;
		// $cr=Carree($dif);
		$std_dev_scfp=sqrt($sum_time_device/$nb_device);
	} 
	$std_dev[1]=number_format($std_dev_scfp, 3);
 	// echo '<br><br><b> Deviation standard de SCFP:' . $std_dev[1] . '</b><br>';
	for($i=1; $i<=$nb_device; $i++)
	{
		echo '<b> i : ' . $i . '  Device :  ' . $Dev_Charge1[$i+1][0] . ' a une valeur : ' . $Dev_Charge1[$i+1][1] . '</b><br>';

	}
	?>



	<?php 
	$maxspan3=0;
	$dev3=0;
	echo '<br><br>--------------------------------<br>';
	echo '<b>Resultats Min Min</b><br>';
	echo '--------------------------------';

	$rg_device=0;
	$sum_part=array(100);
	$sum_time_device=0;
	$std_dev_min=0;
	$dif=0;
	$cr=0;

	$s=0;
	$sql1 = "SELECT distinct(id_device)  FROM a3 where no_test=". $jjj;
	// $sql1 = "SELECT id_device  FROM a3 where no_test=". $jjj;
	$result1 = $conn->query($sql1);

	if ($result1->num_rows > 0) 
	{
    		// output data of each row
		$k2=2;
    		while($row1 = $result1->fetch_assoc()) 
		{
			$id_device=$row1["id_device"];

			$sql2 = "SELECT count(*) nombre FROM a3 where id_device=". $id_device . " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$nombre=$row2["nombre"];

			$sql2 = "SELECT device FROM a3 where id_device=". $id_device. " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$device=$row2["device"];

			$nom_task=$row1["task"];
			$nom_device=$row1["device"];
 			echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';


			$some=0;
			$some2=0;
			$sql3 = "SELECT task,temps FROM a3 where id_device=". $id_device . " and no_test=". $jjj;
			$result3 = $conn->query($sql3);
			while($row3 = $result3->fetch_assoc()) 
			{
				$task=$row3["task"];
				$temps=$row3["temps"];
				$some=$some+$temps;
 				echo $task . ', ' . $temps . ' seconds<br>';
				//affichage des sizes des tasks
				$sql5 = "SELECT size FROM tasks where task='". $task . "'";
				$result5 = $conn->query($sql5);
				$row5 = $result5->fetch_assoc();
				$size=$row5["size"];

				$some2=$some2+$size;
				// echo 'Taille taches=' . $size . '<br>';
			}
			$s=$s+$some;
			$rg_device++;
			$sum_part[$rg_device]=$some;
 			echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
 			// echo 'Temps total requis par cet appareil ' . $rg_device . ' seconds<br>';
			if($maxspan3<$some) 
			{
				$maxspan3=$some;
				$dev3=$device;
			}


			if($minspan3>$some) 
			{
				$minspan3=$some;
			}
			echo 'Taille total des taches executes ' . $some . '<br>';

			echo '<br><br>device: '. $device .'  nombre: '. $nombre .' <br>';
			if($jjj==1)
			{
				$Dev_Charge2[$k2][0]=$device;
				$Dev_Charge2[$k2][1]=$nombre;	
				$k2++;			
			}
			else
			{
				$found=0;
				$kk=0;
				for($m=2; $m<=$nb_device+2; $m++)
				{
					if($Dev_Charge2[$m][0]==$device)
					{
						$found=1;
						$kk=$m;
					}
				}
				if($found==0)
				{
					$Dev_Charge2[$k2][0]=$device;
					$Dev_Charge2[$k2][1]=$nombre;	
					$k++;	
				}
				else
				{
					$Dev_Charge2[$kk][0]=$device;
					$Dev_Charge2[$kk][1]=$Dev_Charge2[$kk][1]+$nombre;
					echo '<b> kk : ' .  $kk . ' Device :  ' . $Dev_Charge2[$kk][0] . ' a une valeur : ' . $Dev_Charge2[$kk][1] . '</b><br>';	
				}	
			}

 		} 

		for($i=1; $i<=$nb_device; $i++)
		{
			$sum_time_device=$sum_time_device+Carree($sum_part[$i]-$maxspan3);
		}

		// $sum_time_device=$sum_time_device+$s;
 		echo 'Temps total par tous les appareils ' . $sum_time_device . '<br>';
		// $dif=$sum_time_device-$maxspan3;
		// $cr=Carree($dif);
		$std_dev_min=sqrt($sum_time_device/$nb_device);
	} 
	$std_dev[2]=number_format($std_dev_min, 3);
 	// echo '<br><br><b> Deviation standard de Min-Min:' . $std_dev[2] . '</b><br>';
	for($i=1; $i<=$nb_device; $i++)
	{
		echo '<b> i : ' . $i . '  Device :  ' . $Dev_Charge[$i+1][0] . ' a une valeur : ' . $Dev_Charge[$i+1][1] . '</b><br>';
	}
	?>

	<?php 
	$maxspan4=0;
	$dev4=0;
	echo '<br><br>--------------------------------<br>';
	echo '<b>Resultats Notre Algorithme</b><br>';
	echo '--------------------------------';

	$rg_device=0;
	$sum_part=array(100);
	$sum_time_device=0;
	$std_dev_notre=0;
	$dif=0;
	$cr=0;

	$s=0;
	$sql1 = "SELECT distinct(id_device)  FROM a4 where no_test=". $jjj;
	// $sql1 = "SELECT id_device  FROM a4 where no_test=". $jjj;
	$result1 = $conn->query($sql1);

	if ($result1->num_rows > 0) 
	{
    		// output data of each row
		$k3=2;
    		while($row1 = $result1->fetch_assoc()) 
		{
			$id_device=$row1["id_device"];
			
			$sql2 = "SELECT count(*) nombre FROM a4 where id_device=". $id_device . " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$nombre=$row2["nombre"];
			echo $id_device . ', ' . $nombre . ' LABEL<br>';
			$sql2 = "SELECT device FROM a4 where id_device=". $id_device  . " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$device=$row2["device"];

			$nom_task=$row1["task"];
			$nom_device=$row1["device"];
 			echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';


			$some=0;
			$some2=0;
			$sql3 = "SELECT task,temps FROM a4 where id_device=". $id_device. " and no_test=". $jjj;
			$result3 = $conn->query($sql3);
			while($row3 = $result3->fetch_assoc()) 
			{
				$task=$row3["task"];
				$temps=$row3["temps"];
				$some=$some+$temps;
 				echo $task . ', ' . $temps . ' seconds<br>';
				//affichage des sizes des tasks
				$sql5 = "SELECT size FROM tasks where task='". $task . "'";
				$result5 = $conn->query($sql5);
				$row5 = $result5->fetch_assoc();
				$some=$some;
				$size=$row5["size"];

				$some2=$some2+$size;
				// echo 'Taille taches=' . $size . '<br>';
			}
			
			$s=$s+$some;
			$rg_device++;
			$sum_part[$rg_device]=$some;
 			echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
 			echo 'Temps total requis par cet appareil ' . $rg_device . ' seconds<br>';
			if($maxspan4<$some) 
			{
				$maxspan4=$some;
				$dev4=$device;
			}

			if($minspan4>$some) 
			{
				$minspan4=$some;
			}


			// echo 'Taille Makespan ' . $maxspan4 . '<br>';

 			echo 'Taille total des taches executes ' . $some . '<br>';

			echo '<br><br>device: '. $device .'  nombre: '. $nombre .' <br>';
			if($jjj==1)
			{
				$Dev_Charge3[$k3][0]=$device;
				$Dev_Charge3[$k3][1]=$nombre;	
				$k3++;			
			}
			else
			{
				$found=0;
				$kk=0;
				for($m=2; $m<=$nb_device+2; $m++)
				{
					if($Dev_Charge3[$m][0]==$device)
					{
						$found=1;
						$kk=$m;
						break;
					}

				}
				if($found==0)
				{
					$Dev_Charge3[$k3][0]=$device;
					$Dev_Charge3[$k3][1]=$nombre;	
					$k++;	
				}
				else
				{
					$Dev_Charge3[$kk][0]=$device;
					$Dev_Charge3[$kk][1]=$Dev_Charge3[$kk][1]+$nombre;
					echo '<b> kk : ' .  $kk . ' Device :  ' . $Dev_Charge3[$kk][0] . ' a une valeur : ' . $Dev_Charge3[$kk][1] . '</b><br>';	
				}	
			}

 		} 

		for($i=1; $i<=$nb_device; $i++)
		{
			if ($i<$nb_device){$maxspan4=1*$maxspan4;}
			$sum_time_device=$sum_time_device+Carree($sum_part[$i]-$maxspan4);
		}

		// $sum_time_device=$sum_time_device+$s;
 		echo 'Temps total par tous les appareils ' . $sum_time_device . '<br>';
		// $dif=$sum_time_device-$maxspan4;
		// $cr=Carree($dif);
		$std_dev_notre=sqrt($sum_time_device/$nb_device);
	} 
	for($i=1; $i<=$nb_device; $i++)
	{
		echo '<b> i : ' . $i . '  Device :  ' . $Dev_Charge3[$i+1][0] . ' a une valeur : ' . $Dev_Charge3[$i+1][1] . '</b><br>';
	}
/*

	$list = array (
		[' ', ' ', ' ', ' ', ' ', '% of Load Balancing', ' ', ' ', ' ', ' ', ' '],   
		[' Algorithm ', 'D1 ', 'D2 ' , 'D3 ' , 'D4 ', 'D5 ', 'D6 ', 'D7 ', 'D8 ', 'D9 ', 'D10 '],
		['LCFP       ', round($Dev_Charge[2][1]/$jjj),  round($Dev_Charge[3][1]/$jjj) , round($Dev_Charge[4][1]/$jjj) , round($Dev_Charge[5][1]/$jjj), round($Dev_Charge[6][1]/$jjj) ,  round($Dev_Charge[7][1]/$jjj) , round($Dev_Charge[8][1]/$jjj) , round($Dev_Charge[9][1]/$jjj), round($Dev_Charge[10][1]/$jjj), round($Dev_Charge[11][1]/$jjj)],
		['SCFP       ', round($Dev_Charge1[2][1]/$jjj),  round($Dev_Charge1[3][1]/$jjj) , round($Dev_Charge1[4][1]/$jjj) , round($Dev_Charge1[5][1]/$jjj), round($Dev_Charge1[6][1]/$jjj) ,  round($Dev_Charge1[7][1]/$jjj) , round($Dev_Charge1[8][1]/$jjj) , round($Dev_Charge1[9][1]/$jjj), round($Dev_Charge1[10][1]/$jjj), round($Dev_Charge1[11][1]/$jjj)],
		['Min-Min    ', round($Dev_Charge2[2][1]/$jjj),  round($Dev_Charge2[3][1]/$jjj) , round($Dev_Charge2[4][1]/$jjj) , round($Dev_Charge2[5][1]/$jjj), round($Dev_Charge2[6][1]/$jjj) ,  round($Dev_Charge2[7][1]/$jjj) , round($Dev_Charge2[8][1]/$jjj) , round($Dev_Charge2[9][1]/$jjj), round($Dev_Charge2[10][1]/$jjj), round($Dev_Charge2[11][1]/$jjj)],
		['Our-Algorithm', round($Dev_Charge3[2][1]/$jjj),  round($Dev_Charge3[3][1]/$jjj) , round($Dev_Charge3[4][1]/$jjj) , round($Dev_Charge3[5][1]/$jjj), round($Dev_Charge3[6][1]/$jjj) ,  round($Dev_Charge3[7][1]/$jjj) , round($Dev_Charge3[8][1]/$jjj) , round($Dev_Charge3[9][1]/$jjj), round($Dev_Charge3[10][1]/$jjj), round($Dev_Charge3[11][1]/$jjj)]
 	);

	$fp = fopen('file_load_balancing.csv', 'w');

	foreach ($list as $fields) 
	{
    		fputcsv($fp, $fields);
	}

	fclose($fp);

*/

	$std_dev[3]=number_format($std_dev_notre, 3);
 	// echo '<br><br><b> Deviation standard de Notre Algorithme:' . $std_dev[3] . '</b><br>';

	//echo '<br><br><b>Temps Total Notre Algorithme:' . $s . ' seconds</b><br>';

	$sql2 = "SELECT count(id_task) nbr_task FROM a1 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_task1=$row2["nbr_task"];

	$sql2 = "SELECT count(distinct(id_device)) nbr_device FROM a1 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_device1=$row2["nbr_device"];


	$sql2 = "SELECT count(id_task) nbr_task FROM a2 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_task2=$row2["nbr_task"];

	$sql2 = "SELECT count(distinct(id_device)) nbr_device FROM a2 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_device2=$row2["nbr_device"];

	$sql2 = "SELECT count(id_task) nbr_task FROM a3 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_task3=$row2["nbr_task"];

	$sql2 = "SELECT count(distinct(id_device)) nbr_device FROM a3 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_device3=$row2["nbr_device"];


	$sql2 = "SELECT count(id_task) nbr_task FROM a4 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_task4=$row2["nbr_task"];

	$sql2 = "SELECT count(distinct(id_device)) nbr_device FROM a4 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_device4=$row2["nbr_device"];

	// $set_mks = new \Ds\Set([$maxspan1, $maxspan2, $maxspan3, $maxspan4]);
	// $set_mks->sort();
	// print_r($set_mks);

	$maxspan1=number_format($maxspan1+$last_lcf, 3);
	$maxspan2=number_format($maxspan2+$last_scf, 3);
	$maxspan3=number_format($maxspan3+$last_min, 3);
	$maxspan4=number_format($maxspan4+$last_our, 3);
	echo '<b>maxspan1 : ' . $maxspan1 . '    maxspan2 : ' . $maxspan2 . ' maxspan3 : ' . $maxspan3 . '    maxspan4 : ' . $maxspan4 . '</b><br>';
	echo '<b>minspan1 : ' . $minspan1 . '    minspan2 : ' . $minspan2 . ' minspan3 : ' . $minspan3 . '    minspan4 : ' . $minspan4 . '</b><br>';
	
	$diff1=number_format($maxspan1-$minspan1, 3);
	$diff2=number_format($maxspan2-$minspan2, 3);
	$diff3=number_format($maxspan3-$minspan3, 3);
	$diff4=number_format($maxspan4-$minspan4, 3);

	$mksarray = array($maxspan1, $maxspan2, $maxspan3, $maxspan4);
	sort($mksarray);
	$devarray = array($std_dev[0], $std_dev[1], $std_dev[2], $std_dev[3]);
	sort($devarray);
	$difarray = array($diff1, $diff2, $diff3, $diff4);
	sort($difarray);

 	echo '<b>$mksarray[0] : ' . $mksarray[0] . '    $devarray[0] : ' . $devarray[0] . '</b><br>';

	if ($mksarray[0]!==$mksarray[1])
	{

		if ($mksarray[0]==$maxspan1)
		{
			$mkdvdf1++;
			$Best_Makespan[0][0]='LCFP';
			$Best_Makespan[0][1]=$Best_Makespan[0][1]+1;
		 	echo '<b>Best_Makespan[0][0] : ' . $Best_Makespan[0][0] . ' a une valeur : ' . $mkdvdf1 . '</b><br>';
		}

		elseif ($mksarray[0]==$maxspan2)
		{
			$mkdvdf2++;
			$Best_Makespan[1][0]='SCFP';
			$Best_Makespan[1][1]=$Best_Makespan[1][1]+1;
		 	echo '<b>Best_Makespan[1][0] : ' . $Best_Makespan[1][0] . ' a une valeur : ' . $mkdvdf2. '</b><br>';
		}

		elseif ($mksarray[0]==$maxspan3)
		{
			$mkdvdf3++;
			$Best_Makespan[2][0]='Min-Min';
			$Best_Makespan[2][1]=$Best_Makespan[2][1]+1;
		 	echo '<b>Best_Makespan[2][0] : ' . $Best_Makespan[2][0] . ' a une valeur : ' . $mkdvdf3 . '</b><br>';
		}

		elseif ($mksarray[0]==$maxspan4)
		{
			$mkdvdf4++;
			$Best_Makespan[3][0]='Our algorithm';
			$Best_Makespan[3][1]=$Best_Makespan[3][1]+1;
			 echo '<b>Best_Makespan[3][0] : ' . $Best_Makespan[3][0] . ' a une valeur : ' . $mkdvdf4 . '</b><br>';
		}	
	}
	else
	{
		echo '<br><br>--------------------------------<br>';
		echo '<b>*******EGAL1*******</b><br>';
		echo '<br><br>--------------------------------<br>';
		if ($devarray[0]!==$devarray[1])
		{

			if ($devarray[0]==$std_dev[0])
			{
				$mkdvdf1++;
				$Best_Dev[0][0]='LCFP';
				$Best_Dev[0][1]=$Best_Dev[0][1]+1;
			 	echo '<b>Best_Deviation[0][0] : ' . $Best_Dev[0][0] . ' a une valeur : ' . $mkdvdf1 . '</b><br>';
			}

			elseif ($devarray[0]==$std_dev[1])
			{
				$mkdvdf2++;
				$Best_Dev[1][0]='SCFP';
				$Best_Dev[1][1]=$Best_Dev[0][1]+1;
			 	echo '<b>Best_Deviation[1][0] : ' . $Best_Dev[1][0] . ' a une valeur : ' . $mkdvdf2. '</b><br>';
			}

			elseif ($devarray[0]==$std_dev[2])
			{
				$mkdvdf3++;
				$Best_Dev[2][0]='Min-Min';
				$Best_Dev[2][1]=$Best_Dev[0][1]+1;
			 	echo '<b>Best_Deviation[2][0] : ' . $Best_Dev[2][0] . ' a une valeur : ' . $mkdvdf3 . '</b><br>';
			}

			elseif ($devarray[0]==$std_dev[3])
			{
				$mkdvdf4++;
				$Best_Dev[3][0]='Our algorithm';
				$Best_Dev[3][1]=$Best_Dev[0][1]+1;
			 	echo '<b>Best_Deviation[3][0] : ' . $Best_Dev[3][0] . ' a une valeur : ' . $mkdvdf4 . '</b><br>';
			}	
	
		}
		else
		{
			echo '<br><br>--------------------------------<br>';
			echo '<b>*******EGAL2*******</b><br>';
			echo '<br><br>--------------------------------<br>';
			if ($difarray[0]!==$difarray[1])
			{

				if ($difarray[0]==$diff1)
				{
					$mkdvdf1++;
					$Best_Dfr[0][0]='LCFP';
					$Best_Dfr[0][1]=$Best_Dfr[0][1]+1;
				 	echo '<b>Best_Difference[0][0] : ' . $Best_Dfr[0][0] . ' a une valeur : ' . $mkdvdf1 . '</b><br>';
				}

				elseif ($difarray[0]==$diff2)
				{
					$mkdvdf2++;
					$Best_Dfr[1][0]='SCFP';
					$Best_Dfr[1][1]=$Best_Dfr[1][1]+1;
				 	echo '<b>Best_Difference[1][0] : ' . $Best_Dfr[1][0] . ' a une valeur : ' . $mkdvdf2. '</b><br>';
				}

				elseif ($difarray[0]==$diff3)
				{
					$mkdvdf3++;
					$Best_Dfr[2][0]='Min-Min';
					$Best_Dfr[2][1]=$Best_Dfr[2][1]+1;
				 	echo '<b>Best_Difference[2][0] : ' . $Best_Dfr[2][0] . ' a une valeur : ' . $mkdvdf3 . '</b><br>';
				}

				elseif ($difarray[0]==$diff4)
				{
					$mkdvdf4++;
					$Best_Dfr[3][0]='Our algorithm';
					$Best_Dfr[3][1]=$Best_Dfr[3][1]+1;
				 	echo '<b>Best_Difference[3][0] : ' . $Best_Dfr[3][0] . ' a une valeur : ' . $mkdvdf4 . '</b><br>';
				}
			}
			else
			{
				echo '<br><br>--------------------------------<br>';
				echo '<b>*******EGAL3*******</b><br>';
				echo '<br><br>--------------------------------<br>';
				$min_val=min($mkdvdf1, $mkdvdf2, $mkdvdf3, $mkdvdf4);
				if($min_val==$mkdvdf1){$mkdvdf1++;}
				elseif($min_val==$mkdvdf2){$mkdvdf2++;}
				elseif($min_val==$mkdvdf3){$mkdvdf3++;}
				elseif($min_val==$mkdvdf4){$mkdvdf4++;}
			}
		}
	}


	$list = array (
		[' ', ' ', ' ', ' ', ' ', '% of Load Balancing', ' ', ' ', ' ', ' ', ' '],   
		[' Algorithm ', 'D1 ', 'D2 ' , 'D3 ' , 'D4 ', 'D5 ', 'D6 ', 'D7 ', 'D8 ', 'D9 ', 'D10 '],
		['LCFP       ', round($Dev_Charge[2][1]/$jjj),  round($Dev_Charge[3][1]/$jjj) , round($Dev_Charge[4][1]/$jjj) , round($Dev_Charge[5][1]/$jjj), round($Dev_Charge[6][1]/$jjj) ,  round($Dev_Charge[7][1]/$jjj) , round($Dev_Charge[8][1]/$jjj) , round($Dev_Charge[9][1]/$jjj), round($Dev_Charge[10][1]/$jjj), round($Dev_Charge[11][1]/$jjj)],
		['SCFP       ', round($Dev_Charge1[2][1]/$jjj),  round($Dev_Charge1[3][1]/$jjj) , round($Dev_Charge1[4][1]/$jjj) , round($Dev_Charge1[5][1]/$jjj), round($Dev_Charge1[6][1]/$jjj) ,  round($Dev_Charge1[7][1]/$jjj) , round($Dev_Charge1[8][1]/$jjj) , round($Dev_Charge1[9][1]/$jjj), round($Dev_Charge1[10][1]/$jjj), round($Dev_Charge1[11][1]/$jjj)],
		['Min-Min    ', round($Dev_Charge2[2][1]/$jjj),  round($Dev_Charge2[3][1]/$jjj) , round($Dev_Charge2[4][1]/$jjj) , round($Dev_Charge2[5][1]/$jjj), round($Dev_Charge2[6][1]/$jjj) ,  round($Dev_Charge2[7][1]/$jjj) , round($Dev_Charge2[8][1]/$jjj) , round($Dev_Charge2[9][1]/$jjj), round($Dev_Charge2[10][1]/$jjj), round($Dev_Charge2[11][1]/$jjj)],
		['Our-Algorithm', round($Dev_Charge3[2][1]/$jjj),  round($Dev_Charge3[3][1]/$jjj) , round($Dev_Charge3[4][1]/$jjj) , round($Dev_Charge3[5][1]/$jjj), round($Dev_Charge3[6][1]/$jjj) ,  round($Dev_Charge3[7][1]/$jjj) , round($Dev_Charge3[8][1]/$jjj) , round($Dev_Charge3[9][1]/$jjj), round($Dev_Charge3[10][1]/$jjj), round($Dev_Charge3[11][1]/$jjj)]
 	);

	$fp = fopen('file_load_balancing.csv', 'w');

	foreach ($list as $fields) 
	{
    		fputcsv($fp, $fields);
	}

	fclose($fp);


	$list = array (
		[' ', ' ', ' ', ' ', '% Best Criteria', ' ', ' ', ' ', ' '],   
		[' ', ' ', 'Instances Nb ' , 'Devices Nb ' , 'Tasks Nb' , 'LCFP', 'SCFP', 'Min-Min', 'Our algorithm', ' '],
		[' ', ' ',  $maxi ,   $nbr_device1 , $nb_task , number_format($mkdvdf1/$jjj,3), number_format($mkdvdf2/$jjj,3), number_format($mkdvdf3/$jjj,3), number_format($mkdvdf4/$jjj,3), ' ']
 	);

	$fp = fopen('file_crt.csv', 'w');

	foreach ($list as $fields) 
	{
    		fputcsv($fp, $fields);
	}

	fclose($fp);




	$list = array (
		[' ', ' ', ' ', ' ', 'Affectation time', ' ', ' ', ' ', ' '],   
		[' ', ' ', 'Devices Nb ' , 'Tasks Nb' , 'LCFP', 'SCFP', 'Min-Min', 'Our algorithm', ' '],
		[' ', ' ',  $nbr_device1 , $nb_task , $last_lcf, $last_scf, $last_min, $last_our, ' ']
 	);

	$fp = fopen('file_afect.csv', 'w');

	foreach ($list as $fields) 
	{
    		fputcsv($fp, $fields);
	}

	fclose($fp);



/*
 +++++++++++++++++++++++++Début de pourcentage de Makespan+++++++++++++++++++++++++++++

$Best_Mks = min($maxspan1, $maxspan2, $maxspan3, $maxspan4);


 echo '<b>Best Makespan : ' . $Best_Mks . ' pour instance no: ' . $jjj. '=='. $maxspan1 . '=='. $maxspan2  .'=='. $maxspan3  . '=='. $maxspan4 . '</b><br>';

if ($Best_Mks==$maxspan1)
{
	$mkspn1++;
	$Best_Makespan[0][0]='LCFP';
	$Best_Makespan[0][1]=$Best_Makespan[0][1]+1;
	echo '<b>Best_Makespan[0][0] : ' . $Best_Makespan[0][0] . ' a une valeur : ' . $mkspn1 . '</b><br>';
}

elseif ($Best_Mks==$maxspan2)
{
	$mkspn2++;
	$Best_Makespan[1][0]='SCFP';
	$Best_Makespan[1][1]=$Best_Makespan[1][1]+1;
	// echo '<b>Best_Makespan[1][0] : ' . $Best_Makespan[1][0] . ' a une valeur : ' . $mkspn2. '</b><br>';
}

elseif ($Best_Mks==$maxspan3)
{
	$mkspn3++;
	$Best_Makespan[2][0]='Min-Min';
	$Best_Makespan[2][1]=$Best_Makespan[2][1]+1;
	echo '<b>Best_Makespan[2][0] : ' . $Best_Makespan[2][0] . ' a une valeur : ' . $mkspn3 . '</b><br>';
}

elseif ($Best_Mks==$maxspan4)
{
	$mkspn4++;
	$Best_Makespan[3][0]='Our algorithm';
	$Best_Makespan[3][1]=$Best_Makespan[3][1]+1;
	echo '<b>Best_Makespan[3][0] : ' . $Best_Makespan[3][0] . ' a une valeur : ' . $mkspn4 . '</b><br>';
}

$list = array (
	[' ', ' ', ' ' , '% Best Makespan', ' ', ' ', ' ', ' '],   
	[' ', ' ', ' ' , 'Tasks Nb' , 'LCFP', 'SCFP', 'Min-Min', 'Our algorithm', ' '],
	[' ', ' ', ' ' , $nb_task , $mkspn1/$jjj, $mkspn2/$jjj, $mkspn3/$jjj, $mkspn4/$jjj, ' ']
 );

$fp = fopen('file_mks.csv', 'w');

foreach ($list as $fields) {
    fputcsv($fp, $fields);
}

fclose($fp);
 +++++++++++++++++++++++++Fin de pourcentage de Makespan+++++++++++++++++++++++++++++


 +++++++++++++++++++++++++Début de pourcentage de différence Max-Min+++++++++++++++++++++++++++++
$best_dif = min($diff1, $diff2, $diff3, $diff4);


 echo '<b>Best Difference : ' . $best_dif . ' pour instance no: ' . $jjj. '=='. $diff1 . '=='. $diff2  .'=='. $diff3  . '=='. $diff4 . '</b><br>';

if ($best_dif==$diff1)
{
	$df1++;
	$Best_Dfr[0][0]='LCFP';
	$Best_Dfr[0][1]=$Best_Dfr[0][1]+1;
	 echo '<b>Best_Difference[0][0] : ' . $Best_Dfr[0][0] . ' a une valeur : ' . $df1 . '</b><br>';
}

elseif ($best_dif==$diff2)
{
	$df2++;
	$Best_Dfr[1][0]='SCFP';
	$Best_Dfr[1][1]=$Best_Dfr[1][1]+1;
	 echo '<b>Best_Difference[1][0] : ' . $Best_Dfr[1][0] . ' a une valeur : ' . $df2. '</b><br>';
}

elseif ($best_dif==$diff3)
{
	$df3++;
	$Best_Dfr[2][0]='Min-Min';
	$Best_Dfr[2][1]=$Best_Dfr[2][1]+1;
	 echo '<b>Best_Difference[2][0] : ' . $Best_Dfr[2][0] . ' a une valeur : ' . $df3 . '</b><br>';
}

elseif ($best_dif==$diff4)
{
	$df4++;
	$Best_Dfr[3][0]='Our algorithm';
	$Best_Dfr[3][1]=$Best_Dfr[3][1]+1;
	 echo '<b>Best_Difference[3][0] : ' . $Best_Dfr[3][0] . ' a une valeur : ' . $df4 . '</b><br>';
}

$list = array (
	[' ', ' ', ' ' , '% Best Difference', ' ', ' ', ' ', ' '],   
	[' ', ' ', ' ' , 'Tasks Nb' , 'LCFP', 'SCFP', 'Min-Min', 'Our algorithm', ' '],
	[' ', ' ', ' ' , $nb_task , $df1/$jjj, $df2/$jjj, $df3/$jjj, $df4/$jjj, ' ']
 );

$fp = fopen('file_dif.csv', 'w');

foreach ($list as $fields) {
    fputcsv($fp, $fields);
}

fclose($fp);
 +++++++++++++++++++++++++Fin de pourcentage de différence Max-Min+++++++++++++++++++++++++++++




 +++++++++++++++++++++++++Début de pourcentage de déviation+++++++++++++++++++++++++++++


$std_dv = min($std_dev[0], $std_dev[1], $std_dev[2], $std_dev[3]);


 echo '<b>Best Deviation : ' . $std_dv . ' pour instance no: ' . $jjj. '=='. $std_dev[0] . '=='. $std_dev[1]  .'=='. $std_dev[2]  . '=='. $std_dev[43] . '</b><br>';

if ($std_dv==$std_dev[0])
{
	$dv1++;
	$Best_Dev[0][0]='LCFP';
	$Best_Dev[0][1]=$Best_Dev[0][1]+1;
	echo '<b>Best_Deviation[0][0] : ' . $Best_Dev[0][0] . ' a une valeur : ' . $dv1 . '</b><br>';
}

elseif ($std_dv==$std_dev[1])
{
	$dv2++;
	$Best_Dev[1][0]='SCFP';
	$Best_Dev[1][1]=$Best_Dev[0][1]+1;
	echo '<b>Best_Deviation[1][0] : ' . $Best_Dev[1][0] . ' a une valeur : ' . $dv2. '</b><br>';
}

elseif ($std_dv==$std_dev[2])
{
	$dv3++;
	$Best_Dev[2][0]='Min-Min';
	$Best_Dev[2][1]=$Best_Dev[0][1]+1;
	echo '<b>Best_Deviation[2][0] : ' . $Best_Dev[2][0] . ' a une valeur : ' . $dv3 . '</b><br>';
}

elseif ($std_dv==$std_dev[3])
{
	$dv4++;
	$Best_Dev[3][0]='Our algorithm';
	$Best_Dev[3][1]=$Best_Dev[0][1]+1;
	cho '<b>Best_Deviation[3][0] : ' . $Best_Dev[3][0] . ' a une valeur : ' . $dv4 . '</b><br>';
}

$list = array (
	[' ', ' ', ' ' , '% Best Deviation', ' ', ' ', ' ', ' '],   
	[' ', ' ', ' ' , 'Tasks Nb' , 'LCFP', 'SCFP', 'Min-Min', 'Our algorithm', ' '],
	[' ', ' ', ' ' , $nb_task , $dv1/$jjj, $dv2/$jjj, $dv3/$jjj, $dv4/$jjj, ' ']
 );

$fp = fopen('file_dev.csv', 'w');

foreach ($list as $fields) {
    fputcsv($fp, $fields);
}

fclose($fp);


 +++++++++++++++++++++++++Fin de pourcentage de déviation+++++++++++++++++++++++++++++

*/




	$sql4 = "INSERT INTO a5(max_span,min_span,difference,device,nbr_device,nbr_task,algorithm,no_test)  VALUES ($maxspan1,$minspan1,$diff1,'$dev1',$nbr_device1,$nbr_task1,'LCF',$jjj);";
	if ($conn->query($sql4) === TRUE) 
	{
    		echo "";
	}

	$sql4 = "INSERT INTO a5(max_span,min_span,difference,device,nbr_device,nbr_task,algorithm,no_test)  VALUES ($maxspan2,$minspan2,$diff2,'$dev2',$nbr_device2,$nbr_task2,'SCF',$jjj);";
	if ($conn->query($sql4) === TRUE) 
	{
    		echo "";
	}

	$sql4 = "INSERT INTO a5(max_span,min_span,difference,device,nbr_device,nbr_task,algorithm,no_test)  VALUES ($maxspan3,$minspan3,$diff3,'$dev3',$nbr_device3,$nbr_task3,'Min Min',$jjj);";
	if ($conn->query($sql4) === TRUE) 
	{
    		echo "";
	}

	$sql4 = "INSERT INTO a5(max_span,min_span,difference,device,nbr_device,nbr_task,algorithm,no_test)  VALUES ($maxspan4,$minspan4,$diff4,'$dev4',$nbr_device4,$nbr_task4,'Our Algorithm',$jjj);";
	if ($conn->query($sql4) === TRUE) 
	{
    		echo "";
	}

	echo '<br><br>--------------------------------<br>';
	echo '<b>GENERAL RESULTS OF INSTANCE NO ' . $jjj . '</b><br>';
	echo '--------------------------------';

	echo '<br><br>--------------------------------<br>';
	echo '<b>Maxspan LCFP ' . $maxspan1 . '</b><br>';
	echo '<b>Minspan LCFP ' . $minspan1 . '</b><br>';
	echo '<b>Difference LCFP ' . $diff1 . '</b><br>';
	echo '<b>Deviation LCFP ' . $std_dev[0] . '</b><br>';

	echo '<br><br>--------------------------------<br>';
	echo '<b>Maxspan SCFP ' . $maxspan2 . '</b><br>';
	echo '<b>Minspan SCFP ' . $minspan2 . '</b><br>';
	echo '<b>Difference SCFP ' . $diff2 . '</b><br>';
	echo '<b>Deviation SCFP ' . $std_dev[1] . '</b><br>';

	echo '<br><br>--------------------------------<br>';
	echo '<b>Maxspan Min-Min ' . $maxspan3 . '</b><br>';
	echo '<b>Minspan Min-Min ' . $minspan3 . '</b><br>';
	echo '<b>Difference Min-Min ' . $diff3 . '</b><br>';
	echo '<b>Deviation Min-Min ' . $std_dev[2] . '</b><br>';

	echo '<br><br>--------------------------------<br>';
	echo '<b>Maxspan Notre Algorithme ' . $maxspan4 . '</b><br>';
	echo '<b>Minspan Notre Algorithme ' . $minspan4 . '</b><br>';
	echo '<b>Difference Notre Algorithme ' . $diff4 . '</b><br>';
	echo '<b>Deviation Notre Algorithme ' . $std_dev[3] . '</b><br>';

}

?>

