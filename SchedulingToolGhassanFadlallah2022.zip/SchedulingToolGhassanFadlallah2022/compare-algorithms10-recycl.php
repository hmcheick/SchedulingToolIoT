<?php include("connection.php");
include("top.php");

$sql2 = "SELECT max(no_test) maxi FROM a1";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$maxi=$row2["maxi"];

$nb_device=0;


/*
$sum_time_device=0;
$std_dev_lcfp=0;
$std_dev_scfp=0;
$std_dev_min=0;
$std_dev_notre=0;*/


$nb=10;

function Carree($nb){
    $result = $nb*$nb;
     return $result;
// echo "Le carré de $nb est : $result";
}


$std_dev=array(4);


// echo 'maxiii=' . $maxi;
// echo '<br><br>--------------------------------<br>'; 

for ($jjj=1;$jjj<=$maxi;$jjj++) {
echo '<h1>INSTANCE NO: ' . $jjj . '</h1><br>';
$maxspan1=0;$maxspan2=0;$maxspan3=0;$maxspan4=0;
$minspan1=2000;$minspan2=2000;$minspan3=2000;$minspan4=2000;
$dev1=0;$dev2=0;$dev3=0;$dev4=0;
echo '<br><br>--------------------------------<br>';
echo '<b>Resultats LCFP</b><br>';
echo '--------------------------------';

$rg_device=0;
$sum_part=array(100);
$sum_time_device=0;
$std_dev_lcfp=0;
$dif=0;
$cr=0;

$s=0;
$sql1 = "SELECT distinct(id_device)  FROM a1 where no_test=". $jjj;
$result1 = $conn->query($sql1);

$nb_device=$result1->num_rows;
echo '<br><br>--------------------------------<br>';
echo 'nombre des appareils: ' . $nb_device . '<br>';

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
$id_device=$row1["id_device"];

$sql2 = "SELECT count(*) nombre FROM a1 where id_device=". $id_device. " and no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nombre=$row2["nombre"];

$sql2 = "SELECT device FROM a1 where id_device=". $id_device . " and no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$device=$row2["device"];

$nom_task=$row1["task"];
$nom_device=$row1["device"];
echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';

$some=0;
$some2=0;
$sql3 = "SELECT task,temps FROM a1 where id_device=". $id_device . " and no_test=". $jjj;;
$result3 = $conn->query($sql3);
while($row3 = $result3->fetch_assoc()) {
$task=$row3["task"];
$temps=$row3["temps"];
$some=$some+$temps;
echo $task . ', ' . $temps . ' seconds<br>';
//affichage des sizes des tasks
$sql5 = "SELECT size FROM tasks where task='". $task . "'";
$result5 = $conn->query($sql5);
$row5 = $result5->fetch_assoc();
$size=$row5["size"];

$some2=$some2+$size;
echo 'Taille taches=' . $size . '<br>';
}
$s=$s+$some;
$rg_device++;
$sum_part[$rg_device]=$some;
echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
echo 'Temps total requis par cet appareil ' . $rg_device . ' seconds<br>';

if($maxspan1<$some) 
{
$maxspan1=$some;
$dev1=$device;
}

if($minspan1>$some) 
{
$minspan1=$some;
}

echo 'Taille total des taches executes ' . $some . '<br>';
}

for($i=1; $i<=$nb_device; $i++)
{
	$sum_time_device=$sum_time_device+Carree($sum_part[$i]-$maxspan1);
}

// $sum_time_device=$sum_time_device+$s;
echo 'Temps total par tous les appareils ' . $sum_time_device . '<br>';
// $dif=$sum_time_device-$maxspan1;
// $cr=Carree($dif);
$std_dev_lcfp=sqrt($sum_time_device/$nb_device);
} 
$std_dev[1]=$std_dev_lcfp;
echo '<br><br><b> Deviation standard de LCFP:' . $std_dev[1] . '</b><br>';
?>

<?php 
$maxspan2=0;
$dev2=0;
echo '<br><br>--------------------------------<br>';
echo '<b>Resultats SCFP</b><br>';
echo '--------------------------------';

$rg_device=0;
$sum_part=array(100);
$sum_time_device=0;
$std_dev_scfp=0;
$dif=0;
$cr=0;

$s=0;
$sql1 = "SELECT distinct(id_device)  FROM a2 where no_test=". $jjj;
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
$id_device=$row1["id_device"];

$sql2 = "SELECT count(*) nombre FROM a2 where id_device=". $id_device . " and no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nombre=$row2["nombre"];

$sql2 = "SELECT device FROM a2 where id_device=". $id_device ." and no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$device=$row2["device"];

$nom_task=$row1["task"];
$nom_device=$row1["device"];
echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';


$some=0;
$some2=0;
$sql3 = "SELECT task,temps FROM a2 where id_device=". $id_device. " and no_test=". $jjj;
$result3 = $conn->query($sql3);
while($row3 = $result3->fetch_assoc()) {
$task=$row3["task"];
$temps=$row3["temps"];
$some=$some+$temps;
echo $task . ', ' . $temps . ' seconds<br>';
//affichage des sizes des tasks
$sql5 = "SELECT size FROM tasks where task='". $task . "'";
$result5 = $conn->query($sql5);
$row5 = $result5->fetch_assoc();
$size=$row5["size"];

$some2=$some2+$size;
//echo 'Taille taches=' . $size . '<br>';
}
$s=$s+$some;
$rg_device++;
$sum_part[$rg_device]=$some;
echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
echo 'Temps total requis par cet appareil ' . $rg_device . ' seconds<br>';
if($maxspan2<$some) 
{
$maxspan2=$some;
$dev2=$device;
}


if($minspan2>$some) 
{
$minspan2=$some;
}

echo 'Taille total des taches executes ' . $some . '<br>';
 } 

for($i=1; $i<=$nb_device; $i++)
{
	$sum_time_device=$sum_time_device+Carree($sum_part[$i]-$maxspan2);
}

// $sum_time_device=$sum_time_device+$s;
echo 'Temps total par tous les appareils ' . $sum_time_device . '<br>';
// $dif=$sum_time_device-$maxspan1;
// $cr=Carree($dif);
$std_dev_scfp=sqrt($sum_time_device/$nb_device);
} 
$std_dev[2]=$std_dev_scfp;
echo '<br><br><b> Deviation standard de SCFP:' . $std_dev[2] . '</b><br>';
?>



<?php 
$maxspan3=0;
$dev3=0;
echo '<br><br>--------------------------------<br>';
echo '<b>Resultats Min Min</b><br>';
echo '--------------------------------';

$rg_device=0;
$sum_part=array(100);
$sum_time_device=0;
$std_dev_min=0;
$dif=0;
$cr=0;

$s=0;
$sql1 = "SELECT distinct(id_device)  FROM a3 where no_test=". $jjj;
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
$id_device=$row1["id_device"];

$sql2 = "SELECT count(*) nombre FROM a3 where id_device=". $id_device . " and no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nombre=$row2["nombre"];

$sql2 = "SELECT device FROM a3 where id_device=". $id_device. " and no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$device=$row2["device"];

$nom_task=$row1["task"];
$nom_device=$row1["device"];
echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';


$some=0;
$some2=0;
$sql3 = "SELECT task,temps FROM a3 where id_device=". $id_device . " and no_test=". $jjj;
$result3 = $conn->query($sql3);
while($row3 = $result3->fetch_assoc()) {
$task=$row3["task"];
$temps=$row3["temps"];
$some=$some+$temps;
echo $task . ', ' . $temps . ' seconds<br>';
//affichage des sizes des tasks
$sql5 = "SELECT size FROM tasks where task='". $task . "'";
$result5 = $conn->query($sql5);
$row5 = $result5->fetch_assoc();
$size=$row5["size"];

$some2=$some2+$size;
//echo 'Taille taches=' . $size . '<br>';
}
$s=$s+$some;
$rg_device++;
$sum_part[$rg_device]=$some;
echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
echo 'Temps total requis par cet appareil ' . $rg_device . ' seconds<br>';
if($maxspan3<$some) 
{
$maxspan3=$some;
$dev3=$device;
}


if($minspan3>$some) 
{
$minspan3=$some;
}



//echo 'Taille total des taches executes ' . $some . '<br>';
 } 

for($i=1; $i<=$nb_device; $i++)
{
	$sum_time_device=$sum_time_device+Carree($sum_part[$i]-$maxspan3);
}

// $sum_time_device=$sum_time_device+$s;
echo 'Temps total par tous les appareils ' . $sum_time_device . '<br>';
// $dif=$sum_time_device-$maxspan3;
// $cr=Carree($dif);
$std_dev_min=sqrt($sum_time_device/$nb_device);
} 
$std_dev[3]=$std_dev_min;
echo '<br><br><b> Deviation standard de Min-Min:' . $std_dev[3] . '</b><br>';
?>

<?php 
$maxspan4=0;
$dev4=0;
echo '<br><br>--------------------------------<br>';
echo '<b>Resultats Notre Algorithme</b><br>';
echo '--------------------------------';

$rg_device=0;
$sum_part=array(100);
$sum_time_device=0;
$std_dev_notre=0;
$dif=0;
$cr=0;

$s=0;
$sql1 = "SELECT distinct(id_device)  FROM a4 where no_test=". $jjj;
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
$id_device=$row1["id_device"];

$sql2 = "SELECT count(*) nombre FROM a4 where id_device=". $id_device . " and no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nombre=$row2["nombre"];

$sql2 = "SELECT device FROM a4 where id_device=". $id_device  . " and no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$device=$row2["device"];

$nom_task=$row1["task"];
$nom_device=$row1["device"];
echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';


$some=0;
$some2=0;
$sql3 = "SELECT task,temps FROM a4 where id_device=". $id_device. " and no_test=". $jjj;
$result3 = $conn->query($sql3);
while($row3 = $result3->fetch_assoc()) {
$task=$row3["task"];
$temps=$row3["temps"];
$some=$some+$temps;
echo $task . ', ' . $temps . ' seconds<br>';
//affichage des sizes des tasks
$sql5 = "SELECT size FROM tasks where task='". $task . "'";
$result5 = $conn->query($sql5);
$row5 = $result5->fetch_assoc();

$size=$row5["size"];

$some2=$some2+$size;
//echo 'Taille taches=' . $size . '<br>';
}
$s=$s+$some;
$rg_device++;
$sum_part[$rg_device]=$some;
echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
echo 'Temps total requis par cet appareil ' . $rg_device . ' seconds<br>';
if($maxspan4<$some) 
{
$maxspan4=$some;
$dev4=$device;
}

if($minspan4>$some) 
{
$minspan4=$some;
}



echo 'Taille total des taches executes ' . $some . '<br>';
 } 

for($i=1; $i<=$nb_device; $i++)
{
	$sum_time_device=$sum_time_device+Carree($sum_part[$i]-$maxspan4);
}

// $sum_time_device=$sum_time_device+$s;
echo 'Temps total par tous les appareils ' . $sum_time_device . '<br>';
// $dif=$sum_time_device-$maxspan4;
// $cr=Carree($dif);
$std_dev_notre=sqrt($sum_time_device/$nb_device);
} 
$std_dev[4]=$std_dev_notre;
echo '<br><br><b> Deviation standard de Notre Algorithme:' . $std_dev[4] . '</b><br>';

//echo '<br><br><b>Temps Total Notre Algorithme:' . $s . ' seconds</b><br>';

$sql2 = "SELECT count(id_task) nbr_task FROM a1 where no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nbr_task1=$row2["nbr_task"];

$sql2 = "SELECT count(distinct(id_device)) nbr_device FROM a1 where no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nbr_device1=$row2["nbr_device"];


$sql2 = "SELECT count(id_task) nbr_task FROM a2 where no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nbr_task2=$row2["nbr_task"];

$sql2 = "SELECT count(distinct(id_device)) nbr_device FROM a2 where no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nbr_device2=$row2["nbr_device"];

$sql2 = "SELECT count(id_task) nbr_task FROM a3 where no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nbr_task3=$row2["nbr_task"];

$sql2 = "SELECT count(distinct(id_device)) nbr_device FROM a3 where no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nbr_device3=$row2["nbr_device"];


$sql2 = "SELECT count(id_task) nbr_task FROM a4 where no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nbr_task4=$row2["nbr_task"];

$sql2 = "SELECT count(distinct(id_device)) nbr_device FROM a4 where no_test=". $jjj;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nbr_device4=$row2["nbr_device"];
$diff1=$maxspan1-$minspan1;
$diff2=$maxspan2-$minspan2;
$diff3=$maxspan3-$minspan3;
$diff4=$maxspan4-$minspan4;

$sql4 = "INSERT INTO a5(max_span,min_span,difference,device,nbr_device,nbr_task,algorithm,no_test)  VALUES ($maxspan1,$minspan1,$diff1,'$dev1',$nbr_device1,$nbr_task1,'LCF',$jjj);";
if ($conn->query($sql4) === TRUE) {
    echo "";
}

$sql4 = "INSERT INTO a5(max_span,min_span,difference,device,nbr_device,nbr_task,algorithm,no_test)  VALUES ($maxspan2,$minspan2,$diff2,'$dev2',$nbr_device2,$nbr_task2,'SCF',$jjj);";
if ($conn->query($sql4) === TRUE) {
    echo "";
}

$sql4 = "INSERT INTO a5(max_span,device,min_span,difference,nbr_device,nbr_task,algorithm,no_test)  VALUES ($maxspan3,$minspan3,$diff3,'$dev3',$nbr_device3,$nbr_task3,'Min Min',$jjj);";
if ($conn->query($sql4) === TRUE) {
    echo "";
}

$sql4 = "INSERT INTO a5(max_span,min_span,difference,device,nbr_device,nbr_task,algorithm,no_test)  VALUES ($maxspan4,$minspan4,$diff4,'$dev4',$nbr_device4,$nbr_task4,'Gassan Algorithm',$jjj);";
if ($conn->query($sql4) === TRUE) {
    echo "";
}

echo '<br><br>--------------------------------<br>';
echo '<b>GENERAL RESULTS OF INSTANCE NO ' . $jjj . '</b><br>';
echo '--------------------------------';

echo '<br><br>--------------------------------<br>';
echo '<b>Maxspan LCFP ' . $maxspan1 . '</b><br>';
echo '<b>Minspan LCFP ' . $minspan1 . '</b><br>';
echo '<b>Difference LCFP ' . $diff1 . '</b><br>';
echo '<b>Deviation LCFP ' . $std_dev[1] . '</b><br>';

echo '<br><br>--------------------------------<br>';
echo '<b>Maxspan SCFP ' . $maxspan2 . '</b><br>';
echo '<b>Minspan SCFP ' . $minspan2 . '</b><br>';
echo '<b>Difference SCFP ' . $diff2 . '</b><br>';
echo '<b>Deviation SCFP ' . $std_dev[2] . '</b><br>';

echo '<br><br>--------------------------------<br>';
echo '<b>Maxspan Min-Min ' . $maxspan3 . '</b><br>';
echo '<b>Minspan Min-Min ' . $minspan3 . '</b><br>';
echo '<b>Difference Min-Min ' . $diff3 . '</b><br>';
echo '<b>Deviation Min-Min ' . $std_dev[3] . '</b><br>';

echo '<br><br>--------------------------------<br>';
echo '<b>Maxspan Notre Algorithme ' . $maxspan4 . '</b><br>';
echo '<b>Minspan Notre Algorithme ' . $minspan4 . '</b><br>';
echo '<b>Difference Notre Algorithme ' . $diff4 . '</b><br>';
echo '<b>Deviation Notre Algorithme ' . $std_dev[4] . '</b><br>';


/*
echo '<b>Maxspan SCFP ' . $maxspan2 . '</b><br>';
echo '<b>Maxspan Min Min ' . $maxspan3 . '</b><br>';
echo '<b>Maxspan Notre Algorithm ' . $maxspan4 . '</b><br>';

echo '<b>Minspan LCFP ' . $minspan1 . '</b><br>';
echo '<b>Minspan SCFP ' . $minspan2 . '</b><br>';
echo '<b>Minspan Min Min ' . $minspan3 . '</b><br>';
echo '<b>Minspan Notre Algorithm ' . $minspan4 . '</b><br>';

echo '<b>Difference LCFP ' . $diff1 . '</b><br>';
echo '<b>Difference SCFP ' . $diff2 . '</b><br>';
echo '<b>Difference Min Min ' . $diff3 . '</b><br>';
echo '<b>Difference Notre Algorithm ' . $diff4 . '</b><br>';

echo '<br><br><b> Deviation standard de LCFP:' . $std_dev_lcfp . '</b><br>';
*/
}

?>




















