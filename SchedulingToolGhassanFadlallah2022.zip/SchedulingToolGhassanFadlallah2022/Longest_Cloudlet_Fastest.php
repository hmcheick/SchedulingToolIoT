<?php include("connection.php");
include("top.php");
//Division des devices
//-----------------------------------
//----------------------------------


$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s00=$timediff;
//---------------------------------------------
//---------------------------------------------

$some=0;
$starttime = microtime(true);


if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT id, task,size  FROM tasks where avail=0 order by size desc";
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the large devices</font></b><br><br>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT id,device FROM devices where avail=0 order by score desc limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row["task"] . "</font></b><br><br>";
}
else
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row1["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row["task"] . "</font></b><br><br>";

$sql4 = "update tasks set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update devices set avail=1 where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
}
}
}} 
$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s1=$timediff;
echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';
$starttime = microtime(true);

$sql4 = "update tasks set avail=0";
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update devices set avail=0";
if ($conn->query($sql4) === TRUE) {
    echo "";
}
?>
</body>

</html>