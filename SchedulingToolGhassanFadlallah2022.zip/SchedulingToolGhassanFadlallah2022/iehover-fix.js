/** JavaScript **/
ieHover = function() {
var ieULs1 = document.getElementById('nav1').getElementsByTagName('ul');
var ieULs2 = document.getElementById('nav2').getElementsByTagName('ul');
var ieULs3 = document.getElementById('nav3').getElementsByTagName('ul');
var ieULs4 = document.getElementById('nav4').getElementsByTagName('ul');
/** IE script to cover <select> elements with <iframe>s **/


for (j=0; j<ieULs1.length; j++) {
ieULs1[j].innerHTML = ('<iframe src="about:blank" scrolling="no" frameborder="0"></iframe>' + ieULs1[j].innerHTML);
/*ieULs[j].innerHTML = ('<iframe id="iePad' + j + '" src="about:blank" scrolling="no" frameborder="0" style=""></iframe>' + ieULs[j].innerHTML);
	var ieMat = document.getElementById('iePad' + j + '');*/
//	var ieMat = ieULs[j].childNodes[0];  alert(ieMat.nodeName); // also works...
	var ieMat = ieULs1[j].firstChild;
		ieMat.style.width=ieULs1[j].offsetWidth+"px";
		ieMat.style.height=ieULs1[j].offsetHeight+"px";	
		ieULs1[j].style.zIndex="99";
}


for (j=0; j<ieULs2.length; j++) {
ieULs2[j].innerHTML = ('<iframe src="about:blank" scrolling="no" frameborder="0"></iframe>' + ieULs2[j].innerHTML);
/*ieULs[j].innerHTML = ('<iframe id="iePad' + j + '" src="about:blank" scrolling="no" frameborder="0" style=""></iframe>' + ieULs[j].innerHTML);
	var ieMat = document.getElementById('iePad' + j + '');*/
//	var ieMat = ieULs[j].childNodes[0];  alert(ieMat.nodeName); // also works...
	var ieMat = ieULs2[j].firstChild;
		ieMat.style.width=ieULs2[j].offsetWidth+"px";
		ieMat.style.height=ieULs2[j].offsetHeight+"px";	
		ieULs2[j].style.zIndex="99";
}


for (j=0; j<ieULs3.length; j++) {
ieULs3[j].innerHTML = ('<iframe src="about:blank" scrolling="no" frameborder="0"></iframe>' + ieULs3[j].innerHTML);
/*ieULs[j].innerHTML = ('<iframe id="iePad' + j + '" src="about:blank" scrolling="no" frameborder="0" style=""></iframe>' + ieULs[j].innerHTML);
	var ieMat = document.getElementById('iePad' + j + '');*/
//	var ieMat = ieULs[j].childNodes[0];  alert(ieMat.nodeName); // also works...
	var ieMat = ieULs3[j].firstChild;
		ieMat.style.width=ieULs3[j].offsetWidth+"px";
		ieMat.style.height=ieULs3[j].offsetHeight+"px";	
		ieULs3[j].style.zIndex="99";
}


for (j=0; j<ieULs4.length; j++) {
ieULs4[j].innerHTML = ('<iframe src="about:blank" scrolling="no" frameborder="0"></iframe>' + ieULs4[j].innerHTML);
/*ieULs[j].innerHTML = ('<iframe id="iePad' + j + '" src="about:blank" scrolling="no" frameborder="0" style=""></iframe>' + ieULs[j].innerHTML);
	var ieMat = document.getElementById('iePad' + j + '');*/
//	var ieMat = ieULs[j].childNodes[0];  alert(ieMat.nodeName); // also works...
	var ieMat = ieULs4[j].firstChild;
		ieMat.style.width=ieULs4[j].offsetWidth+"px";
		ieMat.style.height=ieULs4[j].offsetHeight+"px";	
		ieULs4[j].style.zIndex="99";
}
/** IE script to change class on mouseover **/

	
	var ieLIs1 = document.getElementById('nav1').getElementsByTagName('li');
	for (var i=0; i<ieLIs1.length; i++) if (ieLIs1[i]) {
		ieLIs1[i].onmouseover=function() {this.className+=" iehover";}
		ieLIs1[i].onmouseout=function() {this.className=this.className.replace(' iehover', '');}
	}	
	
	var ieLIs2 = document.getElementById('nav2').getElementsByTagName('li');
	for (var i=0; i<ieLIs2.length; i++) if (ieLIs2[i]) {
		ieLIs2[i].onmouseover=function() {this.className+=" iehover";}
		ieLIs2[i].onmouseout=function() {this.className=this.className.replace(' iehover', '');}
	}	
	
	
	var ieLIs3 = document.getElementById('nav3').getElementsByTagName('li');
	for (var i=0; i<ieLIs3.length; i++) if (ieLIs3[i]) {
		ieLIs3[i].onmouseover=function() {this.className+=" iehover";}
		ieLIs3[i].onmouseout=function() {this.className=this.className.replace(' iehover', '');}
	}
	
	var ieLIs4 = document.getElementById('nav4').getElementsByTagName('li');
	for (var i=0; i<ieLIs4.length; i++) if (ieLIs4[i]) {
		ieLIs4[i].onmouseover=function() {this.className+=" iehover";}
		ieLIs4[i].onmouseout=function() {this.className=this.className.replace(' iehover', '');}
	}	
	}
if (window.attachEvent) window.attachEvent('onload', ieHover);
/** end **/