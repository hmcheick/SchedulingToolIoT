<?php include("connection.php");
include("top.php");
$sql5 = "delete from small_devices;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from meduim_devices;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from large_devices;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
//begin of small division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
echo "<br><b><font color='red'>Your small divison of devices is begin successfully" . "</font></b><br>";
$sql = "SELECT * FROM devices where score>0 and score<10";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - device: " . $row["device"]. " - score: " . $row["score"]. "<br>";
$device=$row["device"];
$score=$row["score"];
$sql4 = "INSERT INTO small_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 

//begin of meduim division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
echo "<b><font color='red'>Your meduim divison of devices is begin successfully" . "</font></b><br>";
$sql1 = "SELECT * FROM devices where score>=10 and score<20";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
        echo "id: " . $row1["id"]. " - device: " . $row1["device"]. " - score: " . $row1["score"]. "<br>";
$device=$row1["device"];
$score=$row1["score"];
$sql5 = "INSERT INTO meduim_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql5) === TRUE) {
    echo "";
} } } 

//begin of large division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
echo "<b><font color='red'>Your large divison of devices is begin successfully" . "</font></b><br>";
$sql2 = "SELECT * FROM devices where score>=20";
$result2 = $conn->query($sql2);

if ($result2->num_rows > 0) {
    // output data of each row
    while($row2 = $result2->fetch_assoc()) {
        echo "id: " . $row2["id"]. " - device: " . $row2["device"]. " - score: " . $row2["score"]. "<br>";
$device=$row2["device"];
$score=$row2["score"];
$sql4 = "INSERT INTO large_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 
$conn->close();
?>

</table>	

          </FORM>

</body>

</html>