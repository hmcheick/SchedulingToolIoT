<?php include("connection.php");
$ajouter=$_GET["ajouter"];
if($ajouter=="1")
{


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$task=str_replace("'","''",$_POST["task"]);
$taille=str_replace("'","''",$_POST["taille"]);
$sql = "INSERT INTO tasks(task,size) VALUES ('$task',$taille);";
if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();

echo "<script language='javascript'>window.location='add_task.php?ajouter=2' </script>";

}

include("top.php");

if($ajouter=="2")
{
echo "<br><br><center><b><font color='red'>Your new task is added successfully" . "</font></b><br><br></center>";
}
?>

</head>

<body onload="navBarInit()"  bgcolor="#C0C0C0">

<form name="form1" method="POST" action="add_task.php?ajouter=1">
<center><b><font color="blue">Add task</font></b></center>
  <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="98%" id="AutoNumber1">
    <tr>
      <td width="50%" colspan="2">
      &nbsp;</td>
      </tr>
   
 
    <tr>
      <td width="50%" colspan="2">Task
      &nbsp;&nbsp;&nbsp;<input type="text" name="task" size="20" value="T">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      Score
      &nbsp;&nbsp;<input type="text" name="taille" size="20" value="0">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="submit" value="Send" name="B1"><input type="reset" value="Clear" name="B2"></td>
    </td>
      </tr>

  </table>
  <br>
  
  
</form>

</body>

</html>