<form method="post" action="compare-algorithms.php">
Nombre de taches:<input type="text" name="tasko" value='0'>
Nombre de devices:<input type="text" name="devico" value='0'>
<input type="submit" name="idtest" value='Faire la comparaison'>
<br><br><br>





<?php
/* Ce block si on veut arranger le fichier text par ordre decroissant
on utlise qsort pour arranger par ordre decroissant et sort pour arranger par ordre croissant
$fichier = fopen('tasks.txt','r');
$i=0;
while($ligne = fgets($fichier)) 
{
$liste[$i] = $ligne;
$i++;
}
//la fonction rsort 
rsort($liste);
$i=0;
while(isset($liste[$i])) 
{
echo $liste[$i],"<br />";
$i++;
}
fclose($fichier);

*/

?>

<?php include("connection.php");
include("top.php");
$C1=0;$C2=0;$C3=0;
if($_POST['tasko']=='')
{
$nbrtask=1;
$nbrdevice=1;
}
else
{
$nbrtask=$_POST['tasko'];
$nbrdevice=$_POST['devico'];
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from devices";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from large_devices";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from meduim_devices";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from small_devices";
if ($conn->query($sql4) === TRUE) {
echo "";
}


    // Nom du fichier à ouvrir
    $fichier = file("devices.txt");
    // Nombre total de ligne du fichier
    $total = count($fichier);

    for($i = 0; $i < $total; $i++) {
    // On affiche ligne par ligne le contenu du fichier
    // avec la fonction nl2br pour ajouter les sauts de lignes
   // echo $fichier[$i] . '<br>';
$tt=explode(" ", $fichier[$i]);
$sql = "INSERT INTO devices(device,score,avail) VALUES ('$tt[0]',$tt[1],0);";

if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}




    }





if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from large_tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from meduim_tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from small_tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

    // Nom du fichier à ouvrir
    $fichier = file("tasks.txt");
    // Nombre total de ligne du fichier
    $total = count($fichier);

    for($i = 0; $i < $total; $i++) {
    // On affiche ligne par ligne le contenu du fichier
    // avec la fonction nl2br pour ajouter les sauts de lignes
   // echo $fichier[$i] . '<br>';
$tt=explode(" ", $fichier[$i]);
$sql = "INSERT INTO tasks(task,size,avail) VALUES ('$tt[0]',$tt[1],0);";
if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}




    }





//Division des devices
//-----------------------------------
//----------------------------------
$starttime = microtime(true);
$sql5 = "delete from small_devices;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from meduim_devices;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from large_devices;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
//begin of small division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
echo "<br><b><font color='red'>Your small divison of devices is begin successfully" . "</font></b><br>";
$sql = "SELECT * FROM devices where score>0 and score<10 limit " .$nbrdevice;
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - device: " . $row["device"]. " - score: " . $row["score"]. "<br>";
$device=$row["device"];
$score=$row["score"];
$sql4 = "INSERT INTO small_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 

//begin of meduim division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
echo "<b><font color='red'>Your meduim divison of devices is begin successfully" . "</font></b><br>";
$sql1 = "SELECT * FROM devices where score>=10 and score<20 limit " .$nbrdevice;
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
        echo "id: " . $row1["id"]. " - device: " . $row1["device"]. " - score: " . $row1["score"]. "<br>";
$device=$row1["device"];
$score=$row1["score"];
$sql5 = "INSERT INTO meduim_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql5) === TRUE) {
    echo "";
} } } 

//begin of large division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
echo "<b><font color='red'>Your large divison of devices is begin successfully" . "</font></b><br>";
$sql2 = "SELECT * FROM devices where score>=20 limit " .$nbrdevice;
$result2 = $conn->query($sql2);

if ($result2->num_rows > 0) {
    // output data of each row
    while($row2 = $result2->fetch_assoc()) {
        echo "id: " . $row2["id"]. " - device: " . $row2["device"]. " - score: " . $row2["score"]. "<br>";
$device=$row2["device"];
$score=$row2["score"];
$sql4 = "INSERT INTO large_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 

$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s0=$timediff;
//---------------------------------------------
//---------------------------------------------

//Division des taches
//-----------------------------------
//----------------------------------
$starttime = microtime(true);

$sql5 = "delete from small_tasks;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from meduim_tasks;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from large_tasks;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
//begin of small division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
echo "<br><b><font color='red'>Your small divison of tasks is begin successfully" . "</font></b><br>";
$sql = "SELECT * FROM tasks where size>0 and size<10 limit " .$nbrtask;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - task: " . $row["task"]. " - size: " . $row["size"]. "<br>";
$task=$row["task"];
$size=$row["size"];
$sql4 = "INSERT INTO small_tasks(task,size,avail) VALUES ('$task',$size,0);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 

//begin of meduim division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
echo "<b><font color='red'>Your meduim divison of tasks is begin successfully" . "</font></b><br>";
$sql1 = "SELECT * FROM tasks where size>=10 and size<20 limit " .$nbrtask;
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
        echo "id: " . $row1["id"]. " - task: " . $row1["task"]. " - size: " . $row1["size"]. "<br>";
$task=$row1["task"];
$size=$row1["size"];
$sql5 = "INSERT INTO meduim_tasks(task,size,avail) VALUES ('$task',$size,0);";
if ($conn->query($sql5) === TRUE) {
    echo "";
} } } 

//begin of large division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
echo "<b><font color='red'>Your large divison of tasks is begin successfully" . "</font></b><br>";
$sql2 = "SELECT * FROM tasks where size>=20 limit " .$nbrtask;
$result2 = $conn->query($sql2);

if ($result2->num_rows > 0) {
    // output data of each row
    while($row2 = $result2->fetch_assoc()) {
        echo "id: " . $row2["id"]. " - task: " . $row2["task"]. " - size: " . $row2["size"]. "<br>";
$task=$row2["task"];
$size=$row2["size"];
$sql4 = "INSERT INTO large_tasks(task,size,avail) VALUES ('$task',$size,0);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 





$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s00=$timediff;
//---------------------------------------------
//---------------------------------------------

$some=0;
$starttime = microtime(true);

//begin of seach in the large devices
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT id, task,size  FROM large_tasks where avail=0 order by size ";
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the large devices</font></b><br><br>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT id,device FROM large_devices where avail=0 order by score limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($id1=='') {
echo "<b><font color='blue'>We didn't find any device available to do the task</font><font color='red'> " . $row["task"] . "</font></b><br><br>";
}
else
{
$C1=$C1+1;
echo "<b><font color='blue'>the device </font><font color='red'>" . $row1["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row["task"] . "</font></b><br><br>";

$sql4 = "update large_tasks set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update large_devices set avail=1 where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
}
}
}} 
$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s1=$timediff;
$D1=$timediff;
//echo '<b>The search time in the large devices is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';
$starttime = microtime(true);

//begin of seach in the meduim devices
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT id, task,size  FROM meduim_tasks where avail=0 order by size ";
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the meduim devices</font></b><br><br>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT id,device FROM meduim_devices where avail=0 order by score limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row["task"] . "</font></b><br><br>";
$medi=1;
}
else
{
$C2=$C2+1;
echo "<b><font color='blue'>the device </font><font color='red'>" . $row1["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row["task"] . "</font></b><br><br>";
$sql4 = "update meduim_tasks set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update meduim_devices set avail=1 where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
   echo "";
}
}
}} 


//On cherche une dans la large device pour la tache meduim
//Si on a encore des taches dans meduim 
//--------------------------------------------------------
//--------------------------------------------------------
//--------------------------------------------------------
//--------------------------------------------------------
if ($medi==1) {
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT id, task,size  FROM meduim_tasks where avail=0 order by size ";
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the large devices to find some avalaibility for the meduim tasks</font></b><br><br>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT id,device FROM large_devices where avail=0 order by score limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row["task"] . "</font></b><br><br>";
}
else
{
$C3=$C3+1;
echo "<b><font color='blue'>the device </font><font color='red'>" . $row1["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row["task"] . "</font></b><br><br>";
$sql4 = "update meduim_tasks set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update large_devices set avail=1 where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
}
}
}} 

} 
$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s2=$timediff;
$D2=$timediff;
//echo '<b>The search time in the meduim devices is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';
$starttime = microtime(true);
//--------------------------------------------------------
//--------------------------------------------------------
//--------------------------------------------------------
//--------------------------------------------------------

//begin of seach in the large devices
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT id, task,size  FROM small_tasks where avail=0 order by size ";
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the small devices</font></b><br><br>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT id,device FROM small_devices where avail=0 order by score limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($id1=='')  {
$medi1=1;
echo "<b><font color='blue'>We didn't find any device available to do the task</font><font color='red'> " . $row["task"] . "</font></b><br><br>";
}
else
 {
$C4=$C4+1;
echo "<b><font color='blue'>the device </font><font color='red'>" . $row1["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row["task"] . "</font></b><br><br>";

$sql4 = "update small_tasks set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
   echo "";
} 
$sql4 = "update small_devices set avail=1 where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
}
}
}} 

//On cherche une dans la meduim device pour la tache small
//dans meduim si no trouve c'est correct, si on trouve pas on 
//cherche dans grande devices
//--------------------------------------------------------
//--------------------------------------------------------
//--------------------------------------------------------
//--------------------------------------------------------
if ($medi1==1) {
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT id, task,size  FROM small_tasks where avail=0 order by size ";
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the meduim devices to find some avalaibility for the small tasks</font></b><br><br>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT id,device FROM meduim_devices where avail=0 order by score limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];

if ($id1=='') {
$medi2=1;
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row["task"] . "</font></b><br><br>";
}
else
{
$C5=$C5+1;
echo "<b><font color='blue'>the device </font><font color='red'>" . $row1["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row["task"] . "</font></b><br><br>";
$sql4 = "update small_tasks set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update meduim_devices set avail=1 where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
}
}


}
}} 

 

//--------------------------------------------------------
//--------------------------------------------------------
//--------------------------------------------------------
//--------------------------------------------------------




//On cherche une dans la large device pour la tache small
//dans meduim si no trouve c'est correct, si on trouve pas on 
//cherche dans grande devices
//--------------------------------------------------------
//--------------------------------------------------------
//--------------------------------------------------------
//--------------------------------------------------------
if ($medi2==1) {
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT id, task,size  FROM small_tasks where avail=0 order by size ";
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the large devices to find some avalaibility for the small tasks</font></b><br><br>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT id,device FROM large_devices where avail=0 order by score limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row["task"] . "</font></b><br><br>";
}
else
{
$C6=$C6+1;
echo "<b><font color='blue'>the device </font><font color='red'>" . $row1["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row["task"] . "</font></b><br><br>";
$sql4 = "update small_tasks set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update large_devices set avail=1 where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
}
}
}} 

} 

//--------------------------------------------------------
//--------------------------------------------------------
//--------------------------------------------------------
//--------------------------------------------------------

$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s3=$timediff;
echo '<b>The divsion time of devices for three groups  small, meduim is ' .  number_format((float)$s0, 6, '.', '') . ' seconds</b><br>';
echo '<b>The divsion time of tasks for three groups  small, meduim is ' .  number_format((float)$s00, 6, '.', '') . ' seconds</b><br>';
echo '<b>The search time in the large devices is ' .  number_format((float)$s1, 6, '.', '') . ' seconds</b><br>';
echo '<b>The search time in the meduim devices is ' .  number_format((float)$s2, 6, '.', '') . ' seconds</b><br>';
echo '<b>The search time in the small devices is ' .  number_format((float)$s3, 6, '.', '') . ' seconds</b><br>';
echo '<b>The total search time is ' .  number_format((float)$some, 6, '.', '') . ' seconds</b><br><br><br>';
$some50=$some;
$sql4 = "update meduim_tasks set avail=0";
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update large_devices set avail=0";
if ($conn->query($sql4) === TRUE) {
    echo "";
}




$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s00=$timediff;
//---------------------------------------------
//---------------------------------------------

$some=0;
$starttime = microtime(true);


if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT id, task,size  FROM tasks where avail=0 order by size desc limit " .$nbrtask;;
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the large devices</font></b><br><br>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT id,device FROM devices where avail=0 order by score desc limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row["task"] . "</font></b><br><br>";
}
else
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row1["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row["task"] . "</font></b><br><br>";

$sql4 = "update tasks set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update devices set avail=1 where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
}
}
}} 
$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s1=$timediff;
echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';
$starttime = microtime(true);

$sql4 = "update tasks set avail=0";
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update devices set avail=0";
if ($conn->query($sql4) === TRUE) {
    echo "";
}
$some51=$timediff;




$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s00=$timediff;
//---------------------------------------------
//---------------------------------------------

$some=0;
$starttime = microtime(true);


if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT id, task,size  FROM tasks where avail=0 order by size asc limit " .$nbrtask;
$result = $conn->query($sql);
echo "<br><b><font color='green'>Shortest Cloudlet Fatest Algorithm</font></b><br><br>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT id,device FROM devices where avail=0 order by score desc limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row["task"] . "</font></b><br><br>";
}
else
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row1["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row["task"] . "</font></b><br><br>";

$sql4 = "update tasks set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update devices set avail=1 where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
}
}
}} 
$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s1=$timediff;
echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';
$starttime = microtime(true);

$sql4 = "update tasks set avail=0";
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update devices set avail=0";
if ($conn->query($sql4) === TRUE) {
    echo "";
}

$some52=$timediff;



$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s00=$timediff;
//---------------------------------------------
//---------------------------------------------

$some=0;
$starttime = microtime(true);


if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT id, task,size  FROM tasks where avail=0 order by size desc limit " .$nbrtask;
$result = $conn->query($sql);
echo "<br><b><font color='green'>algorithem Min Min</font></b><br><br>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT id,device FROM devices where avail=0 order by score desc limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row["task"] . "</font></b><br><br>";
}
else
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row1["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row["task"] . "</font></b><br><br>";

$sql4 = "update tasks set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update devices set avail=1 where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
}
}
}} 
$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s1=$timediff;
echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';
$starttime = microtime(true);

$sql4 = "update tasks set avail=0";
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
$sql4 = "update devices set avail=0";
if ($conn->query($sql4) === TRUE) {
    echo "";
}
$some53=$timediff;
echo '<br><br><br>';
$some60=$_POST['tasko'];
$some61=$_POST['devico'];
echo '<font color=red><b>The tasks number is ' . $some60. '</b></font><br>';
echo '<font color=red><b>The devices number is ' .  $some61. '</b></font><br>';
echo '<font color=red><b>The search time  for our algorithm is ' .  number_format((float)$some50, 6, '.', '') . ' seconds</b></font><br>';
echo '<font color=red><b>The search time  for the  Longest Cloudlet Fastest  algorithm is ' .  number_format((float)$some51, 6, '.', '') . ' seconds</b></font><br>';
echo '<font color=red><b>The search time  for the Shortest Cloudlet Fastest algorithm is ' .  number_format((float)$some52, 6, '.', '') . ' seconds</b></font><br>';
echo '<font color=red><b>The search time  for Min Min algorithm is ' .  number_format((float)$some53, 6, '.', '') . ' seconds</b></font><br>';

?>


</body>

</html>





