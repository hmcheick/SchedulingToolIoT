
<?php include("connection.php");
/*Ce script est pour initialiser les données, 
on doit l'executer avant chaque algorithme pour reinitialiser
les taches et les devices, on utilise les deux fichiers devices.txt et tasks.txt
ces deux fichiers contiennent les devices et les taches à executé
*/
include("top.php");


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from large_tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from meduim_tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from small_tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

    // Nom du fichier des taches
    $fichier = file("tasks.txt");
    // Nombre total de ligne du fichier
    $total = count($fichier);
        if($_POST[tasko]!='') { $total=$_POST[tasko]; }
    for($i = 0; $i < $total; $i++) {
    // On affiche ligne par ligne le contenu du fichier
    // avec la fonction nl2br pour ajouter les sauts de lignes
   // echo $fichier[$i] . '<br>';
$tt=explode(" ", $fichier[$i]);
$sql = "INSERT INTO tasks(task,size,avail) VALUES ('$tt[0]',$tt[1],0);";
if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}




    }


?>


</body>

</html>


