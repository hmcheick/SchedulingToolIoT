<?php include("connection.php");
include("top.php");
//Ce script pour afficher le temps de recherche de chaque algorithme, il stocke tous les résultats des
//tests dans le fichier computation.txt, donc on peut faire des centaines des tests et apres on ouvre le 
//fichier text computation.txt pour chercher les temps de recherche données poutr chaque algorithme et
//dans chaque test
$myfile = fopen("computation.txt", "a");
$some1=0;
$fichier = file("lcf.txt");
$total = count($fichier);
for($i = 0; $i < $total; $i++) {
$some1=$some1+$fichier[$i];
 }

echo 'The computation time for lcf algorithm is ' . round($some1, 4) . ' seconds<br>';
$a='The computation time for lcf algorithm is ' . round($some1, 4) . ' seconds';
fwrite($myfile, $a);
$a = "\n";
fwrite($myfile, $a);

$some1=0;
$fichier = file("scf.txt");
$total = count($fichier);
for($i = 0; $i < $total; $i++) {
$some1=$some1+$fichier[$i];
 }

echo 'The computation time for scf algorithm is ' . round($some1, 4) . ' seconds<br>';
$a='The computation time for scf algorithm is ' . round($some1, 4) . ' seconds';
fwrite($myfile, $a);
$a = "\n";
fwrite($myfile, $a);


$some1=0;
$fichier = file("minmin.txt");
$total = count($fichier);
for($i = 0; $i < $total; $i++) {
$some1=$some1+$fichier[$i];
 }

echo 'The computation time for min min algorithm is ' . round($some1, 4) . ' seconds<br>';
$a='The computation time for min min algorithm is ' . round($some1, 4) . ' seconds';
fwrite($myfile, $a);
$a = "\n";
fwrite($myfile, $a);


$some1=0;
$fichier = file("ghassanalgo.txt");
$total = count($fichier);
for($i = 0; $i < $total; $i++) {
$some1=$some1+$fichier[$i];
 }

echo 'The computation time for our algorithm is ' . round($some1, 4) . ' seconds<br>';
$a='The computation time for our algorithm is ' . round($some1, 4) . ' seconds';
fwrite($myfile, $a);
$a = "\n";
fwrite($myfile, $a);
$a='------------------------------------------------------------------------------';
fwrite($myfile, $a);
$a = "\n";
fwrite($myfile, $a);

fopen("lcf.txt", "w+");
fopen("scf.txt", "w+");
fopen("minmin.txt", "w+");
fopen("ghassanalgo.txt", "w+");


?>






