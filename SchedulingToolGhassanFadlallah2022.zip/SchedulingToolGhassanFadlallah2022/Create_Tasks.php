<?php
include("top.php"); 
?>
<form method="post" action="compare-algorithms000.php">
Nombre de taches:<input type="text" name="tasko" value='0'>
<input type="submit" name="idtest" value='Generer le liste de taches'>
<br><br><br>





<?php
$nbrtask=$_POST['tasko'];

if($_POST['tasko']!='')
{
$fichier = fopen('tasks.txt','w');
for($i = 0; $i < $nbrtask; $i++) {
$k=$i+1;
$temps=rand(1,250) /10;
$tok="TA" . $k . " " . $temps. "\r\n";
fwrite($fichier, $tok);
//fwrite($fichier, '\n');
echo $tok . '<br>';
}
fclose($fichier);
}




if($_POST['tasko']!='') 
{
echo '<b>Votre liste de taches est genere</b><br>';
}

?>


</body>

</html>





