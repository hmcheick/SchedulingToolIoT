<?php
include("top.php"); 
?>
<form method="post" action="compare-algorithms00.php">
Nombre de devices:<input type="text" name="devico" value='0'>

<input type="submit" name="idtest" value='Generer le liste de devices'>
<br><br><br>





<?php
$nbrdevice=$_POST['devico'];

if($_POST['devico']!='')
{
$fichier = fopen('devices.txt','w');
for($i = 0; $i < $nbrdevice; $i++) {
$score=rand(1,300) /10;
$k=$i+1;
$tok="DE" . $k . " " . $score. "\r\n";
fwrite($fichier, $tok);
//fwrite($fichier, '\n');
echo $tok . '<br>';
}
//$k=$i+1;
//$score=rand(310,510) /10;
//$tok="DE" . $k . " " . $score. "\r\n";
//echo $tok . '<br>';
//fwrite($fichier, $tok);
//fclose($fichier);
}

if($_POST['devico']!='') 
{
echo '<b>Votre liste de devices et genere</b>';
}

?>


</body>

</html>





