<?php include("connection.php");
include("top.php");



$requete1= "SELECT * FROM devices";

$curseur1 = @mysql_query($requete1) Or die("Impossible de s�lectionner le contenu de la requete");	
while( $un_element = mysql_fetch_array($curseur1))
{
if ($un_element["score"]>0 and $un_element["score"]<=10)
{

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$device=str_replace("'","''",$_POST["device"]);
$score=str_replace("'","''",$_POST["score"]);
$sql = "INSERT INTO devices(device,score) VALUES ('$device',$score);";
if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();

}

if ($un_element["score"]>10 and $un_element["score"]<=20)
{
$device=str_replace("'","''",$un_element["device"]);
$score=str_replace("'","''",$un_element["score"]);
$sql = "INSERT INTO meduim_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}

if ($un_element["score"]>20 and $un_element["score"]<=30)
{
$device=str_replace("'","''",$un_element["device"]);
$score=str_replace("'","''",$un_element["score"]);
$sql = "INSERT INTO large_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}

$conn->close();

}
echo "<br><br><center><b><font color='red'>Your small divison of devices is was successfully" . "</font></b><br><br></center>";
echo "<br><br><center><b><font color='red'>Your meduim divison of devices is was successfully" . "</font></b><br><br></center>";
echo "<br><br><center><b><font color='red'>Your large divison of devices is was successfully" . "</font></b><br><br></center>";
?>

</table>	

          </FORM>

</body>

</html>