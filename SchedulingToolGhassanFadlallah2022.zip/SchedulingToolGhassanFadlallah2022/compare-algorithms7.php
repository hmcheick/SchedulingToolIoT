<?php
header("refresh: 10"); 
//on utilise 10 seconds pour ré-executer des nouvelles taches
//on peut mettre 20 seconds, 30 seconds ou autre
//Ce script execute le lcf algorithme, on doit attendre qu'il execute tous les taches qui sont
//dans le fichier tasks.txt
include("connection.php");
include("top.php");
$ss1=0;
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT devices.id id,tasks.id id1,score,size,device,task   FROM devices, tasks where size>1.3*score and size<1.7*score order by score desc";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

$starttime = microtime(true);
    // output data of each row
    while($row = $result->fetch_assoc()) {
echo 'dddddd';
$id=$row["id"];
$id1=$row["id1"];
echo 'aaaaaaaaaaaaaa=' . $row["size"];
$ss1=1;

echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row["task"] . "</font></b><br><br>";

$sql4 = "delete from tasks where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 



}
}
$endtime = microtime(true);
$timediff = $endtime - $starttime;

if ($ss1==0)
{
echo '<b>All the tasks are executed</b>';
}
else
{
echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';





$endtime = microtime(true);
$timediff = $endtime - $starttime;
//ecrire tout le temps de calcul dans un fichier text
$myfile = fopen("lcf.txt", "a") or die("Unable to open file!");
$txt =$timediff;
fwrite($myfile, $txt);
$txt = "\n";
fwrite($myfile, $txt);
fclose($myfile);
}



?>






