<?php include("connection.php");
include("top.php");
echo '<br><br>--------------------------------<br>';
echo '<b>Resultats LSF</b><br>';
echo '--------------------------------';
$s=0;
$sql1 = "SELECT distinct(id_device)  FROM a1";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
$id_device=$row1["id_device"];

$sql2 = "SELECT count(*) nombre FROM a1 where id_device=". $id_device;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nombre=$row2["nombre"];

$sql2 = "SELECT device FROM a1 where id_device=". $id_device;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$device=$row2["device"];

$nom_task=$row1["task"];
$nom_device=$row1["device"];
echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';


$some=0;
$sql3 = "SELECT task,temps FROM a1 where id_device=". $id_device;
$result3 = $conn->query($sql3);
while($row3 = $result3->fetch_assoc()) {
$task=$row3["task"];
$temps=$row3["temps"];
$some=$some+$temps;
echo $task . ', ' . $temps . ' seconds<br>';
}
$s=$s+$some;
echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
echo 'Temps total requis par cet appareil ' . $some . ' seconds<br>';
 } } 

//echo '<br><br><b>Temps Total LSF:' . $s . ' seconds</b><br>';
?>


<?php 

echo '<br><br>--------------------------------<br>';
echo '<b>Resultats SCF</b><br>';
echo '--------------------------------';
$s=0;
$sql1 = "SELECT distinct(id_device)  FROM a2";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
$id_device=$row1["id_device"];

$sql2 = "SELECT count(*) nombre FROM a2 where id_device=". $id_device;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nombre=$row2["nombre"];

$sql2 = "SELECT device FROM a2 where id_device=". $id_device;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$device=$row2["device"];

$nom_task=$row1["task"];
$nom_device=$row1["device"];
echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';


$some=0;
$sql3 = "SELECT task,temps FROM a2 where id_device=". $id_device;
$result3 = $conn->query($sql3);
while($row3 = $result3->fetch_assoc()) {
$task=$row3["task"];
$temps=$row3["temps"];
$some=$some+$temps;
echo $task . ', ' . $temps . ' seconds<br>';
}
$s=$s+$some;
echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
echo 'Temps total requis par cet appareil ' . $some . ' seconds<br>';
 } } 

//echo '<br><br><b>Temps Total SCF:' . $s . ' seconds</b><br>';
?>



<?php 

echo '<br><br>--------------------------------<br>';
echo '<b>Resultats Min Min</b><br>';
echo '--------------------------------';
$s=0;
$sql1 = "SELECT distinct(id_device)  FROM a3";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
$id_device=$row1["id_device"];

$sql2 = "SELECT count(*) nombre FROM a3 where id_device=". $id_device;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nombre=$row2["nombre"];

$sql2 = "SELECT device FROM a3 where id_device=". $id_device;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$device=$row2["device"];

$nom_task=$row1["task"];
$nom_device=$row1["device"];
echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';


$some=0;
$sql3 = "SELECT task,temps FROM a3 where id_device=". $id_device;
$result3 = $conn->query($sql3);
while($row3 = $result3->fetch_assoc()) {
$task=$row3["task"];
$temps=$row3["temps"];
$some=$some+$temps;
echo $task . ', ' . $temps . ' seconds<br>';
}
$s=$s+$some;
echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
echo 'Temps total requis par cet appareil ' . $some . ' seconds<br>';
 } } 

//echo '<br><br><b>Temps Total Min Min:' . $s . ' seconds</b><br>';
?>

<?php 
echo '<br><br>--------------------------------<br>';
echo '<b>Resultats Notre Algorithme<</b><br>';
echo '--------------------------------';

$s=0;
$sql1 = "SELECT distinct(id_device)  FROM a4";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
$id_device=$row1["id_device"];

$sql2 = "SELECT count(*) nombre FROM a4 where id_device=". $id_device;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$nombre=$row2["nombre"];

$sql2 = "SELECT device FROM a4 where id_device=". $id_device;
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$device=$row2["device"];

$nom_task=$row1["task"];
$nom_device=$row1["device"];
echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';


$some=0;
$sql3 = "SELECT task,temps FROM a4 where id_device=". $id_device;
$result3 = $conn->query($sql3);
while($row3 = $result3->fetch_assoc()) {
$task=$row3["task"];
$temps=$row3["temps"];
$some=$some+$temps;
echo $task . ', ' . $temps . ' seconds<br>';
}
$s=$s+$some;
echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
echo 'Temps total requis par cet appareil ' . $some . ' seconds<br>';
 } } 

//echo '<br><br><b>Temps Total Notre Algorithme:' . $s . ' seconds</b><br>';
?>




















