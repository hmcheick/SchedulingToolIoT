<?php
header("refresh: 10"); 
//on utilise 10 seconds pour ré-executer des nouvelles taches
//on peut mettre 20 seconds, 30 seconds ou autre
//Ce script execute notre algorithme, on doit attendre qu'il execute tous les taches qui sont
//dans le fichier tasks.txt, nous avons utilisé notre méthode de recherche dans les trois
//fichier large_tasks, meduim_tasks et small_tasks, ils utilisent large_devices, meduim_devices et small_devices
include("connection.php");
include("top.php");
$some=0;
$ss1=0;
$k=0;
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
//--------------------------------
//--------------------------------
$sql4 = "update large_devices set avail=0";
if ($conn->query($sql4) === TRUE) {
    echo "";
} 

$sql4 = "update meduim_devices set avail=0";
if ($conn->query($sql4) === TRUE) {
    echo "";
} 

$sql4 = "update small_devices set avail=0";
if ($conn->query($sql4) === TRUE) {
    echo "";
} 


//-------------------------------
//-------------------------------
$sql = "SELECT *  FROM large_devices where avail=0";
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the large devices</font></b><br><br>";
if ($result->num_rows > 0) {
$some=1;
$starttime = microtime(true);
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT * FROM large_tasks where size<=" . $row["score"] . " limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];

if ($result1->num_rows > 0) {
$ss1=1;
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
}
elseif($row1["size"]<=$row["score"])
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
$id_device=$row["id"];
$nom_device=$row["device"];
$id_task=$row1["id"];
$nom_task=$row1["task"];
$id_task=$row1["id"];
$temps=$row1["temps"];
$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps);";
if ($conn->query($sql4) === TRUE) {
    echo "";
}
$sql4 = "delete from large_tasks where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 

$sql4 = "update large_devices set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 

} 


}

}
$endtime = microtime(true);
$timediff = $endtime - $starttime;
$k=$k+$timediff;


}
//--------------------------------------------------------
//--------------------------------------------------------

$sql = "SELECT *  FROM large_devices where avail=0";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
$some=1;
$starttime = microtime(true);
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT * FROM meduim_tasks where size<=" . $row["score"] . " limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($result1->num_rows > 0) {
$ss1=1;
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
}
elseif($row1["size"]<=$row["score"])
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
$id_device=$row["id"];
$nom_device=$row["device"];
$id_task=$row1["id"];
$nom_task=$row1["task"];
$id_task=$row1["id"];
$temps=$row1["temps"];
$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps);";
if ($conn->query($sql4) === TRUE) {
    echo "";
}
$sql4 = "delete from meduim_tasks where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 

$sql4 = "update large_devices set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 

} 


}

}
$endtime = microtime(true);
$timediff = $endtime - $starttime;
$k=$k+$timediff;
}
//--------------------------------------------------------
//--------------------------------------------------------

$sql = "SELECT *  FROM large_devices where avail=0";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
$some=1;
$starttime = microtime(true);
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT * FROM small_tasks where size<=" . $row["score"] . "  limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($result1->num_rows > 0) {
$ss1=1;
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
}
elseif($row1["size"]<=$row["score"])
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
$id_device=$row["id"];
$nom_device=$row["device"];
$id_task=$row1["id"];
$nom_task=$row1["task"];
$id_task=$row1["id"];
$temps=$row1["temps"];
$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps);";
if ($conn->query($sql4) === TRUE) {
    echo "";
}
$sql4 = "delete from small_tasks where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 

$sql4 = "update large_devices set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 

} 


}

}
$endtime = microtime(true);
$timediff = $endtime - $starttime;
$k=$k+$timediff;
}
//--------------------------------------------------------
//--------------------------------------------------------

$sql = "SELECT *  FROM meduim_devices where avail=0";
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the meduim devices</font></b><br><br>";
if ($result->num_rows > 0) {
$some=1;
$starttime = microtime(true);
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT * FROM meduim_tasks where size<=" . $row["score"] . " limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($result1->num_rows > 0) {
$ss1=1;
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
}
elseif($row1["size"]<=$row["score"])
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
$id_device=$row["id"];
$nom_device=$row["device"];
$id_task=$row1["id"];
$nom_task=$row1["task"];
$id_task=$row1["id"];
$temps=$row1["temps"];
$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps);";
if ($conn->query($sql4) === TRUE) {
    echo "";
}
$sql4 = "delete from meduim_tasks where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 

$sql4 = "update meduim_devices set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 

} 


}
}
$endtime = microtime(true);
$timediff = $endtime - $starttime;
$k=$k+$timediff;
}

//--------------------------------------------------------
//--------------------------------------------------------

$sql = "SELECT *  FROM meduim_devices where avail=0";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
$some=1;
$starttime = microtime(true);
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT * FROM small_tasks where size<=" . $row["score"] . " limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($result1->num_rows > 0) {
$ss1=1;
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
}
elseif($row1["size"]<=$row["score"])
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
$id_device=$row["id"];
$nom_device=$row["device"];
$id_task=$row1["id"];
$nom_task=$row1["task"];
$id_task=$row1["id"];
$temps=$row1["temps"];
$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps);";
if ($conn->query($sql4) === TRUE) {
    echo "";
}
$sql4 = "delete from small_tasks where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 

$sql4 = "update meduim_devices set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 

} 


}

}
$endtime = microtime(true);
$timediff = $endtime - $starttime;
$k=$k+$timediff;
}
$sql = "SELECT *  FROM small_devices where avail=0";
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the small devices</font></b><br><br>";
if ($result->num_rows > 0) {
$starttime = microtime(true);
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT * FROM small_tasks where size<=" . $row["score"] . "  limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($result1->num_rows > 0) {
$ss1=1;
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
}
elseif($row1["size"]<=$row["score"])
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
$id_device=$row["id"];
$nom_device=$row["device"];
$id_task=$row1["id"];
$nom_task=$row1["task"];
$id_task=$row1["id"];
$temps=$row1["temps"];
$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps);";
if ($conn->query($sql4) === TRUE) {
    echo "";
}
$sql4 = "delete from small_tasks where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 

$sql4 = "update small_devices set avail=1 where id=" . $id;
if ($conn->query($sql4) === TRUE) {
    echo "";
}  
} 


}
}
$endtime = microtime(true);
$timediff = $endtime - $starttime;
$k=$k+$timediff;
}

if ($ss1==1)  {

echo '<b>The search time  is ' .  number_format((float)$k, 6, '.', '') . ' seconds</b><br>';


//ecrire tout le temps de calcul dans un fichier text
$myfile = fopen("ghassanalgo.txt", "a") or die("Unable to open file!");
$txt =$k;
fwrite($myfile, $txt);
$txt = "\n";
fwrite($myfile, $txt);
fclose($myfile);
}
else
{
echo '<b>All the tasks are executed</b>';
}
?>






