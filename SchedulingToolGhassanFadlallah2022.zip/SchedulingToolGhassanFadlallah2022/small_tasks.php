<?php include("connection.php");
include("top.php");

if($_GET["id"]!='')
{
if($_GET["avail"]=='1')
{
$id=$_GET["id"];
$task=$_GET["task"];
$size=$_GET["size"];
$sql5 = "update small_tasks set avail=0 where id=" . $_GET["id"];
if ($conn->query($sql5) === TRUE) {
   echo "";
}
}
else 
{
$id=$_GET["id"];
$sql5 = "update small_tasks set avail=1 where id=" . $_GET["id"];
if ($conn->query($sql5) === TRUE) {
   echo "";
}	
}
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>

<body onload="navBarInit()" bgcolor="#C0C0C0"  onload="javacript:form1.rech1.focus()">


<form method="POST" name="form1" action="list_tasks.php?ajouter=1&rech1=<?php echo $rech1; ?>&rech2=<?php echo $rech2; ?>">

 <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="50%" id="AutoNumber1">

 <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="50%" id="AutoNumber1">
 <tr>
     <td width="20%">
    <p align="center"><b><a href="list_tasks.php?param=code&rech1=<?php echo $rech1; ?>&rech2=<?php echo $rech2; ?>&active=<?php echo $_GET['active']; ?>&inactive=<?php echo $_GET['inactive']; ?>"  style="text-decoration: none;color:blue" >Id</a></b></td>
    <td width="20%">
    <p align="center"><b><a href="list_tasks.php?param=code&rech1=<?php echo $rech1; ?>&rech2=<?php echo $rech2; ?>&active=<?php echo $_GET['active']; ?>&inactive=<?php echo $_GET['inactive']; ?>"  style="text-decoration: none;color:blue" >task</a></b></td>
    <td width="20%">
    <p align="center"><b><a href="list_tasks.php?param=code&rech1=<?php echo $rech1; ?>&rech2=<?php echo $rech2; ?>&active=<?php echo $_GET['active']; ?>&inactive=<?php echo $_GET['inactive']; ?>"  style="text-decoration: none;color:blue" >size</a></b></td>
    <td width="20%">
    <p align="center"><b><a href="list_tasks.php?param=code&rech1=<?php echo $rech1; ?>&rech2=<?php echo $rech2; ?>&active=<?php echo $_GET['active']; ?>&inactive=<?php echo $_GET['inactive']; ?>"  style="text-decoration: none;color:blue" >Available</a></b></td>

  
 </tr>
  

<?php 

$requete1= "SELECT * FROM small_tasks order by size";

$j=0;
$curseur1 = @mysql_query($requete1) Or die("Impossible de s�lectionner le contenu de la requete");	
while( $un_element = mysql_fetch_array($curseur1))
{
?>

<tr>
           <td width="20%">
    <p align="center"><input type='text' size='25' name='code<?php echo $j; ?>' value="<?php echo str_replace('É','�',$un_element['id']) ;  ?>"></td>
<td width="20%">
    <p align="center"><input type='text' size='25' name='code<?php echo $j; ?>' value="<?php echo str_replace('É','�',$un_element['task']) ;  ?>"></td>
<td width="20%">
    <p align="center"><input type='text' size='25' name='code<?php echo $j; ?>' value="<?php echo str_replace('É','�',$un_element['size']) ;  ?>"></td>
<td width="20%">
    <p align="center"><?php if ($un_element["avail"]==0) { echo "<a href='small_tasks.php?id=" . $un_element["id"] .  "&avail=0'>Yes</a>" ; } else { echo "<a href='small_tasks.php?id=" . $un_element["id"] .  "&avail=1'>No</a>"; } ?></td>  
  </tr>
<?php 
$i=$i+1;
$j=$j+1;
  }
$j=$j-1;
?>

</table>	

          </FORM>

</body>

</html>