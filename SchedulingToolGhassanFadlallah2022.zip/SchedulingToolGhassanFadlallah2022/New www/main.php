<?php
$end_lcfp = 1;
$end_scfp = 1;
$end_min = 1;
$end_our = 1;

include("connection.php");
include("top.php");
$sql2 = "SELECT min(no_test) min1 FROM tasks";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min1=$row2["min1"];
//echo 'min1=' . $min1 . '<br>';

$sql2 = "SELECT min(no_test) min2 FROM tasks1";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min2=$row2["min2"];
//echo 'min2=' . $min2 . '<br>';


$sql2 = "SELECT min(no_test) min3 FROM tasks2";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min3=$row2["min3"];
//echo 'min3=' . $min3 . '<br>';

$sql2 = "SELECT min(no_test) min4 FROM large_tasks";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min4=$row2["min4"];
//echo 'min4=' . $min4 . '<br>';


$sql2 = "SELECT min(no_test) min5 FROM meduim_tasks";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min5=$row2["min5"];
//echo 'min5=' . $min5 . '<br>';


$sql2 = "SELECT min(no_test) min6 FROM small_tasks";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min6=$row2["min6"];
//echo 'min6=' . $min6 . '<br>';
if($min1=='') $min1=0;
if($min2=='') $min2=0;
if($min3=='') $min3=0;
if($min4=='') $min4=0;
if($min5=='') $min5=0;
if($min6=='') $min6=0;



while ($min1!=0 || $min2!=0  || $min3!=0 || $min4!=0 || $min5!=0 || $min6!=0) {

//---------------------------------------
//---------------------------------------
$sql2 = "SELECT min(no_test) min1 FROM tasks";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min1=$row2["min1"];
//echo 'min1=' . $min1 . '<br>';

$sql2 = "SELECT min(no_test) min2 FROM tasks1";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min2=$row2["min2"];
//echo 'min2=' . $min2 . '<br>';


$sql2 = "SELECT min(no_test) min3 FROM tasks2";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min3=$row2["min3"];
//echo 'min3=' . $min3 . '<br>';

$sql2 = "SELECT min(no_test) min4 FROM large_tasks";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min4=$row2["min4"];
//echo 'min4=' . $min4 . '<br>';


$sql2 = "SELECT min(no_test) min5 FROM meduim_tasks";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min5=$row2["min5"];
//echo 'min5=' . $min5 . '<br>';


$sql2 = "SELECT min(no_test) min6 FROM small_tasks";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min6=$row2["min6"];
//echo 'min6=' . $min6 . '<br>';
if($min1=='') $min1=0;
if($min2=='') $min2=0;
if($min3=='') $min3=0;
if($min4=='') $min4=0;
if($min5=='') $min5=0;
if($min6=='') $min6=0;


//---------------------------------------
//---------------------------------------
if($min1>0 && $min1!='')
lcf_algo();
if($min2>0  && $min2!='')
scf_algo(); 
if($min3>0   && $min3!='')     
min_min_algo();
if($min4>0 || $min5>0 || $min6>0)  
ghassan_algo();

}

// AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

//LE CODE QUE J'AI AJOUTÉ EST ICI
//--------------------------------------------
$sql5 = "SELECT count(*) nom1 FROM tasks";
$result5 = $conn->query($sql5);
$row5 = $result5->fetch_assoc();
$nom1=$row5["nom1"];
$sql5 = "SELECT count(*) nom2 FROM tasks1";
$result5 = $conn->query($sql5);
$row5 = $result5->fetch_assoc();
$nom2=$row5["nom2"];
$sql5 = "SELECT count(*) nom3 FROM tasks2";
$result5 = $conn->query($sql5);
$row5 = $result5->fetch_assoc();
$nom3=$row5["nom3"];
$sql5 = "SELECT count(*) nom4 FROM large_tasks";
$result5 = $conn->query($sql5);
$row5 = $result5->fetch_assoc();
$nom4=$row5["nom4"];
$sql5 = "SELECT count(*) nom5 FROM meduim_tasks";
$result5 = $conn->query($sql5);
$row5 = $result5->fetch_assoc();
$nom5=$row5["nom5"];
$sql5 = "SELECT count(*) nom6 FROM small_tasks";
$result5 = $conn->query($sql5);
$row5 = $result5->fetch_assoc();
$nom6=$row5["nom6"];

if($nom1==0 && $nom2==0  && $nom3==0 && $nom4==0 && $nom5==0 && $nom6==0) {

echo '<br><br>----------Aller dans Extraire des resultats---------<br>';
sleep(1);
?>
<script language='javascript'>window.location='http://localhost/compare-algorithms10.php';</script>
<?php
}
//------------------------------------------------------------------------
//----------------------------------------------------------------------
//----------------------------------------------------------------------

//----------------------------------------------------------------------
//----------------------------------------------------------------------
function initialize()
{
	include("connection.php");
	if ($conn->connect_error) 
	{
    		die("Connection failed: " . $conn->connect_error);
	} 

	echo '<center>end initialize</center>';

}



function lcf_algo()
{

	include("connection.php");
 	global $min1,$min2,$min3,$min4,$min5,$min6, $end_lcfp;;

	$ss1=0;
	if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
	$sql = "SELECT *  FROM devices order by score desc";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) 
	{

		$starttime = microtime(true);
    		// output data of each row
    		while($row = $result->fetch_assoc()) 
		{

			$id=$row["id"];

			$sql1 = "SELECT * FROM tasks where no_test=" . $min1 . " and size<=" . $row["score"] . " order by size desc limit 1"; 
			
			$result1 = $conn->query($sql1);
			$row1 = $result1->fetch_assoc();
			$id1=$row1["id"];
/*				
			if ($id1!='') 
			{
				echo "<b><font color='blue'> Value of id1 </font><font color='red'> " . $id1 . "</font></b><br><br>";
				// sleep(1);
			}
			else 
			{
				echo "<b><font color='blue'> Value of id1 </font><font color='red'> " . 0 . "</font></b><br><br>";
				sleep(10);
			}
*/
			if ($result1->num_rows > 0) 
			{
				$ss1=1;
				if ($id1=='') 
				{
					echo "<b><font color='blue'>We didn't find any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
				}
				elseif($row1["size"]<=0.87*$row["score"])
				{
					// echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
					//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
					$id_device=$row["id"];
					$nom_device=$row["device"];
					$id_task=$row1["id"];
					$nom_task=$row1["task"];
					$id_task=$row1["id"];
					$temps=$row1["temps"];
					$sql4 = "INSERT INTO a1(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min1);";
					if ($conn->query($sql4) === TRUE) 
					{
    						echo "";
					}
					$sql4 = "delete from tasks where id=" . $id1;
					if ($conn->query($sql4) === TRUE) 
					{
    						echo "";
					} 
				} 


			}
			
		}
		$endtime = microtime(true);
		$timediff = $endtime - $starttime;
		//echo '<b>$ss1 =' . $ss1 . '</b>';
		//sleep(2);
		if ($ss1==0)
		{
			echo '<br> LCFP: All the tasks are executed</b>';
			// $end_lcfp = 0;
			// echo '$end_lcfp =' . $end_lcfp . '<br>';
			// sleep(2);
		}
		else
		{
			// echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';

			$endtime = microtime(true);
			$timediff = $endtime - $starttime;
			//ecrire tout le temps de calcul dans un fichier text
			$myfile = fopen("lcf.txt", "a") or die("Unable to open file!");
			$txt =$timediff;
			fwrite($myfile, $txt);
			$txt = "\n";
			fwrite($myfile, $txt);
			fclose($myfile);
		}
	} 
	// echo "<center>LCFP</center>";

/*
$result = mysql_query("SELECT COUNT(*) AS `count` FROM `tasks`");
$row = mysql_fetch_assoc($result);
$count = $row['count'];
echo "<b><font color='red'>count = </font><font color='green'> " . $count . "</font></b><br><br>";
if ($count==0)
{
	$end_lcfp = 0;
}


	echo "<b><font color='red'>end_lcfp = </font><font color='green'> " . $end_lcfp . "</font></b><br><br>";
	sleep(1);
*/
}


function scf_algo()
{
 	global $min1,$min2,$min3,$min4,$min5,$min6, $end_scfp;;
	include("connection.php");

	$some=0;
	$ss1=0;
	if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
	$sql = "SELECT *  FROM devices1 order by score desc";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) 
	{
		$some=1;
		$starttime = microtime(true);
    		// output data of each row
    		while($row = $result->fetch_assoc()) 
		{
			$id=$row["id"];
			$sql1 = "SELECT * FROM tasks1 where no_test=" . $min2 . " and size<=" . $row["score"] . " order by size asc limit 1"; 

			$result1 = $conn->query($sql1);
			$row1 = $result1->fetch_assoc();
			$id1=$row1["id"];
			if ($result1->num_rows > 0) 
			{
				$ss1=1;
				if ($id1=='') 
				{
					echo "<b><font color='blue'>We didn't find any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
				}
				elseif($row1["size"]<=0.87*$row["score"])
				{
					// echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
					//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
					$id_device=$row["id"];
					$nom_device=$row["device"];
					$id_task=$row1["id"];
					$nom_task=$row1["task"];
					$id_task=$row1["id"];
					$temps=$row1["temps"];
					$sql4 = "INSERT INTO a2(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min2);";
					if ($conn->query($sql4) === TRUE) 
					{
 					   echo "";
					}
					$sql4 = "delete from tasks1 where id=" . $id1;
					if ($conn->query($sql4) === TRUE) 
					{
					    echo "";
					} 
				} 


			}
			
		}
		$endtime = microtime(true);
		$timediff = $endtime - $starttime;
		if ($ss1==0)
		{
			echo '<b> SCFP: All the tasks are executed</b>';
			// $end_scfp = 0;
			// echo '$end_scfp =' . $end_scfp . '<br>';
			// sleep(2);
		}
		else
		{
			// echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';

			$endtime = microtime(true);
			$timediff = $endtime - $starttime;
			//ecrire tout le temps de calcul dans un fichier text
			$myfile = fopen("scf.txt", "a") or die("Unable to open file!");
			$txt =$timediff;
			fwrite($myfile, $txt);
			$txt = "\n";
			fwrite($myfile, $txt);
			fclose($myfile);
		}
	} 

	// echo "<center>SCFP</center>";
/*
echo "<b><font color='green'>end_scfp = </font><font color='blue'> " . $end_scfp . "</font></b><br><br>";
$result = mysql_query("SELECT COUNT(*) AS `count` FROM `tasks1` ");
$row = mysql_fetch_assoc($result);
$count = $row['count'];
echo "<b><font color='green'>count_scfp = </font><font color='blue'> " . $count . "</font></b><br><br>";
if ($count==0)
{
	$end_scfp = 0;

	echo "<b><font color='red'>end_scfp = </font><font color='green'> " . $end_scfp . "</font></b><br><br>";
	sleep(1);
}
*/

}

function min_min_algo()
{
	global $min1,$min2,$min3,$min4,$min5,$min6, $end_min;
	include("connection.php");
	$some=0;
	$ss1=0;
	if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
	$sql = "SELECT *  FROM devices2 order by score asc";
	$result = $conn->query($sql);
	if ($result->num_rows > 0)
	{
		$some=1;
		$starttime = microtime(true);
		// output data of each row
		while($row = $result->fetch_assoc()) 
		{
			$id=$row["id"];
			$sql1 = "SELECT * FROM tasks2 where no_test=" . $min3 . " order by size asc limit 1"; 
			$result1 = $conn->query($sql1);
			$row1 = $result1->fetch_assoc();
			$id1=$row1["id"];
			if ($result1->num_rows > 0) 
			{
				$ss1=1;
				if ($id1=='') 
				{
					echo "<b><font color='blue'>We didn't find any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
				}
				elseif($row1["size"]<=0.87*$row["score"])
				{
					// echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
					//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
					$id_device=$row["id"];
					$nom_device=$row["device"];
					$id_task=$row1["id"];
					$nom_task=$row1["task"];
					$id_task=$row1["id"];
					$temps=$row1["temps"];
					$sql4 = "INSERT INTO a3(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min3);";
					if ($conn->query($sql4) === TRUE) 
					{
						echo "";
					}
					$sql4 = "delete from tasks2 where id=" . $id1;
					if ($conn->query($sql4) === TRUE) 
					{
						echo "";
					} 
				} 


			}
			
		} 
		$endtime = microtime(true);
		$timediff = $endtime - $starttime;
		if ($ss1==0)
		{
			echo '<b> Min-Min: All the tasks are executed</b>';
			// $end_min = 0;
			// echo '$end_min =' . $end_min . '<br>';
			// sleep(2);
		}
		else
		{
			// echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';

			$endtime = microtime(true);
			$timediff = $endtime - $starttime;
			//ecrire tout le temps de calcul dans un fichier text
			$myfile = fopen("minmin.txt", "a") or die("Unable to open file!");
			$txt =$timediff;
			fwrite($myfile, $txt);
			$txt = "\n";
			fwrite($myfile, $txt);
			fclose($myfile);
		}
	}
	// echo "<center>Min-Min</center>";

/*
echo "<b><font color='green'>end_min = </font><font color='blue'> " . $end_min . "</font></b><br><br>";
$result = mysql_query("SELECT COUNT(*) AS `count` FROM `tasks2` ");
$row = mysql_fetch_assoc($result);
$count = $row['count'];
echo "<b><font color='green'>count_min = </font><font color='blue'> " . $count . "</font></b><br><br>";
if ($count==0)
{
	$end_min = 0;

	echo "<b><font color='red'>end_min = </font><font color='green'> " . $end_min . "</font></b><br><br>";
	sleep(1);
}

*/
}

function ghassan_algo()
{
	global $min1,$min2,$min3,$min4,$min5,$min6;$min7;
	include("connection.php");

/*	
	$min7=min($min4,$min5,$min6);
	if($min7==0) 
	{
		if($min4==0 && $min5==0 && $min6>0)
		$min7=$min6;

		if($min4==0 && $min5>0 && $min6==0)
		$min7=$min5;
	
		if($min4>0 && $min5==0 && $min6==0)
		$min7=$min4;
	}
*/
// ++++


$min7=min($min4,$min5,$min6);
if($min7==0) {
if($min4==0 && $min5==0 && $min6>0)
$min7=$min6;

if($min4==0 && $min5>0 && $min6==0)
$min7=$min5;

if($min4>0 && $min5==0 && $min6==0)
$min7=$min4;

if($min4>0 && $min5>0 && $min6==0)
$min7=$min4;


if($min4>0 && $min6>0 && $min5==0)
$min7=$min4;




if($min5>0 && $min6>0 && $min4==0)
$min7=$min5;
}


// ++++

	$some=0;
	$ss1=0;
	$k=0;
	if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
	//--------------------------------
	//--------------------------------
	$sql4 = "update large_devices set avail=0";
	if ($conn->query($sql4) === TRUE) 
	{
		echo "";
	} 

	$sql4 = "update meduim_devices set avail=0";
	if ($conn->query($sql4) === TRUE) 
	{
		echo "";
	} 

	$sql4 = "update small_devices set avail=0";
	if ($conn->query($sql4) === TRUE) 
	{
		echo "";
	} 

	//-------------------------------
	//-------------------------------

	$sql = "SELECT *  FROM large_devices where avail=0 order by score desc";
	$result = $conn->query($sql);
	
	// echo "<br><b><font color='green'>Search in the large devices</font></b><br><br>";
	// echo '$result->num_rows :  ' . $result->num_rows . '<br>';
	if ($result->num_rows > 0) 
	{
	$some=1;

	$starttime = microtime(true);
	$rvrs=-1; // new======
	while($row = $result->fetch_assoc()) 
	{
		$rvrs=-$rvrs;
		
		$id=$row["id"];
		//echo '$id :  ' . $id . '<br>';
/**/		
		$score1=0.35*$row["score"];
		$score2=0.93*$row["score"];
		
		// $sql1 = "SELECT * FROM large_tasks where  no_test=" . $min7 . " and size<" . $score2 . " order by size desc limit 1";

		// $sql1 = "SELECT * FROM large_tasks where  no_test=" . $min7 . " and size<" . $score2 . " and size>=" . $score1 . " order by size asc limit 1";
		// $sql1 = "SELECT * FROM large_tasks where  no_test=" . $min7 . " and size<" . $score2 . " and size>=" . $score1 . " order by size asc limit 1";
/**/
// replaced		$sql1 = "SELECT * FROM large_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size asc limit 1";
 // new======
if($rvrs==1)
{		
		$sql1 = "SELECT * FROM large_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size asc limit 1";
}
elseif($rvrs==-1)
{		
		$sql1 = "SELECT * FROM large_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size desc limit 1";
}
 // new======		
		$result1 = $conn->query($sql1);
		$row1 = $result1->fetch_assoc();
		// echo '$result1 :  ' . $result1 . '<br>';
		// echo 'La taille de la tache = :  ' . $row1["size"] . '<br>';
		// echo 'rvrs :  ' . $rvrs . '<br>';
		// echo 'Score du dispositif :  ' . $row["score"] . '<br>';
		// sleep(1);
		
		// $row1 = $result1->fetch_assoc();
		$id1=$row1["id"];
		// echo '$result1->num_rows :  ' . $result1->num_rows . '<br>';
		if ($result1->num_rows > 0) 
		{
			$rvrs=-$rvrs; // new======
			$ss1=1;
			if ($id1=='') 
			{
				echo "<b><font color='blue'>We didn't find any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
			}

			elseif($row1["size"]<=0.87*$row["score"])
			{
				/*echo 'Taille de la tache :  ' . $row1["size"] . '<br>';
				echo 'Score du dispositif :  ' . $row["score"] . '<br>';
				sleep(1);*/
				// echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
				//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
				$id_device=$row["id"];
				$nom_device=$row["device"];
				$id_task=$row1["id"];
				$nom_task=$row1["task"];
				$id_task=$row1["id"];
				$temps=$row1["temps"];
				$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min7);";
				if ($conn->query($sql4) === TRUE) 
				{
 					echo "";
				}
				$sql4 = "delete from large_tasks where id=" . $id1;
				if ($conn->query($sql4) === TRUE) 
				{
					echo "";
				} 
					
				/*$sql4 = "update large_devices set avail=1 where id=" . $id;
				if ($conn->query($sql4) === TRUE) 
				{
					echo "";
				} */
				
			} 


		}

	}	$endtime = microtime(true);
	$timediff = $endtime - $starttime;
	$k=$k+$timediff;


}

	//--------------------------------------------------------
	//--------------------------------------------------------

	//--------------------------------------------------------
	//--------------------------------------------------------
	$rvrs=1; // new======
	$sql = "SELECT *  FROM meduim_devices where avail=0 order by score desc";
	$result = $conn->query($sql);
	// echo "<br><b><font color='green'>Search in the meduim devices</font></b><br><br>";
	if ($result->num_rows > 0) 
	{
		$some=1;
		$starttime = microtime(true);
 		while($row = $result->fetch_assoc()) 
		{
			$id=$row["id"];
// replaced		$sql1 = "SELECT * FROM meduim_tasks where  no_test=" . $min7 . " and size>=" . $row["score"] . " order by size desc limit 1";


 // new======
if($rvrs==1)
{		
		$sql1 = "SELECT * FROM meduim_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size asc limit 1";
}
elseif($rvrs==-1)
{		
		$sql1 = "SELECT * FROM meduim_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size desc limit 1";
}
 // new======	


			$result1 = $conn->query($sql1);
			$row1 = $result1->fetch_assoc();
			$id1=$row1["id"];
			if ($result1->num_rows > 0) 
			{
				$rvrs=-$rvrs; // new======
				$ss1=1;
				if ($id1=='') 
				{
					echo "<b><font color='blue'>We didn't find any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
				}
				elseif($row1["size"]<=1*$row["score"])
				{
					// echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
					//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
					$id_device=$row["id"];
					$nom_device=$row["device"];
					$id_task=$row1["id"];
					$nom_task=$row1["task"];
					$id_task=$row1["id"];
					$temps=$row1["temps"];
					$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min7);";
					if ($conn->query($sql4) === TRUE) 
					{
						echo "";
					}
					$sql4 = "delete from meduim_tasks where id=" . $id1;
					if ($conn->query($sql4) === TRUE) 
					{
						echo "";
					} 
						
					/*$sql4 = "update meduim_devices set avail=1 where id=" . $id;
					if ($conn->query($sql4) === TRUE) 
					{
						echo "";
					}*/ 

				} 


			}
			
		}
		$endtime = microtime(true);
		$timediff = $endtime - $starttime;
		$k=$k+$timediff;

	} // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

	//--------------------------------------------------------
	//--------------------------------------------------------
	$rvrs=1; // new======
	$sql = "SELECT *  FROM small_devices where avail=0 order by score desc";
	$result = $conn->query($sql);
	// echo "<br><b><font color='green'>Search in the small devices</font></b><br><br>";
	if ($result->num_rows > 0) 
	{
		$starttime = microtime(true);
		while($row = $result->fetch_assoc()) 
	{
	$id=$row["id"];
	// replaced	$sql1 = "SELECT * FROM small_tasks where  no_test=" . $min7 . " and size<" . $row["score"] . "  order by size desc limit 1";
	
 // new======
if($rvrs==1)
{		
		$sql1 = "SELECT * FROM small_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size asc limit 1";
}
elseif($rvrs==-1)
{		
		$sql1 = "SELECT * FROM small_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size desc limit 1";
}
 // new======	


	$result1 = $conn->query($sql1);
	$row1 = $result1->fetch_assoc();
	$id1=$row1["id"];
	if ($result1->num_rows > 0) {
	$rvrs=-$rvrs; // new======
	$ss1=1;
	if ($id1=='') 
	{
		echo "<b><font color='blue'>We didn't find any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
	}
	elseif($row1["size"]<=1*$row["score"])
	{
		// echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
		//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
		$id_device=$row["id"];
		$nom_device=$row["device"];
		$id_task=$row1["id"];
		$nom_task=$row1["task"];
		$id_task=$row1["id"];
		$temps=$row1["temps"];
		$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min7);";
		if ($conn->query($sql4) === TRUE) 
		{
			echo "";
		}
		$sql4 = "delete from small_tasks where id=" . $id1;
		if ($conn->query($sql4) === TRUE) 
		{
			echo "";
		} 

		/*$sql4 = "update small_devices set avail=1 where id=" . $id;
		if ($conn->query($sql4) === TRUE) 
		{
			echo "";
		}*/  
	} 


} // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
} // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

	$endtime = microtime(true);
	$timediff = $endtime - $starttime;
	$k=$k+$timediff;

} // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

	$sql15 = "SELECT count(*) nombri FROM large_tasks where  no_test=" . $min7;
	$result15 = $conn->query($sql15);
	$row15 = $result15->fetch_assoc();
	$nombri=$row2["nombri"];
	/*
	if($nombri==0)  
	{
		echo "<b><font color='red'>nombri</font><font color='green'> " . $nombri . "</font></b><br><br>";
		//sleep(1);
	}
	*/
	if($nombri=='' || $nombri==0)  
	{
		$rvrs=1;  // new======
		$sql = "SELECT *  FROM large_devices where avail=0 order by score asc";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) 
		{
			
			$some=1;
			$starttime = microtime(true);
			// output data of each row
			while($row = $result->fetch_assoc()) 
			{
				$id=$row["id"];
			// replaced	$sql1 = "SELECT * FROM meduim_tasks where  no_test=" . $min7 . " and size<" . $row["score"] . " order by size asc limit 1";
				
	
 // new======
if($rvrs==1)
{		
		$sql1 = "SELECT * FROM meduim_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size asc limit 1";
}
elseif($rvrs==-1)
{		
		$sql1 = "SELECT * FROM meduim_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size desc limit 1";
}
 // new======	


				$result1 = $conn->query($sql1);
				$row1 = $result1->fetch_assoc();
				$id1=$row1["id"];
				if ($result1->num_rows > 0) 
				{
					$rvrs=-$rvrs; // new======
					$ss1=1;
					if ($id1=='') 
					{
						echo "<b><font color='blue'>We didn't find any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
					}
					elseif($row1["size"]<=$row["score"])
					{
						// echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
						//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a4
						$id_device=$row["id"];
						$nom_device=$row["device"];
						$id_task=$row1["id"];
						$nom_task=$row1["task"];
						$id_task=$row1["id"];
						$temps=$row1["temps"];
						$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min7);";
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						}
						$sql4 = "delete from meduim_tasks where id=" . $id1;
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						} 
						
						/*$sql4 = "update meduim_devices set avail=1 where id=" . $id;
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						}*/ 
						
					} 


				}

			}
			$endtime = microtime(true);
			$timediff = $endtime - $starttime;
			$k=$k+$timediff;
		}
		//--------------------------------------------------------
		//--------------------------------------------------------
		$rvrs=1;  // new======
		$sql = "SELECT *  FROM large_devices where avail=0 order by score asc";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) 
		{
			
			$some=1;
			$starttime = microtime(true);
			while($row = $result->fetch_assoc()) 
			{
				$id=$row["id"];
			// new======	$sql1 = "SELECT * FROM small_tasks where   no_test=" . $min7 . " and size<=" . $row["score"] . "  order by size desc limit 1";
	
 // new======
if($rvrs==1)
{		
		$sql1 = "SELECT * FROM small_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size asc limit 1";
}
elseif($rvrs==-1)
{		
		$sql1 = "SELECT * FROM small_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size desc limit 1";
}
 // new======	



				$result1 = $conn->query($sql1);
				$row1 = $result1->fetch_assoc();
				$id1=$row1["id"];
				if ($result1->num_rows > 0) 
				{
					$rvrs=-$rvrs; // new======
					$ss1=1;
					if ($id1=='') 
					{
						echo "<b><font color='blue'>We didn't find any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
					}
					elseif($row1["size"]<=$row["score"])
					{
						// echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
						//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
						$id_device=$row["id"];
						$nom_device=$row["device"];
						$id_task=$row1["id"];
						$nom_task=$row1["task"];
						$id_task=$row1["id"];
						$temps=$row1["temps"];
						$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min7);";
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						}
						$sql4 = "delete from small_tasks where id=" . $id1;
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						} 
						/*
						$sql4 = "update small_devices set avail=1 where id=" . $id;
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						} 
						*/ 
					} 


				}

			}
			$endtime = microtime(true);
			$timediff = $endtime - $starttime;
			$k=$k+$timediff;
		}
	} 
	//aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
	$sql50 = "SELECT count(*) nombri FROM meduim_tasks where  no_test=" . $min7;
	$result50 = $conn->query($sql50);
	$row50 = $result50->fetch_assoc();
	$nombri=$row2["nombri"];
	if($nombri=='' || $nombri==0)  
	{
		$rvrs=1;  // new======
		$sql = "SELECT *  FROM meduim_devices where avail=0 order by score desc";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) 
		{
			$some=1;
			$starttime = microtime(true);
			while($row = $result->fetch_assoc()) 
			{
				$id=$row["id"];
			// new======	$sql1 = "SELECT * FROM small_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size desc limit 1";

	
 // new======
if($rvrs==1)
{		
		$sql1 = "SELECT * FROM small_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size asc limit 1";
}
elseif($rvrs==-1)
{		
		$sql1 = "SELECT * FROM small_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size desc limit 1";
}
 // new======	

				$result1 = $conn->query($sql1);
				$row1 = $result1->fetch_assoc();
				$id1=$row1["id"];
				if ($result1->num_rows > 0) 
				{
					$rvrs=-$rvrs; // new======
					$ss1=1;
					if ($id1=='') 
					{
						echo "<b><font color='blue'>We didn't find any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
					}
					elseif($row1["size"]<=$row["score"])
					{
						// echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
						//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
						$id_device=$row["id"];
						$nom_device=$row["device"];
						$id_task=$row1["id"];
						$nom_task=$row1["task"];
						$id_task=$row1["id"];
						$temps=$row1["temps"];
						$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min7);";
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						}
						$sql4 = "delete from small_tasks where id=" . $id1;
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						} 
						/*
						$sql4 = "update small_devices set avail=1 where id=" . $id;
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						} 
						*/
					} 


				}

			}
			$endtime = microtime(true);
			$timediff = $endtime - $starttime;
			$k=$k+$timediff;
		}
	}

	if ($ss1==1)  
	{
		// echo '<b>The search time  is ' .  number_format((float)$k, 6, '.', '') . ' seconds</b><br>';

		//ecrire tout le temps de calcul dans un fichier text
		$myfile = fopen("ghassanalgo.txt", "a") or die("Unable to open file!");
		$txt =$k;
		fwrite($myfile, $txt);
		$txt = "\n";
		fwrite($myfile, $txt);
		fclose($myfile);
	}
	else
	{
		echo '<b> Notre algorithme: All the tasks are executed</b>';
	}

	// echo "<center>Notre algorithme</center>";

} // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

function new_results()
{
	include("connection.php");
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	} 

		echo "<center>end new results</center>";
}


function delete_cash()
{
	include("connection.php");
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	} 

	echo "<center>end delete cash</center>";
}
/*
echo 'end_lcfp =' . $end_lcfp . ' end_scfp = ' . $end_scfp . ' end_min = ' . $end_min . ' end_our = ' . $end_our . '<br>';
while ($end_lcfp == 0 && $end_scfp == 0 && $end_min == 0 && $end_our == 1)
{
	header("refresh:30");

} // end while
*/

?>