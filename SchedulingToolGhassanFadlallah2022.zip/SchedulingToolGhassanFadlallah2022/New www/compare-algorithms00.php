
<?php
include("top.php"); 
include("connection.php");
?>
<form method="post" action="compare-algorithms00.php">
Nombre de devices:<input type="text" name="devico" value='0'><br>
Nombre de taches:<input type="text" name="tasko" value='0'><br>
Nombre d'instances:<input type="text" name="inst" value='0'><br>
<input type="submit" name="idtest" value='Generer le liste de devices et taches'>
<br><br><br>


