<?php
header("refresh: 10"); 
include("connection.php");
include("top.php");
$some=0;
$ss1=0;
$starttime = microtime(true);
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT *  FROM large_devices";
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the large devices</font></b><br><br>";
if ($result->num_rows > 0) {
$some=1;
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT * FROM large_tasks limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
//-------------------------------------
//-------------------------------------

if ($result1->num_rows > 0) {
$ss1=1;
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
}
else
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";

$sql4 = "delete from large_tasks where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
} 


}





}}
//--------------------------------------------------------
//--------------------------------------------------------
$sql = "SELECT *  FROM meduim_devices";
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the meduim devices</font></b><br><br>";
if ($result->num_rows > 0) {
$some=1;
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT * FROM meduim_tasks limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];

if ($result1->num_rows > 0) {
$ss1=1;
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
}
else
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";

$sql4 = "delete from meduim_tasks where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
} 


}
}}

//--------------------------------------------------------
//--------------------------------------------------------
$sql = "SELECT *  FROM small_devices";
$result = $conn->query($sql);
echo "<br><b><font color='green'>Search in the small devices</font></b><br><br>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$id=$row["id"];
$sql1 = "SELECT * FROM small_tasks limit 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($result1->num_rows > 0) {
$ss1=1;
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
}
else
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";

$sql4 = "delete from small_tasks where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
} 


}
}}

if ($ss1==1)  {
$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s1=$timediff;
echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';


//ecrire tout le temps de calcul dans un fichier text
$myfile = fopen("ghassanalgo.txt", "a") or die("Unable to open file!");
$txt =$timediff;
fwrite($myfile, $txt);
$txt = "\n";
fwrite($myfile, $txt);
fclose($myfile);
}
else
{
echo '<b>All the tasks are executed</b>';
}
?>






