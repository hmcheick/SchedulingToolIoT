<?php include("connection.php");
include("top.php");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

//$sql4 = "delete from devices";
//if ($conn->query($sql4) === TRUE) {
 //   echo "";
//}

    // Nom du fichier à ouvrir
    $fichier = file("devices.txt");
    // Nombre total de ligne du fichier
    $total = count($fichier);

    for($i = 0; $i < $total; $i++) {
    // On affiche ligne par ligne le contenu du fichier
    // avec la fonction nl2br pour ajouter les sauts de lignes
    echo $fichier[$i] . '<br>';
$tt=explode(" ", $fichier[$i]);
$sql = "INSERT INTO devices(device,score) VALUES ('$tt[0]',$tt[1]);";

if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}




    }

$conn->close();
?>
</body>

</html>





