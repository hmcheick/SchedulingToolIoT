-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Ven 24 Avril 2020 à 21:48
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `healthsoftware`
--

-- --------------------------------------------------------

--
-- Structure de la table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task` varchar(60) NOT NULL DEFAULT '',
  `size` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Contenu de la table `tasks`
--

INSERT INTO `tasks` (`id`, `task`, `size`) VALUES
(10, 'T60', 1),
(2, 'T7', 3.4),
(3, 'T8', 4),
(4, 'T26', 17),
(5, 'T27', 19.5),
(6, 'T23', 15.3),
(7, 'T8', 25.4),
(8, 'T69', 27.8),
(9, 'T70', 31.5),
(11, 'T61', 2),
(12, 'T62', 3),
(13, 'T63', 1.4),
(14, 'T65', 5.2),
(15, 'T70', 15.1),
(16, 'T71', 15.6),
(17, 'T72', 15.8),
(18, 'T73', 15.9),
(19, 'T74', 15.77),
(20, 'T75', 17),
(21, 'T78', 18.6);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
