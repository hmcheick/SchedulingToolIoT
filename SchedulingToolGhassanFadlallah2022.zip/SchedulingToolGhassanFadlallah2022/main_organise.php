<?php
header("refresh: 3"); 
include("connection.php");
include("top.php");
$sql2 = "SELECT min(no_test) min1 FROM tasks";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min1=$row2["min1"];
//echo 'min1=' . $min1 . '<br>';

$sql2 = "SELECT min(no_test) min2 FROM tasks1";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min2=$row2["min2"];
//echo 'min2=' . $min2 . '<br>';


$sql2 = "SELECT min(no_test) min3 FROM tasks2";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min3=$row2["min3"];
//echo 'min3=' . $min3 . '<br>';

$sql2 = "SELECT min(no_test) min4 FROM large_tasks";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min4=$row2["min4"];
//echo 'min4=' . $min4 . '<br>';


$sql2 = "SELECT min(no_test) min5 FROM meduim_tasks";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min5=$row2["min5"];
//echo 'min5=' . $min5 . '<br>';


$sql2 = "SELECT min(no_test) min6 FROM small_tasks";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$min6=$row2["min6"];
//echo 'min6=' . $min6 . '<br>';
if($min1=='') $min1=0;
if($min2=='') $min2=0;
if($min3=='') $min3=0;
if($min4=='') $min4=0;
if($min5=='') $min5=0;
if($min6=='') $min6=0;




if($min1>0 && $min1!='')
lcf_algo();
if($min2>0  && $min2!='')
scf_algo(); 
if($min3>0   && $min3!='')     
min_min_algo();
if($min4>0 || $min5>0 || $min6>0)  
ghassan_algo();

//new_results();


//----------------------------------------------------------------------
//----------------------------------------------------------------------
function initialize()
{
	include("connection.php");
	if ($conn->connect_error) 
	{
    		die("Connection failed: " . $conn->connect_error);
	} 

	echo '<center>end initialize</center>';

}



function lcf_algo()
{

	include("connection.php");
 	global $min1,$min2,$min3,$min4,$min5,$min6;

	$ss1=0;
	if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
	$sql = "SELECT *  FROM devices order by score desc";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) 
	{

		$starttime = microtime(true);
    		// output data of each row
    		while($row = $result->fetch_assoc()) 
		{

			$id=$row["id"];

			$sql1 = "SELECT * FROM tasks where no_test=" . $min1 . " and size<=" . $row["score"] . " order by size desc limit 1"; 

			$result1 = $conn->query($sql1);
			$row1 = $result1->fetch_assoc();
			$id1=$row1["id"];
			if ($result1->num_rows > 0) 
			{
				$ss1=1;
				if ($id1=='') 
				{
					echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
				}
				elseif($row1["size"]<=$row["score"])
				{
					echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
					//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
					$id_device=$row["id"];
					$nom_device=$row["device"];
					$id_task=$row1["id"];
					$nom_task=$row1["task"];
					$id_task=$row1["id"];
					$temps=$row1["temps"];
					$sql4 = "INSERT INTO a1(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min1);";
					if ($conn->query($sql4) === TRUE) 
					{
    						echo "";
					}
					$sql4 = "delete from tasks where id=" . $id1;
					if ($conn->query($sql4) === TRUE) 
					{
    						echo "";
					} 
				} 


			}
		}
		$endtime = microtime(true);
		$timediff = $endtime - $starttime;

		if ($ss1==0)
		{
			echo '<b>All the tasks are executed</b>';
		}
		else
		{
			echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';

			$endtime = microtime(true);
			$timediff = $endtime - $starttime;
			//ecrire tout le temps de calcul dans un fichier text
			$myfile = fopen("lcf.txt", "a") or die("Unable to open file!");
			$txt =$timediff;
			fwrite($myfile, $txt);
			$txt = "\n";
			fwrite($myfile, $txt);
			fclose($myfile);
		}
	} 

	echo "<center>end lsf</center>";
}

function scf_algo()
{
 	global $min1,$min2,$min3,$min4,$min5,$min6;
	include("connection.php");
	$some=0;
	$ss1=0;
	if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
	$sql = "SELECT *  FROM devices1 order by score desc";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) 
	{
		$some=1;
		$starttime = microtime(true);
    		// output data of each row
    		while($row = $result->fetch_assoc()) 
		{
			$id=$row["id"];
			$sql1 = "SELECT * FROM tasks1 where no_test=" . $min2 . " and size<=" . $row["score"] . " order by size asc limit 1"; 

			$result1 = $conn->query($sql1);
			$row1 = $result1->fetch_assoc();
			$id1=$row1["id"];
			if ($result1->num_rows > 0) 
			{
				$ss1=1;
				if ($id1=='') 
				{
					echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
				}
				elseif($row1["size"]<=$row["score"])
				{
					echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
					//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
					$id_device=$row["id"];
					$nom_device=$row["device"];
					$id_task=$row1["id"];
					$nom_task=$row1["task"];
					$id_task=$row1["id"];
					$temps=$row1["temps"];
					$sql4 = "INSERT INTO a2(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min2);";
					if ($conn->query($sql4) === TRUE) 
					{
 					   echo "";
					}
					$sql4 = "delete from tasks1 where id=" . $id1;
					if ($conn->query($sql4) === TRUE) 
					{
					    echo "";
					} 
				} 


			}
		}
		$endtime = microtime(true);
		$timediff = $endtime - $starttime;
		if ($ss1==0)
		{
			echo '<b>All the tasks are executed</b>';
		}
		else
		{
			echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';

			$endtime = microtime(true);
			$timediff = $endtime - $starttime;
			//ecrire tout le temps de calcul dans un fichier text
			$myfile = fopen("scf.txt", "a") or die("Unable to open file!");
			$txt =$timediff;
			fwrite($myfile, $txt);
			$txt = "\n";
			fwrite($myfile, $txt);
			fclose($myfile);
		}
	} 

	echo "<center>end scf</center>";
}

function min_min_algo()
{
	global $min1,$min2,$min3,$min4,$min5,$min6;
	include("connection.php");
	$some=0;
	$ss1=0;
	if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
	$sql = "SELECT *  FROM devices2 order by score asc";
	$result = $conn->query($sql);
	if ($result->num_rows > 0)
	{
		$some=1;
		$starttime = microtime(true);
		// output data of each row
		while($row = $result->fetch_assoc()) 
		{
			$id=$row["id"];
			$sql1 = "SELECT * FROM tasks2 where no_test=" . $min3 . " order by size asc limit 1"; 
			$result1 = $conn->query($sql1);
			$row1 = $result1->fetch_assoc();
			$id1=$row1["id"];
			if ($result1->num_rows > 0) 
			{
				$ss1=1;
				if ($id1=='') 
				{
					echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
				}
				elseif($row1["size"]<=$row["score"])
				{
					echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
					//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
					$id_device=$row["id"];
					$nom_device=$row["device"];
					$id_task=$row1["id"];
					$nom_task=$row1["task"];
					$id_task=$row1["id"];
					$temps=$row1["temps"];
					$sql4 = "INSERT INTO a3(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min3);";
					if ($conn->query($sql4) === TRUE) 
					{
						echo "";
					}
					$sql4 = "delete from tasks2 where id=" . $id1;
					if ($conn->query($sql4) === TRUE) 
					{
						echo "";
					} 
				} 


			}
		} 
		$endtime = microtime(true);
		$timediff = $endtime - $starttime;
		if ($ss1==0)
		{
			echo '<b>All the tasks are executed</b>';
		}
		else
		{
			echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';

			$endtime = microtime(true);
			$timediff = $endtime - $starttime;
			//ecrire tout le temps de calcul dans un fichier text
			$myfile = fopen("minmin.txt", "a") or die("Unable to open file!");
			$txt =$timediff;
			fwrite($myfile, $txt);
			$txt = "\n";
			fwrite($myfile, $txt);
			fclose($myfile);
		}
	}
	echo "<center>min min</center>";
}

function ghassan_algo()
{
	global $min1,$min2,$min3,$min4,$min5,$min6;$min7;
	include("connection.php");
	$min7=min($min4,$min5,$min6);

	$some=0;
	$ss1=0;
	$k=0;
	if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
	//--------------------------------
	//--------------------------------
	$sql4 = "update large_devices set avail=0";
	if ($conn->query($sql4) === TRUE) 
	{
		echo "";
	} 

	$sql4 = "update meduim_devices set avail=0";
	if ($conn->query($sql4) === TRUE) 
	{
		echo "";
	} 

	$sql4 = "update small_devices set avail=0";
	if ($conn->query($sql4) === TRUE) 
	{
		echo "";
	} 

	//-------------------------------
	//-------------------------------

	$sql = "SELECT *  FROM large_devices where avail=0 order by score desc";
	$result = $conn->query($sql);

	echo "<br><b><font color='green'>Search in the large devices</font></b><br><br>";
	if ($result->num_rows > 0) 
	{
	$some=1;

	$starttime = microtime(true);
	while($row = $result->fetch_assoc()) 
	{
		$id=$row["id"];
		$sql1 = "SELECT * FROM large_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size desc limit 1";
		$result1 = $conn->query($sql1);

		$row1 = $result1->fetch_assoc();
		$id1=$row1["id"];

		if ($result1->num_rows > 0) 
		{
			$ss1=1;
			if ($id1=='') 
			{
				echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
			}
			elseif($row1["size"]<=$row["score"])
			{
				echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
				//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
				$id_device=$row["id"];
				$nom_device=$row["device"];
				$id_task=$row1["id"];
				$nom_task=$row1["task"];
				$id_task=$row1["id"];
				$temps=$row1["temps"];
				$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min7);";
				if ($conn->query($sql4) === TRUE) 
				{
 					echo "";
				}
				$sql4 = "delete from large_tasks where id=" . $id1;
				if ($conn->query($sql4) === TRUE) 
				{
					echo "";
				} 

				/*$sql4 = "update large_devices set avail=1 where id=" . $id;
				if ($conn->query($sql4) === TRUE) 
				{
					echo "";
				} 
				*/
			} 


		}

	}
	$endtime = microtime(true);
	$timediff = $endtime - $starttime;
	$k=$k+$timediff;


}

	//--------------------------------------------------------
	//--------------------------------------------------------

	//--------------------------------------------------------
	//--------------------------------------------------------

	$sql = "SELECT *  FROM meduim_devices where avail=0 order by score desc";
	$result = $conn->query($sql);
	echo "<br><b><font color='green'>Search in the meduim devices</font></b><br><br>";
	if ($result->num_rows > 0) 
	{
		$some=1;
		$starttime = microtime(true);
 	while($row = $result->fetch_assoc()) 
	{
		$id=$row["id"];
		$sql1 = "SELECT * FROM meduim_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size desc limit 1";
		$result1 = $conn->query($sql1);
		$row1 = $result1->fetch_assoc();
		$id1=$row1["id"];
		if ($result1->num_rows > 0) 
		{
			$ss1=1;
			if ($id1=='') 
			{
				echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
			}
			elseif($row1["size"]<=$row["score"])
			{
				echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
				//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
				$id_device=$row["id"];
				$nom_device=$row["device"];
				$id_task=$row1["id"];
				$nom_task=$row1["task"];
				$id_task=$row1["id"];
				$temps=$row1["temps"];
				$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min7);";
				if ($conn->query($sql4) === TRUE) 
				{
					echo "";
				}
				$sql4 = "delete from meduim_tasks where id=" . $id1;
				if ($conn->query($sql4) === TRUE) 
				{
					echo "";
				} 

				$sql4 = "update meduim_devices set avail=1 where id=" . $id;
				if ($conn->query($sql4) === TRUE) 
				{
					echo "";
				} 

			} 


		}
	}
	$endtime = microtime(true);
	$timediff = $endtime - $starttime;
	$k=$k+$timediff;

} // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

	//--------------------------------------------------------
	//--------------------------------------------------------

	$sql = "SELECT *  FROM small_devices where avail=0 order by score desc";
	$result = $conn->query($sql);
	echo "<br><b><font color='green'>Search in the small devices</font></b><br><br>";
	if ($result->num_rows > 0) 
	{
		$starttime = microtime(true);
		while($row = $result->fetch_assoc()) 
	{
	$id=$row["id"];
	$sql1 = "SELECT * FROM small_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . "  order by size desc limit 1";
	$result1 = $conn->query($sql1);
	$row1 = $result1->fetch_assoc();
	$id1=$row1["id"];
	if ($result1->num_rows > 0) {
	$ss1=1;
	if ($id1=='') 
	{
		echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
	}
	elseif($row1["size"]<=$row["score"])
	{
		echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
		//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
		$id_device=$row["id"];
		$nom_device=$row["device"];
		$id_task=$row1["id"];
		$nom_task=$row1["task"];
		$id_task=$row1["id"];
		$temps=$row1["temps"];
		$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min7);";
		if ($conn->query($sql4) === TRUE) 
		{
			echo "";
		}
		$sql4 = "delete from small_tasks where id=" . $id1;
		if ($conn->query($sql4) === TRUE) 
		{
			echo "";
		} 

		$sql4 = "update small_devices set avail=1 where id=" . $id;
		if ($conn->query($sql4) === TRUE) 
		{
			echo "";
		}  
	} 


} // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
} // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

	$endtime = microtime(true);
	$timediff = $endtime - $starttime;
	$k=$k+$timediff;

} // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

	$sql5 = "SELECT count(*) nombri FROM large_tasks where  no_test=" . $min7;
	$result5 = $conn->query($sql5);
	$row5 = $result5->fetch_assoc();
	$nombri=$row2["nombri"];
	if($nombri=='' || $nombri==0)  
	{
		$sql = "SELECT *  FROM large_devices where avail=0 order by score desc";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) 
		{
			$some=1;
			$starttime = microtime(true);
			// output data of each row
			while($row = $result->fetch_assoc()) 
			{
				$id=$row["id"];
				$sql1 = "SELECT * FROM meduim_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size desc limit 1";
				$result1 = $conn->query($sql1);
				$row1 = $result1->fetch_assoc();
				$id1=$row1["id"];
				if ($result1->num_rows > 0) 
				{
					$ss1=1;
					if ($id1=='') 
					{
						echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
					}
					elseif($row1["size"]<=$row["score"])
					{
						echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
						//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
						$id_device=$row["id"];
						$nom_device=$row["device"];
						$id_task=$row1["id"];
						$nom_task=$row1["task"];
						$id_task=$row1["id"];
						$temps=$row1["temps"];
						$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min7);";
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						}
						$sql4 = "delete from meduim_tasks where id=" . $id1;
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						} 
						/*
						$sql4 = "update large_devices set avail=1 where id=" . $id;
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						} 
						*/
					} 


				}

			}
			$endtime = microtime(true);
			$timediff = $endtime - $starttime;
			$k=$k+$timediff;
		}
		//--------------------------------------------------------
		//--------------------------------------------------------

		$sql = "SELECT *  FROM large_devices where avail=0 order by score desc";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) 
		{
			$some=1;
			$starttime = microtime(true);
			while($row = $result->fetch_assoc()) 
			{
				$id=$row["id"];
				$sql1 = "SELECT * FROM small_tasks where   no_test=" . $min7 . " and size<=" . $row["score"] . "  order by size desc limit 1";
				$result1 = $conn->query($sql1);
				$row1 = $result1->fetch_assoc();
				$id1=$row1["id"];
				if ($result1->num_rows > 0) 
				{
					$ss1=1;
					if ($id1=='') 
					{
						echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
					}
					elseif($row1["size"]<=$row["score"])
					{
						echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
						//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
						$id_device=$row["id"];
						$nom_device=$row["device"];
						$id_task=$row1["id"];
						$nom_task=$row1["task"];
						$id_task=$row1["id"];
						$temps=$row1["temps"];
						$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min7);";
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						}
						$sql4 = "delete from small_tasks where id=" . $id1;
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						} 
						/*
						$sql4 = "update large_devices set avail=1 where id=" . $id;
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						} 
						*/
					} 


				}

			}
			$endtime = microtime(true);
			$timediff = $endtime - $starttime;
			$k=$k+$timediff;
		}
	}
	//aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
	$sql5 = "SELECT count(*) nombri FROM meduim_tasks where  no_test=" . $min7;
	$result5 = $conn->query($sql5);
	$row5 = $result5->fetch_assoc();
	$nombri=$row2["nombri"];
	if($nombri=='' || $nombri==0)  
	{

		$sql = "SELECT *  FROM meduim_devices where avail=0 order by score desc";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) 
		{
			$some=1;
			$starttime = microtime(true);
			while($row = $result->fetch_assoc()) 
			{
				$id=$row["id"];
				$sql1 = "SELECT * FROM small_tasks where  no_test=" . $min7 . " and size<=" . $row["score"] . " order by size desc limit 1";
				$result1 = $conn->query($sql1);
				$row1 = $result1->fetch_assoc();
				$id1=$row1["id"];
				if ($result1->num_rows > 0) 
				{
					$ss1=1;
					if ($id1=='') 
					{
						echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
					}
					elseif($row1["size"]<=$row["score"])
					{
						echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";
						//ICI ON DOIT AJOUTER LES INFORMATIONS DANS LE TABLEAU a1
						$id_device=$row["id"];
						$nom_device=$row["device"];
						$id_task=$row1["id"];
						$nom_task=$row1["task"];
						$id_task=$row1["id"];
						$temps=$row1["temps"];
						$sql4 = "INSERT INTO a4(id_device,device,id_task,task,avail,temps,no_test) VALUES ($id_device,'$nom_device',$id_task,'$nom_task',1,$temps,$min7);";
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						}
						$sql4 = "delete from small_tasks where id=" . $id1;
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						} 

						$sql4 = "update meduim_devices set avail=1 where id=" . $id;
						if ($conn->query($sql4) === TRUE) 
						{
							echo "";
						} 

					} 


				}

			}
			$endtime = microtime(true);
			$timediff = $endtime - $starttime;
			$k=$k+$timediff;
		}
	}
	if ($ss1==1)  
	{
		echo '<b>The search time  is ' .  number_format((float)$k, 6, '.', '') . ' seconds</b><br>';

		//ecrire tout le temps de calcul dans un fichier text
		$myfile = fopen("ghassanalgo.txt", "a") or die("Unable to open file!");
		$txt =$k;
		fwrite($myfile, $txt);
		$txt = "\n";
		fwrite($myfile, $txt);
		fclose($myfile);
	}
	else
	{
		echo '<b>All the tasks are executed</b>';
	}

	echo "<center>end Notre algorithme</center>";

} // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

function new_results()
{
	include("connection.php");
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	} 

		echo "<center>end new results</center>";
}


function delete_cash()
{
	include("connection.php");
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	} 

	echo "<center>end delete cash</center>";
}

?>