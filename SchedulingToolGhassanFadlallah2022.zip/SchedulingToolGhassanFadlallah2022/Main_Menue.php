<?php
include("top.php"); 
include("Create_Devices.php");
include("Devices_Division.php");
include("Initialize_Devices.php");
include("Create_Tasks.php");
include("Tasks_Division.php");
include("Initialize_Tasks.php");

?>
<form method="post" action="Main_Menue.php">
Nombre de devices:<input type="text" name="devico" value='0'>
<input type="submit" name="idtest" value='Generer le liste de devices'>
<br><br><br>

Nombre de taches:<input type="text" name="tasko" value='0'>
<input type="submit" name="idtest" value='Generer le liste de taches'>
<br><br><br>

Nombre d'instances de taches:<input type="text" name="instantasko" value='0'>
<input type="submit" name="idtest" value='Generer le nombre d'instances de taches'>
<br><br><br>

// Appel de la fonction Create_Devices.php;
// Appel de la fonction Devices-Division.php; 

for($i = 0; $i < $instantasko; $i++) {
   // Appel de la fonction Create_Tasks.php; 
   // Appel de la fonction Tasks-Division.php; 
   // Appel de la fonction compare-algorithms1.php;
   // Appel de la fonction compare-algorithms2.php;
   // Appel de la fonction compare-algorithms3.php;
   // Appel de la fonction compare-algorithms4.php;
   // Appel de la fonction compare-algorithms6.php;
   // Appel de la fonction compare-algorithms10.php;
   // Appel de la fonction compare-algorithms11.php;


}

?>


</body>

</html>





