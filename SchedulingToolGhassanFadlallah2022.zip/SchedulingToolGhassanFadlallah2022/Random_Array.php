<?php 

// Sélectionne une ou plusieurs entrées aléatoires dans un tableau et renvoie la clé (ou les clés) des entrées aléatoires.
array_rand ( array $array [, int $num = 1 ] ) : mixed
  
// Declare an associative array 
$arr = array( "a"=>"21", "b"=>"31", "c"=>"7", "d"=>"20" ); 
  
// Use shiffle function to randomly assign numeric 
// key to all elements of array. 
shuffle($arr); 
  
// Display the first shuffle element of array 
echo $arr[0]; 
  
?> 
