<?php session_start(); 
include("connection.php"); 

		echo "<script language='javascript'>window.location='list_devices.php?connection=1' </script>";


?>

<html lang="en-US">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title><? echo strtoupper($un_element3003["nom"]) . ", " . strtoupper($un_element3003["adresse"]) . ", " . strtoupper($un_element3003["ville"]) . ", " . strtoupper($un_element3003["code_postal"]) . ", TEL :  " . $un_element3003["telephone"] . ", FAX :  " . $un_element3003["fax"]; ?></title>
<meta name="keywords" content="PUT, YOUR, PAGE-SPECIFIC, KEYWORDS, HERE">
<meta name="description" content="Register for a Sun Online Account">
<meta http-equiv="content-language" content="en-US">
 <link rel="stylesheet" type="text/css" href="css/default_developer.css">

</head>

<body leftmargin="0" topmargin="0" marginheight="0" marginwidth="0" bgcolor="#ffffff" onload="javascript:document.form.login.focus();">
<div class="pagetitle" style="width: 907; height: 14">
    <span style="font-size: 16pt" lang="fr-ca">
</span>
  </div>

<!-- ============ -->
<!-- MAIN CONTENT -->
<!-- ============ -->
 <form method=post  enctype="multipart/form-data"  name=form action="index.php?ajouter=1">
      <div class="cornerBL">
      <div class="cornerBR">
      <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Entrer votre nom d'usager et mot de passe pour connecter, <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;si vous n'avez pas une veuillez contacter Freniere & Fils Inc. au numero (514) 272-1033<span lang="fr-ca">
      </span></p>
      
      <div class="g25 g25biglabels">
  <!-- Begin fields here -->
      <div class="fieldset">
      <fieldset>
      <legend><font color="#0000FF">Informations Vendeur</font></legend>      
      <div class="labeled-input">
      <p class="label">
      <label for="f1text16">
       <img src="images/ic_asteric.gif" alt="(required)" class="required-icon" width="7" height="6">Code du vendeur</label>
       </p>
       <p class="input"><input type="text" name="login" id="f1text16" value="" size="30" onfocus="formInUse = true;" />
       <span class="help"></span>
       </p></div>
       
       <div class="labeled-input">
       <p class="label">
   <label for="f1text6">
        <img src="images/ic_asteric.gif" alt="(required)" class="required-icon" width="7" height="6">Mot de passe</label>
 </p>
 <p class="input"><input type="password" name="mot_de_passe" id="f1text6" value="" size="30" onfocus="formInUse = true;" />
<span class="help"></span>
  </p>
</div>

      <div class="submit">
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" id="regSubmit" border="0" class="buttonred" value="&nbsp;ENTRER &raquo;" onmouseover="this.style.color='#fbe249';" onmouseout="this.style.color='#FFF';" />
      </div>
<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" id="regSubmi111" border="0" class="buttonred" value="&nbsp;ALLER EN MODE TEST &raquo;" onmouseover="this.style.color='#fbe249';" onclick="javascript:window.location='modetest/index.php'" onmouseout="this.style.color='#FFF';" />

</form>
<span class="sp10">&nbsp;</span><br />
<span class="sp10">&nbsp;</span><br />
</div>
</div>
</div>
</div>
</body>
</html>