<?php include("connection.php");
include("top.php");

$sql2 = "SELECT max(no_test) maxi FROM a1";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$maxi=$row2["maxi"];

$sum_time_device=0;
$nb_device=0;
$std_dev=0;
$nb=10;
$cr=0;
$rep=0;

function Carree($nb){
    $result = $nb*$nb;
    return $result;
    // echo "Le carré de $nb est : $result";
}

function RacineCarree($nb)
{
	$rep = sqrt($nb);
	return $rep;
	//echo '<br><br>--------------------------------<br>';
	//echo '<b>Racine carree: ' . $rep . '</b><br>';
	//echo '--------------------------------';
}

//echo 'maxiii=' . $maxi;
for ($jjj=1;$jjj<=$maxi;$jjj++) 
{
	echo '<h1>INSTANCE NO: ' . $jjj . '</h1><br>';
	$maxspan1=0;$maxspan2=0;$maxspan3=0;$maxspan4=0;
	$minspan1=2000;$minspan2=2000;$minspan3=2000;$minspan4=2000;
	$dev1=0;$dev2=0;$dev3=0;$dev4=0;
	echo '<br><br>--------------------------------<br>';
	echo '<b>Resultats LCFP</b><br>';
	echo '--------------------------------';
	$s=0;
	$sql1 = "SELECT distinct(id_device)  FROM a1 where no_test=". $jjj;
	$result1 = $conn->query($sql1);

	$nb_device=$result1->num_rows;
	echo '<br><br>--------------------------------<br>';
	echo 'nombre des appareils: ' . $nb_device . '<br>';

	if ($result1->num_rows > 0) 
	{
    		// output data of each row
    		while($row1 = $result1->fetch_assoc()) 
		{
			$id_device=$row1["id_device"];

			$sql2 = "SELECT count(*) nombre FROM a1 where id_device=". $id_device. " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$nombre=$row2["nombre"];

			$sql2 = "SELECT device FROM a1 where id_device=". $id_device . " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$device=$row2["device"];

			$nom_task=$row1["task"];
			$nom_device=$row1["device"];
			echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';

			$some=0;
			$some2=0;
			$sql3 = "SELECT task,temps FROM a1 where id_device=". $id_device . " and no_test=". $jjj;;
			$result3 = $conn->query($sql3);
			while($row3 = $result3->fetch_assoc()) 
			{
				$task=$row3["task"];
				$temps=$row3["temps"];
				$some=$some+$temps;
				echo $task . ', ' . $temps . ' seconds<br>';
				//affichage des sizes des tasks
				$sql5 = "SELECT size FROM tasks where task='". $task . "'";
				$result5 = $conn->query($sql5);
				$row5 = $result5->fetch_assoc();
				$size=$row5["size"];

				$some2=$some2+$size;
				//echo 'Taille taches=' . $size . '<br>';
			}
			$s=$s+$some;
			echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
			echo 'Temps total requis par cet appareil ' . $some . ' seconds<br>';
			if($maxspan1<$some) 
			{
				$maxspan1=$some;
				$dev1=$device;
			}

			if($minspan1>$some) 
			{
				$minspan1=$some;
			}
			$sum_time_device=$sum_time_device+$s;
			$dif=$sum_time_device-$maxspan1;
			$cr=Carree($dif);
			
			echo 'Taille total des taches executes ' . $cr . '<br>';
 		}
			//std_dev=sqrt($cr/$nb_device);

			echo '<br><br><b> Deviation standard de LCFP:' . $std_dev . '</b><br>';			 	
	} 

	echo '<br><br><b>Temps Total LCFP:' . $s . ' seconds</b><br>';
	?>


	<?php 
	$maxspan2=0;
	$dev2=0;
	echo '<br><br>--------------------------------<br>';
	echo '<b>Resultats SCF</b><br>';
	echo '--------------------------------';
	$s=0;
	$sql1 = "SELECT distinct(id_device)  FROM a2 where no_test=". $jjj;
	$result1 = $conn->query($sql1);

	if ($result1->num_rows > 0) 
	{
    		// output data of each row
    		while($row1 = $result1->fetch_assoc()) 
		{
			$id_device=$row1["id_device"];

			$sql2 = "SELECT count(*) nombre FROM a2 where id_device=". $id_device . " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$nombre=$row2["nombre"];

			$sql2 = "SELECT device FROM a2 where id_device=". $id_device ." and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$device=$row2["device"];

			$nom_task=$row1["task"];
			$nom_device=$row1["device"];
			echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';


			$some=0;
			$some2=0;
			$sql3 = "SELECT task,temps FROM a2 where id_device=". $id_device. " and no_test=". $jjj;
			$result3 = $conn->query($sql3);
			while($row3 = $result3->fetch_assoc()) {
			$task=$row3["task"];
			$temps=$row3["temps"];
			$some=$some+$temps;
			echo $task . ', ' . $temps . ' seconds<br>';
			//affichage des sizes des tasks
			$sql5 = "SELECT size FROM tasks where task='". $task . "'";
			$result5 = $conn->query($sql5);
			$row5 = $result5->fetch_assoc();
			$size=$row5["size"];

			$some2=$some2+$size;
			//echo 'Taille taches=' . $size . '<br>';
		}
		$s=$s+$some;
		echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
		echo 'Temps total requis par cet appareil ' . $some . ' seconds<br>';
		if($maxspan2<$some) 
		{
			$maxspan2=$some;
			$dev2=$device;
		}


		if($minspan2>$some) 
		{
			$minspan2=$some;
		}

		echo 'Taille total des taches executes ' . $some2 . '<br>';
	} 

} // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx 

	echo '<br><br><b>Temps Total SCF:' . $s . ' seconds</b><br>';
	?>



	<?php 
	$maxspan3=0;
	$dev3=0;
	echo '<br><br>--------------------------------<br>';
	echo '<b>Resultats Min Min</b><br>';
	echo '--------------------------------';
	$s=0;
	$sql1 = "SELECT distinct(id_device)  FROM a3 where no_test=". $jjj;
	$result1 = $conn->query($sql1);

	if ($result1->num_rows > 0) 
	{
    		// output data of each row
   		while($row1 = $result1->fetch_assoc()) 
		{
			$id_device=$row1["id_device"];
	
			$sql2 = "SELECT count(*) nombre FROM a3 where id_device=". $id_device . " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$nombre=$row2["nombre"];

			$sql2 = "SELECT device FROM a3 where id_device=". $id_device. " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$device=$row2["device"];

			$nom_task=$row1["task"];
			$nom_device=$row1["device"];
			echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';

			$some=0;
			$some2=0;
			$sql3 = "SELECT task,temps FROM a3 where id_device=". $id_device . " and no_test=". $jjj;
			$result3 = $conn->query($sql3);
			while($row3 = $result3->fetch_assoc()) 
			{
				$task=$row3["task"];
				$temps=$row3["temps"];
				$some=$some+$temps;
				echo $task . ', ' . $temps . ' seconds<br>';
				//affichage des sizes des tasks
				$sql5 = "SELECT size FROM tasks where task='". $task . "'";
				$result5 = $conn->query($sql5);
				$row5 = $result5->fetch_assoc();
				$size=$row5["size"];

				$some2=$some2+$size;
				//echo 'Taille taches=' . $size . '<br>';
			}
			$s=$s+$some;
			echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
			echo 'Temps total requis par cet appareil ' . $some . ' seconds<br>';
			if($maxspan3<$some) 
			{
				$maxspan3=$some;
				$dev3=$device;
			}


			if($minspan3>$some) 
			{
				$minspan3=$some;
			}


			//echo 'Taille total des taches executes ' . $some2 . '<br>';
		} 
	} 

	//echo '<br><br><b>Temps Total Min Min:' . $s . ' seconds</b><br>';
	?>

	<?php 
	$maxspan4=0;
	$dev4=0;
	echo '<br><br>--------------------------------<br>';
	echo '<b>Resultats Notre Algorithme</b><br>';
	echo '--------------------------------';
	$s=0;
	$sql1 = "SELECT distinct(id_device)  FROM a4 where no_test=". $jjj;
	$result1 = $conn->query($sql1);

	if ($result1->num_rows > 0) 
	{
    		// output data of each row
    		while($row1 = $result1->fetch_assoc()) 
		{
			$id_device=$row1["id_device"];

			$sql2 = "SELECT count(*) nombre FROM a4 where id_device=". $id_device . " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$nombre=$row2["nombre"];

			$sql2 = "SELECT device FROM a4 where id_device=". $id_device  . " and no_test=". $jjj;
			$result2 = $conn->query($sql2);
			$row2 = $result2->fetch_assoc();
			$device=$row2["device"];

			$nom_task=$row1["task"];
			$nom_device=$row1["device"];
			echo '<br><br>Le device ' . $device . ' a execute les taches suivants:<br>';


			$some=0;
			$some2=0;
			$sql3 = "SELECT task,temps FROM a4 where id_device=". $id_device. " and no_test=". $jjj;
			$result3 = $conn->query($sql3);
			while($row3 = $result3->fetch_assoc()) 
			{
				$task=$row3["task"];
				$temps=$row3["temps"];
				$some=$some+$temps;
				echo $task . ', ' . $temps . ' seconds<br>';
				//affichage des sizes des tasks
				$sql5 = "SELECT size FROM tasks where task='". $task . "'";
				$result5 = $conn->query($sql5);
				$row5 = $result5->fetch_assoc();

				$size=$row5["size"];

				$some2=$some2+$size;
				//echo 'Taille taches=' . $size . '<br>';
			}
			$s=$s+$some;
			echo 'nombre des taches atribue a cet appareil: ' . $nombre . '<br>';
			echo 'Temps total requis par cet appareil ' . $some . ' seconds<br>';
			if($maxspan4<$some) 
			{
				$maxspan4=$some;
				$dev4=$device;
			}

			if($minspan4>$some) 
			{
				$minspan4=$some;
			}



		} 
	} 

	//echo '<br><br><b>Temps Total Notre Algorithme:' . $s . ' seconds</b><br>';

	$sql2 = "SELECT count(id_task) nbr_task FROM a1 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_task1=$row2["nbr_task"];

	$sql2 = "SELECT count(distinct(id_device)) nbr_device FROM a1 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_device1=$row2["nbr_device"];


	$sql2 = "SELECT count(id_task) nbr_task FROM a2 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_task2=$row2["nbr_task"];

	$sql2 = "SELECT count(distinct(id_device)) nbr_device FROM a2 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_device2=$row2["nbr_device"];

	$sql2 = "SELECT count(id_task) nbr_task FROM a3 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_task3=$row2["nbr_task"];

	$sql2 = "SELECT count(distinct(id_device)) nbr_device FROM a3 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_device3=$row2["nbr_device"];


	$sql2 = "SELECT count(id_task) nbr_task FROM a4 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_task4=$row2["nbr_task"];

	$sql2 = "SELECT count(distinct(id_device)) nbr_device FROM a4 where no_test=". $jjj;
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$nbr_device4=$row2["nbr_device"];
	$diff1=$maxspan1-$minspan1;
	$diff2=$maxspan2-$minspan2;
	$diff3=$maxspan3-$minspan3;
	$diff4=$maxspan4-$minspan4;

	$sql4 = "INSERT INTO a5(max_span,min_span,difference,device,nbr_device,nbr_task,algorithm,no_test)  VALUES ($maxspan1,$minspan1,$diff1,'$dev1',$nbr_device1,$nbr_task1,'LCF',$jjj);";
	if ($conn->query($sql4) === TRUE) 
	{
    		echo "";
	}

	$sql4 = "INSERT INTO a5(max_span,min_span,difference,device,nbr_device,nbr_task,algorithm,no_test)  VALUES ($maxspan2,$minspan2,$diff2,'$dev2',$nbr_device2,$nbr_task2,'SCF',$jjj);";
	if ($conn->query($sql4) === TRUE) 
	{
   		 echo "";
	}

	$sql4 = "INSERT INTO a5(max_span,device,min_span,difference,nbr_device,nbr_task,algorithm,no_test)  VALUES ($maxspan3,$minspan3,$diff3,'$dev3',$nbr_device3,$nbr_task3,'Min Min',$jjj);";
	if ($conn->query($sql4) === TRUE) 
	{
    		echo "";
	}

	$sql4 = "INSERT INTO a5(max_span,min_span,difference,device,nbr_device,nbr_task,algorithm,no_test)  VALUES ($maxspan4,$minspan4,$diff4,'$dev4',$nbr_device4,$nbr_task4,'Gassan Algorithm',$jjj);";
	if ($conn->query($sql4) === TRUE) 
	{
    		echo "";
	}

	echo '<b>Maxspan LCF ' . $maxspan1 . '</b><br>';
	echo '<b>Maxspan SCF ' . $maxspan2 . '</b><br>';
	echo '<b>Maxspan Min Min ' . $maxspan3 . '</b><br>';
	echo '<b>Maxspan Gassan Algorithm ' . $maxspan4 . '</b><br>';

	echo '<b>Minspan LCF ' . $minspan1 . '</b><br>';
	echo '<b>Minspan SCF ' . $minspan2 . '</b><br>';
	echo '<b>Minspan Min Min ' . $minspan3 . '</b><br>';
	echo '<b>Minspan Gassan Algorithm ' . $minspan4 . '</b><br>';

	echo '<b>Difference LCF ' . $diff1 . '</b><br>';
	echo '<b>Difference SCF ' . $diff2 . '</b><br>';
	echo '<b>Difference Min Min ' . $diff3 . '</b><br>';
	echo '<b>Difference Gassan Algorithm ' . $diff4 . '</b><br>';
}

?>




















