<?php include("connection.php");
include("top.php");
$sql4 = "delete from a1";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from a2";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from a3";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from a4";
if ($conn->query($sql4) === TRUE) {
echo "";
}
echo '<b>Cache deleted</b>';
?>




















