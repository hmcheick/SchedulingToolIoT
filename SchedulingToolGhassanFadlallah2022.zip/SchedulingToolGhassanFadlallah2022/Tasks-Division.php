
<?php include("connection.php");
/*Ce script est pour initialiser les données, 
on doit l'executer avant chaque algorithme pour reinitialiser
les taches et les devices, on utilise les deux fichiers devices.txt et tasks.txt
ces deux fichiers contiennent les devices et les taches à executé
*/
include("top.php");


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 



//Division des taches
//-----------------------------------
//----------------------------------
$starttime = microtime(true);

$sql5 = "delete from small_tasks;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from meduim_tasks;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from large_tasks;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
//begin of small division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT * FROM tasks where size>0 and size<10";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$task=$row["task"];
$size=$row["size"];
$temps=$row["temps"];
$sql4 = "INSERT INTO small_tasks(task,size,avail,temps) VALUES ('$task',$size,0,$temps);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 

//begin of meduim division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql1 = "SELECT * FROM tasks where size>=10 and size<20";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
$task=$row1["task"];
$size=$row1["size"];
$temps=$row1["temps"];
$sql5 = "INSERT INTO meduim_tasks(task,size,avail,temps) VALUES ('$task',$size,0,$temps);";
if ($conn->query($sql5) === TRUE) {
    echo "";
} } } 

//begin of large division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql2 = "SELECT * FROM tasks where size>=20";
$result2 = $conn->query($sql2);

if ($result2->num_rows > 0) {
    // output data of each row
    while($row2 = $result2->fetch_assoc()) {
$task=$row2["task"];
$size=$row2["size"];
$temps=$row2["temps"];
$sql4 = "INSERT INTO large_tasks(task,size,avail,temps) VALUES ('$task',$size,0,$temps);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 


//echo '<b>Division finished with succes</b>';
 //---------------------------------------------
//---------------------------------------------


?>


</body>

</html>

