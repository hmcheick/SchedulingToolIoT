<?php
include("top.php"); 
include("connection.php");
?>
<form method="post" action="compare-algorithms00.php">
Nombre de devices:<input type="text" name="devico" value='0'><br>
Nombre de taches:<input type="text" name="tasko" value='0'><br>
Nombre d'instances:<input type="text" name="inst" value='0'><br>
<input type="submit" name="idtest" value='Generer le liste de devices et taches'>
<br><br><br>





<?php
$nbrdevice=$_POST['devico'];
$inst=$_POST['inst'];
if($inst=='') $inst=0;

$sql4 = "delete from devices";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from devices1";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from devices2";
if ($conn->query($sql4) === TRUE) {
echo "";
}
$sql4 = "delete from large_devices";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from meduim_devices";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from small_devices";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}


$sql4 = "delete from tasks1";
if ($conn->query($sql4) === TRUE) {
echo "";
}


$sql4 = "delete from tasks2";
if ($conn->query($sql4) === TRUE) {
echo "";
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from large_tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from meduim_tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql4 = "delete from small_tasks";
if ($conn->query($sql4) === TRUE) {
echo "";
}


$sql4 = "delete from a1";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from a2";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from a3";
if ($conn->query($sql4) === TRUE) {
echo "";
}

$sql4 = "delete from a4";
if ($conn->query($sql4) === TRUE) {
echo "";
}


$sql4 = "delete from a5";
if ($conn->query($sql4) === TRUE) {
echo "";
}

if($nbrdevice>=0) 
{
if($_POST['devico']!='')
{
$fichier = fopen('devices.txt','w');
for($i = 0; $i < $nbrdevice-1; $i++) {
$score=mt_rand(40,370) /10;
$k=$i+1;
$tok="DE" . $k . " " . $score. "\r\n";
fwrite($fichier, $tok);
//fwrite($fichier, '\n');
echo $tok . '<br>';
}
$k=$i+1;
$score=mt_rand(40,350) /10;
$tok="DE" . $k . " " . $score. "\r\n";
echo $tok . '<br>';
fwrite($fichier, $tok);
fclose($fichier);
}



$nbrtask=$_POST['tasko'];
if($_POST['tasko']!='')
{
$fichier = fopen('tasks.txt','w');
for($jj = 0; $jj < $inst; $jj++) {
for($i = 0; $i < $nbrtask; $i++) {
$k=$i+1;
$nb_test=$jj+1;

$temps=rand(1,250) /10;
$tok="TA" . $k . " " . $temps. " " . $temps. " " . $nb_test . "\r\n";
fwrite($fichier, $tok);
//fwrite($fichier, '\n');
echo $tok . '<br>';
}
}
fclose($fichier);
}


    // Nom du fichier des devices
    $fichier = file("devices.txt");
    // Nombre total de ligne du fichier
    $total = count($fichier);
    for($i = 0; $i < $total; $i++) {
    // On affiche ligne par ligne le contenu du fichier
    // avec la fonction nl2br pour ajouter les sauts de lignes
   // echo $fichier[$i] . '<br>';
$tt=explode(" ", $fichier[$i]);
$sql = "INSERT INTO devices(device,score,avail) VALUES ('$tt[0]',$tt[1],0);";

if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$sql = "INSERT INTO devices1(device,score,avail) VALUES ('$tt[0]',$tt[1],0);";

if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$sql = "INSERT INTO devices2(device,score,avail) VALUES ('$tt[0]',$tt[1],0);";

if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


    }


    // Nom du fichier des taches
    $fichier = file("tasks.txt");
    // Nombre total de ligne du fichier
    $total = count($fichier);
    for($i = 0; $i < $total; $i++) {
    // On affiche ligne par ligne le contenu du fichier
    // avec la fonction nl2br pour ajouter les sauts de lignes
   // echo $fichier[$i] . '<br>';
$tt=explode(" ", $fichier[$i]);
$sql = "INSERT INTO tasks(task,size,avail,temps,no_test) VALUES ('$tt[0]',$tt[1],0,$tt[2],$tt[3]);";
if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$sql = "INSERT INTO tasks1(task,size,avail,temps,no_test) VALUES ('$tt[0]',$tt[1],0,$tt[2],$tt[3]);";
if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$sql = "INSERT INTO tasks2(task,size,avail,temps,no_test) VALUES ('$tt[0]',$tt[1],0,$tt[2],$tt[3]);";
if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


    }


//Division des devices
//-----------------------------------
//----------------------------------
$sql5 = "delete from small_devices;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from meduim_devices;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from large_devices;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
// ++++++++++++++++++++++++++++++++++++
$result_d= mysql_query("SELECT MAX(score) AS maximum_d FROM devices");

$row_d = mysql_fetch_assoc($result_d); 

$maximum_d = $row_d['maximum_d'];

// ++++++++++++++++++++++++++++++++++++
//begin of small division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
// $sql = "SELECT * FROM devices where score>0 and score<10";
$sql = "SELECT * FROM devices where score>0 and score<$maximum_d/3";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$device=$row["device"];
$score=$row["score"];
$sql4 = "INSERT INTO small_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 

//begin of meduim division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
// $sql1 = "SELECT * FROM devices where score>=10 and score<20";
$sql1 = "SELECT * FROM devices where score>=$maximum_d/3 and score<2*$maximum_d/3";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
$device=$row1["device"];
$score=$row1["score"];
$sql5 = "INSERT INTO meduim_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql5) === TRUE) {
    echo "";
} } } 

//begin of large division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
// $sql2 = "SELECT * FROM devices where score>=20";
$sql2 = "SELECT * FROM devices where score>=2*$maximum_d/3";
$result2 = $conn->query($sql2);

if ($result2->num_rows > 0) {
    // output data of each row
    while($row2 = $result2->fetch_assoc()) {
$device=$row2["device"];
$score=$row2["score"];
$sql4 = "INSERT INTO large_devices(device,score,avail) VALUES ('$device',$score,0);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 

// ++++++++++++++++++++++++++++++++++++
$result_sd= mysql_query("SELECT MAX(score) AS maximum_sd FROM small_devices");

$row_sd = mysql_fetch_assoc($result_sd); 

$maximum_sd = $row_sd['maximum_sd'];
// echo ("This is the maximum value in small_devices: $maximum_sd");
// ++++++++++++++++++++++++++++++++++++

// ++++++++++++++++++++++++++++++++++++
$result_md= mysql_query("SELECT MAX(score) AS maximum_md FROM meduim_devices");

$row_md = mysql_fetch_assoc($result_md); 

$maximum_md = $row_md['maximum_md'];
// echo ("***     This is the maximum value in meduim_devices: $maximum_md");
// ++++++++++++++++++++++++++++++++++++


$endtime = microtime(true);
$timediff = $endtime - $starttime;
$some=$some+$timediff;
$s0=$timediff;
//---------------------------------------------
//---------------------------------------------

//Division des taches
//-----------------------------------
//----------------------------------
$starttime = microtime(true);

$sql5 = "delete from small_tasks;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from meduim_tasks;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}
$sql5 = "delete from large_tasks;";
if ($conn->query($sql5) === TRUE) {
    echo "";
}

//begin of small division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT * FROM tasks where size>0 and size<0.85*$maximum_sd";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$task=$row["task"];
$size=$row["size"];
$temps=$row["temps"];
$notest=$row["no_test"];
$sql4 = "INSERT INTO small_tasks(task,size,avail,temps,no_test) VALUES ('$task',$size,0,$temps,$notest);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 

//begin of meduim division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql1 = "SELECT * FROM tasks where size>=0.85*$maximum_sd and size<0.85*$maximum_md";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
$task=$row1["task"];
$size=$row1["size"];
$temps=$row1["temps"];
$notest=$row1["no_test"];
$sql5 = "INSERT INTO meduim_tasks(task,size,avail,temps,no_test) VALUES ('$task',$size,0,$temps,$notest);";
if ($conn->query($sql5) === TRUE) {
    echo "";
} } } 

//begin of large division
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql2 = "SELECT * FROM tasks where size>=0.85*$maximum_md";
$result2 = $conn->query($sql2);

if ($result2->num_rows > 0) {
    // output data of each row
    while($row2 = $result2->fetch_assoc()) {
$task=$row2["task"];
$size=$row2["size"];
$temps=$row2["temps"];
$notest=$row2["no_test"];
$sql4 = "INSERT INTO large_tasks(task,size,avail,temps,no_test) VALUES ('$task',$size,0,$temps,$notest);";
if ($conn->query($sql4) === TRUE) {
    echo "";
} } } 

/*
if($_POST['tasko']!='' && isset($_POST['tasko']))
{
?>

<script language='javascript'>window.location='http://localhost/main.php';</script>
<?php
} 
*/
} 

?>

</body>

</html>





