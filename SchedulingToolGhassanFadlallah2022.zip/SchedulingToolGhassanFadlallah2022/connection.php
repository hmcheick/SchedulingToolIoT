<?php 
 $connection = mysql_connect ("localhost", "root", "")
                or die ('Cannot connect to the database because: ' . mysql_error());
  mysql_select_db("healthsoftware", $connection) or die('Could not select database');	

$conn = new mysqli("localhost", "root", "", "healthsoftware");	
$conn1 = new mysqli("localhost", "root", "", "healthsoftware");	
?>
