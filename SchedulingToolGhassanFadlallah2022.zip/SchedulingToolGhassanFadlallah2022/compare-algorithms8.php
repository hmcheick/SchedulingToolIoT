<?php
header("refresh: 10"); 
//on utilise 10 seconds pour ré-executer des nouvelles taches
//on peut mettre 20 seconds, 30 seconds ou autre
//Ce script execute le lcf algorithme, on doit attendre qu'il execute tous les taches qui sont
//dans le fichier tasks.txt
include("connection.php");
include("top.php");
$ss1=0;
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error);} 
$sql = "SELECT *  FROM devices order by score desc";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

$starttime = microtime(true);
    // output data of each row
    while($row = $result->fetch_assoc()) {

$id=$row["id"];

if ($row["score"] >= 20) { $sql1 = "SELECT * FROM tasks order by size desc limit 1"; }
elseif ($row["score"] >= 10) { $sql1 = "SELECT * FROM tasks where size<20 order by size desc limit 1"; }
elseif ($row["score"] < 10) { $sql1 = "SELECT * FROM tasks where size<10 order by size desc limit 1"; } 
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
$id1=$row1["id"];
if ($result1->num_rows > 0) {
$ss1=1;
if ($id1=='') {
echo "<b><font color='blue'>We didn't finf any device available to do the task</font><font color='red'> " . $row1["task"] . "</font></b><br><br>";
}
elseif($row1["size"]>1.3*$row["score"] and $row1["size"]<1.7*$row["score"])
{
echo "<b><font color='blue'>the device </font><font color='red'>" . $row["device"] . "</font><font color='blue'> was available and know we use it to do the task </font><font color='red'>" . $row1["task"] . "</font></b><br><br>";

$sql4 = "delete from tasks where id=" . $id1;
if ($conn->query($sql4) === TRUE) {
    echo "";
} 
} 


}
}
$endtime = microtime(true);
$timediff = $endtime - $starttime;

if ($ss1==0)
{
echo '<b>All the tasks are executed</b>';
}
else
{
echo '<b>The search time  is ' .  number_format((float)$timediff, 6, '.', '') . ' seconds</b><br>';





$endtime = microtime(true);
$timediff = $endtime - $starttime;
//ecrire tout le temps de calcul dans un fichier text
$myfile = fopen("lcf.txt", "a") or die("Unable to open file!");
$txt =$timediff;
fwrite($myfile, $txt);
$txt = "\n";
fwrite($myfile, $txt);
fclose($myfile);
}
} 



?>






